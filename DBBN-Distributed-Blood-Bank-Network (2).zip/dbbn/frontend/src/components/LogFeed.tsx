import React from "react";
import type { LogEntry } from "../types";
import { timeAgo } from "./ui";

const typeColor: Record<string, string> = {
  RPC: "text-sky-400 border-sky-500/30 bg-sky-500/10",
  MESSAGE: "text-violet-400 border-violet-500/30 bg-violet-500/10",
  P2P: "text-teal-400 border-teal-500/30 bg-teal-500/10",
  ELECTION: "text-amber-400 border-amber-500/30 bg-amber-500/10",
};

export default function LogFeed({ logs, max = 60 }: { logs: LogEntry[]; max?: number }) {
  const items = logs.slice(0, max);
  if (items.length === 0) {
    return <div className="text-sm text-slate-500 py-8 text-center">No activity yet — trigger a search, reservation, or node failure to see live logs.</div>;
  }
  return (
    <div className="space-y-1.5 font-mono text-xs max-h-[520px] overflow-y-auto pr-1">
      {items.map((l) => (
        <div key={l.id} className="log-enter flex items-start gap-2 px-2 py-1.5 rounded-lg bg-black/20 border border-white/5">
          <span className={`shrink-0 px-1.5 py-0.5 rounded border text-[10px] font-semibold ${typeColor[l.type] || ""}`}>{l.type}</span>
          <span className="text-slate-300 flex-1">
            <span className="text-slate-500">{l.from}</span>
            <span className="text-slate-600"> → </span>
            <span className="text-slate-500">{l.to}</span>
            <span className="text-slate-400">: </span>
            {l.summary}
          </span>
          <span className="text-slate-600 shrink-0">{timeAgo(l.ts)}</span>
        </div>
      ))}
    </div>
  );
}
