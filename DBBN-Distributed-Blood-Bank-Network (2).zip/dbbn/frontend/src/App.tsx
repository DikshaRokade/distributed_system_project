import React from "react";
import { HashRouter, Routes, Route } from "react-router-dom";
import Sidebar from "./components/Sidebar";
import { NetworkProvider } from "./store";

import Dashboard from "./pages/Dashboard";
import BloodSearch from "./pages/BloodSearch";
import EmergencyRequests from "./pages/EmergencyRequests";
import NetworkTopology from "./pages/NetworkTopology";
import NodeManagement from "./pages/NodeManagement";
import CommunicationMonitor from "./pages/CommunicationMonitor";
import ReplicationMonitor from "./pages/ReplicationMonitor";
import LeaderElection from "./pages/LeaderElection";
import FaultTolerance from "./pages/FaultTolerance";
import Transactions from "./pages/Transactions";
import VirtualInfrastructure from "./pages/VirtualInfrastructure";
import DSConcepts from "./pages/DSConcepts";
import ClockSync from "./pages/ClockSync";
import LogicalClocks from "./pages/LogicalClocks";
import GlobalSnapshot from "./pages/GlobalSnapshot";
import MutualExclusion from "./pages/MutualExclusion";
import Beacon from "./pages/Beacon";
import DeadlockDetection from "./pages/DeadlockDetection";
import DistObjects from "./pages/DistObjects";
import WebSystems from "./pages/WebSystems";
import DistFileSystem from "./pages/DistFileSystem";
import Serverless from "./pages/Serverless";
import MapReduceJob from "./pages/MapReduceJob";
import Orchestrator from "./pages/Orchestrator";
import NetworkFabric from "./pages/NetworkFabric";

export default function App() {
  return (
    <NetworkProvider>
      <HashRouter>
        <div className="flex min-h-screen bg-slate-950">
          <Sidebar />
          <main className="flex-1 min-w-0 p-6 max-w-[1500px]">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/search" element={<BloodSearch />} />
              <Route path="/emergency" element={<EmergencyRequests />} />
              <Route path="/topology" element={<NetworkTopology />} />
              <Route path="/nodes" element={<NodeManagement />} />
              <Route path="/monitor" element={<CommunicationMonitor />} />
              <Route path="/replication" element={<ReplicationMonitor />} />
              <Route path="/election" element={<LeaderElection />} />
              <Route path="/fault-tolerance" element={<FaultTolerance />} />
              <Route path="/transactions" element={<Transactions />} />
              <Route path="/infrastructure" element={<VirtualInfrastructure />} />
              <Route path="/clocks" element={<ClockSync />} />
              <Route path="/logical" element={<LogicalClocks />} />
              <Route path="/snapshot" element={<GlobalSnapshot />} />
              <Route path="/mutex" element={<MutualExclusion />} />
              <Route path="/beacon" element={<Beacon />} />
              <Route path="/deadlock" element={<DeadlockDetection />} />
              <Route path="/objects" element={<DistObjects />} />
              <Route path="/web" element={<WebSystems />} />
              <Route path="/dfs" element={<DistFileSystem />} />
              <Route path="/serverless" element={<Serverless />} />
              <Route path="/mapreduce" element={<MapReduceJob />} />
              <Route path="/orchestrator" element={<Orchestrator />} />
              <Route path="/fabric" element={<NetworkFabric />} />
              <Route path="/concepts" element={<DSConcepts />} />
            </Routes>
          </main>
        </div>
      </HashRouter>
    </NetworkProvider>
  );
}
