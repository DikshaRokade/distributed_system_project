import React, { useState } from "react";
import { Crown, PowerOff, Power, Loader2 } from "lucide-react";
import { api } from "../api";
import { useNetwork } from "../store";
import { PageHeader, Panel, Button, StatusBadge } from "../components/ui";
import { BLOOD_GROUPS } from "../constants";

export default function NodeManagement() {
  const { nodes, coordinatorId, refreshAll } = useNetwork();
  const [busyId, setBusyId] = useState<string | null>(null);

  async function toggle(id: string, status: string) {
    setBusyId(id);
    try {
      if (status === "healthy") await api.failNode(id);
      else await api.recoverNode(id);
      await refreshAll();
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div>
      <PageHeader title="Node Management" subtitle="Per-node inventory, workload, and manual fault injection" />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {nodes.map((n) => (
          <Panel key={n.id}>
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-white">{n.name}</span>
                {n.id === coordinatorId && <Crown className="w-4 h-4 text-amber-400" />}
                <StatusBadge status={n.status} />
              </div>
              <Button
                variant={n.status === "healthy" ? "danger" : "secondary"}
                onClick={() => toggle(n.id, n.status)}
                disabled={busyId === n.id}
              >
                {busyId === n.id ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin inline mr-1" />
                ) : n.status === "healthy" ? (
                  <PowerOff className="w-3.5 h-3.5 inline mr-1" />
                ) : (
                  <Power className="w-3.5 h-3.5 inline mr-1" />
                )}
                {n.status === "healthy" ? "Simulate Failure" : "Recover Node"}
              </Button>
            </div>

            <div className="text-xs text-slate-400 font-mono mb-3">
              {n.ip}:{n.port} · id: {n.id} · numericId: {n.numericId}
            </div>

            <div className="mb-3">
              <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                <span>Workload</span>
                <span>{n.workload}%</span>
              </div>
              <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full ${n.workload > 75 ? "bg-rose-500" : n.workload > 45 ? "bg-amber-500" : "bg-emerald-500"}`}
                  style={{ width: `${n.workload}%` }}
                />
              </div>
            </div>

            <div className="grid grid-cols-4 gap-2">
              {BLOOD_GROUPS.map((bg) => (
                <div key={bg} className="rounded-lg bg-white/5 px-2 py-1.5 text-center">
                  <div className="text-[10px] text-slate-500">{bg}</div>
                  <div className="text-sm font-bold text-white">{n.inventory[bg] ?? 0}</div>
                  {n.locks[bg] && <div className="text-[9px] text-amber-400 mt-0.5">locked</div>}
                </div>
              ))}
            </div>
          </Panel>
        ))}
      </div>
    </div>
  );
}
