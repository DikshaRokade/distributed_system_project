import React, { useState } from "react";
import { http, api } from "../api";
import { usePoll, useAction } from "../components/hooks";
import { PageHeader, Panel, Button, Input, timeAgo } from "../components/ui";

export default function Beacon() {
  const { data, reload } = usePoll(() => http.get("/beacon"), 700);
  const [iv, setIv] = useState(2000); const [to, setTo] = useState(6000);
  const { error, run } = useAction();
  const act = (fn: () => Promise<any>) => run(fn).then(reload);
  const timeout = data?.timeoutMs || 6000;
  const tone: Record<string, string> = { alive: "border-emerald-500/30 bg-emerald-500/5", suspect: "border-amber-500/40 bg-amber-500/10", failed: "border-rose-500/30 bg-rose-500/10" };

  return (
    <div>
      <PageHeader title="Beacon Protocol" subtitle="Each node periodically broadcasts a beacon. Peers that stop hearing a node's beacons for the timeout declare it failed (and trigger an election if it was the coordinator)." />
      <Panel title="Beacon configuration" className="mb-4">
        <div className="flex flex-wrap items-end gap-3">
          <div><label className="text-xs text-slate-400 block mb-1">Beacon interval (ms)</label><Input type="number" value={iv} onChange={(e) => setIv(Number(e.target.value))} className="w-28" /></div>
          <div><label className="text-xs text-slate-400 block mb-1">Failure timeout (ms)</label><Input type="number" value={to} onChange={(e) => setTo(Number(e.target.value))} className="w-28" /></div>
          <Button onClick={() => act(() => http.post("/beacon/config", { intervalMs: iv, timeoutMs: to }))}>Apply</Button>
          <span className="text-xs text-slate-500">Current: every {data?.intervalMs} ms, timeout {data?.timeoutMs} ms</span>
        </div>
        {error && <div className="text-sm text-rose-400 mt-2">{error}</div>}
      </Panel>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 mb-4">
        {(data?.nodes || []).map((n: any) => (
          <div key={n.id} className={`rounded-xl border p-3 ${tone[n.status]}`}>
            <div className="flex items-center justify-between"><span className="font-semibold text-white text-sm">{n.name}</span><span className="text-[11px] uppercase text-slate-300">{n.status}</span></div>
            <div className="text-xs text-slate-400 mt-2">{n.status === "failed" ? "no beacons" : `last beacon ${(n.agoMs / 1000).toFixed(1)}s ago`}</div>
            <div className="w-full h-1.5 bg-black/30 rounded-full mt-2 overflow-hidden"><div className={`h-full ${n.status === "alive" ? "bg-emerald-500" : "bg-amber-500"}`} style={{ width: `${n.status === "failed" ? 100 : Math.min(100, (n.agoMs / timeout) * 100)}%` }} /></div>
            <div className="text-[10px] text-slate-500 mt-1">timeout bar</div>
            <div className="mt-2">
              {n.status === "failed" ? <Button variant="secondary" className="w-full" onClick={() => act(() => api.recoverNode(n.id))}>Recover node</Button>
                : <Button variant={n.muted ? "secondary" : "danger"} className="w-full" onClick={() => act(() => http.post("/beacon/mute", { nodeId: n.id, muted: !n.muted }))}>{n.muted ? "Resume beacons" : "Silent crash"}</Button>}
            </div>
          </div>
        ))}
      </div>
      <Panel title="Detector events">
        {(data?.events || []).length ? <div className="space-y-1.5 text-xs font-mono">{data.events.map((e: any, i: number) => <div key={i} className={`px-2 py-1.5 rounded-lg bg-black/20 border border-white/5 ${e.kind === "fail" ? "text-rose-300" : e.kind === "ok" ? "text-emerald-300" : "text-amber-300"}`}>{e.text} <span className="text-slate-600">({timeAgo(e.ts)})</span></div>)}</div>
          : <div className="text-sm text-slate-500">No events yet. Press "Silent crash" on a node: it stays up but stops beaconing. After the timeout, the failure is detected automatically.</div>}
      </Panel>
    </div>
  );
}
