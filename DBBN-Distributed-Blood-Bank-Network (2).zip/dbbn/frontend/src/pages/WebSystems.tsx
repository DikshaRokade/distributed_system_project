import React, { useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { http, api } from "../api";
import { usePoll, useAction } from "../components/hooks";
import { PageHeader, Panel, Button, Select, Input, StatCard, timeAgo } from "../components/ui";
import { BLOOD_GROUPS } from "../constants";
import { Gauge, Timer } from "lucide-react";

export default function WebSystems() {
  const { data, reload } = usePoll(() => http.get("/web"), 1000);
  const [bg, setBg] = useState("O-");
  const [last, setLast] = useState<any>(null);
  const [ttl, setTtl] = useState(10000);
  const { error, run } = useAction();
  const act = async (fn: () => Promise<any>) => { const r = await run(fn); await reload(); return r; };
  const cfg = (p: any) => act(() => http.post("/web/config", p));

  return (
    <div>
      <PageHeader title="Distributed Web Systems" subtitle="A reverse proxy at the edge: a load balancer spreads cache misses across origin nodes, and an HTTP-style cache with a TTL serves repeat reads." />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard label="Cache hit ratio" value={`${data?.hitRatio ?? 0}%`} icon={Gauge} tone="success" />
        <StatCard label="Average latency" value={`${data?.avgLatency ?? 0} ms`} icon={Timer} />
        <StatCard label="Hits" value={data?.hits ?? 0} icon={Gauge} tone="success" />
        <StatCard label="Misses (origin requests)" value={data?.misses ?? 0} icon={Gauge} tone="warning" />
      </div>
      <Panel title="Edge configuration" className="mb-4">
        <div className="flex flex-wrap items-end gap-3">
          <div><label className="text-xs text-slate-400 block mb-1">Load-balancing algorithm</label><Select value={data?.algorithm || "round-robin"} onChange={(v) => cfg({ algorithm: v })} options={["round-robin", "least-loaded", "random", "hash"]} /></div>
          <div><label className="text-xs text-slate-400 block mb-1">Cache TTL (ms)</label><Input type="number" value={ttl} onChange={(e) => setTtl(Number(e.target.value))} className="w-28" /></div>
          <Button variant="secondary" onClick={() => cfg({ ttlMs: ttl })}>Set TTL</Button>
          <Button variant={data?.cacheEnabled ? "secondary" : "primary"} onClick={() => cfg({ cacheEnabled: !data?.cacheEnabled })}>Cache: {data?.cacheEnabled ? "ON (click to disable)" : "OFF (click to enable)"}</Button>
          <Button variant="ghost" onClick={() => act(() => http.post("/web/purge"))}>Purge cache</Button>
          <Button variant="ghost" onClick={() => act(() => http.post("/web/reset"))}>Reset stats</Button>
        </div>
      </Panel>
      <Panel title="Send requests" className="mb-4">
        <div className="flex flex-wrap items-end gap-2">
          <Select value={bg} onChange={setBg} options={BLOOD_GROUPS} />
          <Button onClick={async () => { const r = await act(() => http.post("/web/request", { bg })); if (r) setLast(r); }}>GET stock</Button>
          <Button variant="secondary" onClick={() => act(() => http.post("/web/burst", { count: 30 }))}>Burst of 30 requests</Button>
          <Button variant="secondary" onClick={async () => { await act(() => api.reserve("Cache demo hospital", bg, 2)); }}>Reserve 2 units (changes origin data)</Button>
        </div>
        {error && <div className="text-sm text-rose-400 mt-2">{error}</div>}
        {last && <div className={`mt-3 text-sm rounded-lg border p-3 ${last.stale ? "border-amber-500/40 bg-amber-500/10" : "border-white/10 bg-white/5"}`}>
          <span className="font-mono">{last.cache}</span>: {last.bg} = <b className="text-white">{last.value}</b> units, served by {last.servedBy} in {last.latencyMs} ms. {last.stale && <span className="text-amber-300">STALE: real value is now {last.truth}. The cache is eventually consistent until the TTL expires.</span>}
        </div>}
      </Panel>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Panel title="Origin requests per node (load balancing)">
          <ResponsiveContainer width="100%" height={220}><BarChart data={data?.perNode || []}><CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" /><XAxis dataKey="name" stroke="#94a3b8" fontSize={12} /><YAxis stroke="#94a3b8" fontSize={12} allowDecimals={false} /><Tooltip contentStyle={{ background: "#111827", border: "1px solid #ffffff20", borderRadius: 8 }} /><Bar dataKey="requests" fill="#ef4444" radius={[4, 4, 0, 0]} /></BarChart></ResponsiveContainer>
        </Panel>
        <Panel title="Recent requests">
          <div className="max-h-[220px] overflow-y-auto"><table className="w-full text-xs"><tbody>{(data?.log || []).map((l: any, i: number) => (<tr key={i} className="border-b border-white/5"><td className={`py-1 font-mono ${l.cache === "HIT" ? "text-emerald-400" : "text-amber-400"}`}>{l.cache}{l.stale ? " (stale)" : ""}</td><td>{l.bg}</td><td>{l.value}</td><td className="text-slate-400">{l.servedBy}</td><td className="text-slate-500">{l.latencyMs} ms</td><td className="text-slate-600">{timeAgo(l.ts)}</td></tr>))}</tbody></table></div>
        </Panel>
      </div>
    </div>
  );
}
