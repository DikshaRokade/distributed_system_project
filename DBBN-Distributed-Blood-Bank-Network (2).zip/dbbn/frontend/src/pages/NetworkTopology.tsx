import React, { useMemo, useState } from "react";
import { Crown, Server } from "lucide-react";
import { useNetwork } from "../store";
import { PageHeader, Panel, StatusBadge } from "../components/ui";

const CX = 400;
const CY = 260;
const R = 190;

export default function NetworkTopology() {
  const { nodes, coordinatorId } = useNetwork();
  const [selected, setSelected] = useState<string | null>(null);

  const positions = useMemo(() => {
    const n = nodes.length || 5;
    return nodes.map((node, i) => {
      const angle = (Math.PI * 2 * i) / n - Math.PI / 2;
      return { id: node.id, x: CX + R * Math.cos(angle), y: CY + R * Math.sin(angle) };
    });
  }, [nodes]);

  const pos = (id: string) => positions.find((p) => p.id === id) || { x: CX, y: CY };
  const selectedNode = nodes.find((n) => n.id === selected);

  return (
    <div>
      <PageHeader title="Network Topology" subtitle="Middleware-mediated hospital access, coordinator, and peer-to-peer replication links" />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Panel className="lg:col-span-2">
          <svg viewBox="0 0 800 520" className="w-full h-auto">
            {/* P2P mesh links between all healthy nodes */}
            {nodes.map((a, i) =>
              nodes.slice(i + 1).map((b) => {
                if (a.status !== "healthy" || b.status !== "healthy") return null;
                const pa = pos(a.id);
                const pb = pos(b.id);
                return (
                  <line
                    key={`${a.id}-${b.id}`}
                    x1={pa.x}
                    y1={pa.y}
                    x2={pb.x}
                    y2={pb.y}
                    stroke="#14b8a6"
                    strokeOpacity={0.25}
                    strokeWidth={1.5}
                    className="flow-line"
                  />
                );
              })
            )}

            {/* Middleware hub in the center */}
            <g>
              <circle cx={CX} cy={CY} r={44} fill="#1f2937" stroke="#64748b" strokeWidth={1.5} />
              <text x={CX} y={CY - 4} textAnchor="middle" fill="#e2e8f0" fontSize="12" fontWeight={700}>
                Middleware
              </text>
              <text x={CX} y={CY + 12} textAnchor="middle" fill="#94a3b8" fontSize="10">
                API Gateway
              </text>
            </g>

            {/* Spokes from middleware to each node (RPC channel) */}
            {nodes.map((n) => {
              const p = pos(n.id);
              return (
                <line
                  key={`hub-${n.id}`}
                  x1={CX}
                  y1={CY}
                  x2={p.x}
                  y2={p.y}
                  stroke={n.status === "healthy" ? "#38bdf8" : "#f43f5e"}
                  strokeOpacity={0.35}
                  strokeWidth={1.5}
                  strokeDasharray={n.status === "healthy" ? undefined : "4 4"}
                />
              );
            })}

            {/* Nodes */}
            {nodes.map((n) => {
              const p = pos(n.id);
              const isCoordinator = n.id === coordinatorId;
              const isSelected = n.id === selected;
              return (
                <g key={n.id} onClick={() => setSelected(n.id)} className="cursor-pointer">
                  <circle
                    cx={p.x}
                    cy={p.y}
                    r={isSelected ? 40 : 36}
                    fill={n.status === "healthy" ? "#111827" : "#3f0d16"}
                    stroke={isCoordinator ? "#f59e0b" : n.status === "healthy" ? "#10b981" : "#f43f5e"}
                    strokeWidth={isSelected ? 3 : 2}
                  />
                  {isCoordinator && (
                    <g transform={`translate(${p.x - 8}, ${p.y - 54})`}>
                      <Crown className="w-4 h-4" color="#f59e0b" />
                    </g>
                  )}
                  <text x={p.x} y={p.y - 4} textAnchor="middle" fill="#f1f5f9" fontSize="12" fontWeight={700}>
                    {n.name}
                  </text>
                  <text x={p.x} y={p.y + 12} textAnchor="middle" fill={n.status === "healthy" ? "#34d399" : "#fb7185"} fontSize="10">
                    {n.status === "healthy" ? "healthy" : "failed"}
                  </text>
                </g>
              );
            })}
          </svg>
          <div className="flex items-center gap-6 text-xs text-slate-400 mt-2">
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-0.5 bg-sky-400 inline-block" /> RPC channel (middleware ↔ node)
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-0.5 bg-teal-400 inline-block" /> P2P replication mesh
            </span>
            <span className="flex items-center gap-1.5">
              <Crown className="w-3.5 h-3.5 text-amber-400" /> Current coordinator
            </span>
          </div>
        </Panel>

        <Panel title="Node Details">
          {selectedNode ? (
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2">
                <Server className="w-4 h-4 text-slate-400" />
                <span className="font-semibold text-white">{selectedNode.name}</span>
                <StatusBadge status={selectedNode.status} />
              </div>
              <div className="text-slate-400 font-mono text-xs">{selectedNode.ip}:{selectedNode.port}</div>
              <div className="text-slate-400">Node ID: <span className="text-slate-200 font-mono">{selectedNode.id}</span></div>
              <div className="text-slate-400">Numeric ID (election priority): <span className="text-slate-200">{selectedNode.numericId}</span></div>
              <div className="text-slate-400">Workload: <span className="text-slate-200">{selectedNode.workload}%</span></div>
              <div className="text-slate-400">Total inventory: <span className="text-slate-200">{Object.values(selectedNode.inventory).reduce((a: number, b: number) => a + b, 0)} units</span></div>
              {selectedNode.id === coordinatorId && (
                <div className="text-amber-400 text-xs mt-2">★ Acting as network coordinator</div>
              )}
            </div>
          ) : (
            <div className="text-slate-500 text-sm">Click a node in the diagram to see details.</div>
          )}
        </Panel>
      </div>
    </div>
  );
}
