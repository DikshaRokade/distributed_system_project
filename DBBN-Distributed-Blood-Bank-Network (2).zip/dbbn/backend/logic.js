// logic.js — implements the distributed-systems behaviours on top of state.js:
// RPC calls, message-oriented events, distributed locking, replication,
// two-phase-commit-style transactions, and the Bully leader-election algorithm.
const { v4: uuidv4 } = { v4: () => "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
  const r = (Math.random() * 16) | 0;
  const v = c === "x" ? r : (r & 0x3) | 0x8;
  return v.toString(16);
}) };
const state = require("./state");

function sleep(ms) {
  return new Promise((res) => setTimeout(res, ms));
}

function makeLogic(io) {
  function emit(event, payload) {
    io.emit(event, payload);
  }

  function log(entry) {
    const full = { id: uuidv4(), ts: Date.now(), ...entry };
    const s = state.getState();
    s.logs.unshift(full);
    s.logs = s.logs.slice(0, 300);
    state.persist();
    emit("log", full);
    return full;
  }

  function pushDashboard() {
    emit("dashboardUpdate", buildDashboard());
  }

  function buildDashboard() {
    const s = state.getState();
    const totalUnits = s.nodes.reduce(
      (sum, n) => sum + Object.values(n.inventory).reduce((a, b) => a + b, 0),
      0
    );
    return {
      totalUnits,
      activeNodes: s.nodes.filter((n) => n.status === "healthy").length,
      failedNodes: s.nodes.filter((n) => n.status === "failed").length,
      totalNodes: s.nodes.length,
      pendingRequests: s.emergencyRequests.filter((r) => r.status === "pending").length,
      coordinatorId: s.coordinatorId,
      networkHealth: Math.round(
        (s.nodes.filter((n) => n.status === "healthy").length / s.nodes.length) * 100
      ),
      transactionsToday: s.transactions.length,
    };
  }

  // ---- RPC simulation ------------------------------------------------
  // Every "remote call" a node makes goes through this helper so it can be
  // logged uniformly and can fail/timeout when the target node is down.
  async function rpcCall(fromId, toId, method, args) {
    const target = state.getNode(toId);
    const latency = 60 + Math.random() * 180;
    await sleep(latency);
    if (!target || target.status !== "healthy") {
      log({ type: "RPC", from: fromId, to: toId, summary: `${method}() -> TIMEOUT (node unreachable)`, ok: false });
      return { ok: false, error: "NODE_UNREACHABLE" };
    }
    log({ type: "RPC", from: fromId, to: toId, summary: `${method}(${JSON.stringify(args)}) -> OK (${Math.round(latency)}ms)`, ok: true });
    return { ok: true, latencyMs: Math.round(latency), node: target };
  }

  // ---- Distributed computation: parallel blood search -----------------
  async function searchBlood(bloodGroup, units) {
    const nodes = state.healthyNodes();
    log({ type: "MESSAGE", from: "middleware", to: "ALL", summary: `Broadcast search request: ${units} units of ${bloodGroup}` });
    const results = await Promise.all(
      nodes.map(async (n) => {
        const r = await rpcCall("coordinator", n.id, "checkInventory", { bloodGroup });
        if (!r.ok) return { nodeId: n.id, name: n.name, available: 0, unreachable: true };
        return { nodeId: n.id, name: n.name, available: n.inventory[bloodGroup] || 0, unreachable: false };
      })
    );
    results.sort((a, b) => b.available - a.available);
    pushDashboard();
    return results;
  }

  // ---- Distributed locking --------------------------------------------
  function tryAcquireLock(nodeId, bloodGroup) {
    const node = state.getNode(nodeId);
    if (!node) return false;
    if (node.locks[bloodGroup]) return false;
    node.locks[bloodGroup] = true;
    state.persist();
    return true;
  }
  function releaseLock(nodeId, bloodGroup) {
    const node = state.getNode(nodeId);
    if (node) {
      delete node.locks[bloodGroup];
      state.persist();
    }
  }

  // ---- Replication -------------------------------------------------
  async function replicateUpdate(primaryId, bloodGroup, delta) {
    const s = state.getState();
    const others = s.nodes.filter((n) => n.id !== primaryId && n.status === "healthy");
    const results = [];
    for (const n of others) {
      await sleep(40 + Math.random() * 80);
      const entry = { ts: Date.now(), from: primaryId, to: n.id, bloodGroup, delta, status: "synced" };
      s.replicationLog.unshift(entry);
      s.replicationLog = s.replicationLog.slice(0, 200);
      results.push(entry);
      log({ type: "P2P", from: primaryId, to: n.id, summary: `Replicate ${bloodGroup} delta ${delta} (P2P sync)`, ok: true });
      emit("replicationUpdate", entry);
    }
    state.persist();
    return results;
  }

  // ---- Distributed transaction: reserve -> update -> replicate -> commit
  async function reserveBlood({ hospital, bloodGroup, units }) {
    const s = state.getState();
    const txn = {
      id: uuidv4(),
      hospital,
      bloodGroup,
      units,
      status: "pending",
      steps: [],
      createdAt: Date.now(),
    };
    s.transactions.unshift(txn);
    state.persist();
    emit("transactionUpdate", txn);

    const step = (name, status, detail) => {
      txn.steps.push({ name, status, detail, ts: Date.now() });
      state.persist();
      emit("transactionUpdate", txn);
    };

    step("Search", "running", "Querying nodes for availability");
    const results = await searchBlood(bloodGroup, units);
    const candidate = results.find((r) => !r.unreachable && r.available >= units);

    if (!candidate) {
      txn.status = "rolled_back";
      step("Search", "failed", "No single node has sufficient stock");
      pushDashboard();
      return txn;
    }
    step("Search", "done", `Selected ${candidate.name} (${candidate.available} units available)`);

    txn.status = "preparing";
    step("Lock", "running", `Acquiring distributed lock on ${candidate.name}`);
    const gotLock = tryAcquireLock(candidate.nodeId, bloodGroup);
    if (!gotLock) {
      txn.status = "rolled_back";
      step("Lock", "failed", "Resource is locked by a concurrent transaction");
      pushDashboard();
      return txn;
    }
    step("Lock", "done", "Lock acquired");

    try {
      step("Reserve", "running", `RPC reserveBlood(${bloodGroup}, ${units}) -> ${candidate.name}`);
      const rpcRes = await rpcCall("coordinator", candidate.nodeId, "reserveBlood", { bloodGroup, units });
      const node = state.getNode(candidate.nodeId);
      if (!rpcRes.ok || !node || node.inventory[bloodGroup] < units) {
        step("Reserve", "failed", "Node unreachable or insufficient stock at commit time");
        txn.status = "rolled_back";
        return txn;
      }
      step("Reserve", "done", "Units reserved on primary node");

      step("UpdateInventory", "running", "Applying inventory delta on primary");
      node.inventory[bloodGroup] -= units;
      node.workload = Math.min(100, node.workload + 5);
      state.persist();
      step("UpdateInventory", "done", `${candidate.name} inventory: ${node.inventory[bloodGroup]} units left`);

      step("Replicate", "running", "Propagating update to replica nodes (P2P)");
      await replicateUpdate(candidate.nodeId, bloodGroup, -units);
      step("Replicate", "done", "All healthy replicas synchronized");

      txn.status = "committed";
      step("Commit", "done", "Transaction committed");
      return txn;
    } finally {
      releaseLock(candidate.nodeId, bloodGroup);
      pushDashboard();
    }
  }

  // ---- Concurrency demo: two hospitals race for the same stock --------
  async function raceReserve({ bloodGroup, units, hospitalA, hospitalB }) {
    const [a, b] = await Promise.all([
      reserveBlood({ hospital: hospitalA, bloodGroup, units }),
      reserveBlood({ hospital: hospitalB, bloodGroup, units }),
    ]);
    return { a, b };
  }

  // ---- Fault tolerance: fail / recover a node --------------------------
  function failNode(nodeId) {
    const node = state.getNode(nodeId);
    if (!node) return null;
    node.status = "failed";
    node.locks = {};
    state.persist();
    log({ type: "MESSAGE", from: "monitor", to: nodeId, summary: `Heartbeat lost — ${node.name} marked FAILED`, ok: false });
    emit("nodeUpdate", node);
    pushDashboard();
    const s = state.getState();
    if (s.coordinatorId === nodeId) {
      // coordinator went down -> trigger election
      runElection(nodeId);
    }
    return node;
  }

  function recoverNode(nodeId) {
    const node = state.getNode(nodeId);
    if (!node) return null;
    node.status = "healthy";
    node.lastHeartbeat = Date.now();
    state.persist();
    log({ type: "MESSAGE", from: nodeId, to: "ALL", summary: `${node.name} recovered — resynchronizing state (P2P pull)`, ok: true });
    emit("nodeUpdate", node);
    pushDashboard();
    return node;
  }

  // ---- Bully leader election --------------------------------------------
  async function runElection(failedCoordinatorId) {
    const s = state.getState();
    const candidates = s.nodes.filter((n) => n.status === "healthy");
    const election = { id: uuidv4(), startedAt: Date.now(), messages: [], failedCoordinatorId, newCoordinatorId: null };
    s.electionHistory.unshift(election);
    emit("electionUpdate", { election, phase: "started" });
    log({ type: "ELECTION", from: "system", to: "ALL", summary: `Coordinator ${failedCoordinatorId} unreachable — starting Bully election`, ok: false });

    // Every healthy node with a lower id sends ELECTION to higher-id nodes.
    const sorted = [...candidates].sort((a, b) => a.numericId - b.numericId);
    for (const node of sorted) {
      const higher = sorted.filter((n) => n.numericId > node.numericId);
      for (const h of higher) {
        await sleep(80);
        const msg = { ts: Date.now(), from: node.id, to: h.id, type: "ELECTION" };
        election.messages.push(msg);
        emit("electionUpdate", { election, phase: "message", msg });
        log({ type: "ELECTION", from: node.id, to: h.id, summary: "ELECTION message", ok: true });
      }
    }
    await sleep(150);
    const winner = sorted[sorted.length - 1]; // highest numericId among healthy nodes
    if (winner) {
      s.coordinatorId = winner.id;
      state.persist();
      const msg = { ts: Date.now(), from: winner.id, to: "ALL", type: "COORDINATOR" };
      election.messages.push(msg);
      election.newCoordinatorId = winner.id;
      emit("electionUpdate", { election, phase: "elected", winnerId: winner.id });
      log({ type: "ELECTION", from: winner.id, to: "ALL", summary: `${winner.name} announces itself as new COORDINATOR`, ok: true });
    }
    state.persist();
    pushDashboard();
    return election;
  }

  // ---- Emergency requests + shortage broadcast --------------------------
  function createEmergencyRequest({ hospital, bloodGroup, units, notes }) {
    const s = state.getState();
    const req = { id: uuidv4(), hospital, bloodGroup, units, notes: notes || "", status: "pending", createdAt: Date.now() };
    s.emergencyRequests.unshift(req);
    state.persist();
    log({ type: "MESSAGE", from: hospital || "hospital", to: "middleware", summary: `Emergency request: ${units} units ${bloodGroup}`, ok: true });
    emit("emergencyUpdate", req);

    const s2 = state.getState();
    const totalAvailable = s2.nodes
      .filter((n) => n.status === "healthy")
      .reduce((sum, n) => sum + (n.inventory[bloodGroup] || 0), 0);
    if (totalAvailable < units) {
      const broadcast = {
        id: uuidv4(),
        ts: Date.now(),
        bloodGroup,
        shortfall: units - totalAvailable,
        message: `SHORTAGE ALERT: Network-wide ${bloodGroup} stock (${totalAvailable}) is below emergency demand (${units}).`,
      };
      s2.broadcasts.unshift(broadcast);
      state.persist();
      emit("broadcast", broadcast);
      log({ type: "MESSAGE", from: "middleware", to: "ALL", summary: `Distributed multimedia broadcast: shortage alert for ${bloodGroup}`, ok: false });
    }
    pushDashboard();
    return req;
  }

  async function resolveEmergencyRequest(id) {
    const s = state.getState();
    const req = s.emergencyRequests.find((r) => r.id === id);
    if (!req) return null;
    const txn = await reserveBlood({ hospital: req.hospital, bloodGroup: req.bloodGroup, units: req.units });
    req.status = txn.status === "committed" ? "fulfilled" : "unresolved";
    req.transactionId = txn.id;
    state.persist();
    emit("emergencyUpdate", req);
    return { req, txn };
  }

  return {
    buildDashboard,
    pushDashboard,
    log,
    rpcCall,
    searchBlood,
    reserveBlood,
    raceReserve,
    failNode,
    recoverNode,
    runElection,
    createEmergencyRequest,
    resolveEmergencyRequest,
    replicateUpdate,
  };
}

module.exports = { makeLogic };
