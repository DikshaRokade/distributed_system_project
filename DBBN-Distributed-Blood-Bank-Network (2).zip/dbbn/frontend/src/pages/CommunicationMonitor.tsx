import React, { useMemo, useState } from "react";
import { useNetwork } from "../store";
import { PageHeader, Panel } from "../components/ui";
import LogFeed from "../components/LogFeed";

const TYPES = ["ALL", "RPC", "MESSAGE", "P2P", "ELECTION"] as const;

export default function CommunicationMonitor() {
  const { logs } = useNetwork();
  const [filter, setFilter] = useState<(typeof TYPES)[number]>("ALL");

  const filtered = useMemo(() => (filter === "ALL" ? logs : logs.filter((l) => l.type === filter)), [logs, filter]);

  const counts = useMemo(() => {
    const c: Record<string, number> = { RPC: 0, MESSAGE: 0, P2P: 0, ELECTION: 0 };
    logs.forEach((l) => (c[l.type] = (c[l.type] || 0) + 1));
    return c;
  }, [logs]);

  return (
    <div>
      <PageHeader title="Communication Monitor" subtitle="Every RPC call, asynchronous message, P2P sync, and election message crossing the network" />

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
        {(["RPC", "MESSAGE", "P2P", "ELECTION"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setFilter(t)}
            className={`text-left rounded-xl p-3 border transition-colors ${
              filter === t ? "border-blood-500 bg-blood-500/10" : "border-white/5 bg-ink-800/60 hover:bg-white/5"
            }`}
          >
            <div className="text-xs text-slate-400">{t}</div>
            <div className="text-xl font-bold text-white">{counts[t] || 0}</div>
          </button>
        ))}
      </div>

      <Panel
        title="Event Stream"
        right={
          <button onClick={() => setFilter("ALL")} className={`text-xs ${filter === "ALL" ? "text-blood-400" : "text-slate-500"}`}>
            show all
          </button>
        }
      >
        <LogFeed logs={filtered} max={200} />
      </Panel>
    </div>
  );
}
