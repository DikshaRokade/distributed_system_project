import React from "react";
import { PageHeader, Panel } from "../components/ui";

const rows: { topic: string; implementation: string; where: string }[] = [
  {
    topic: "Distributed Architecture",
    implementation: "5 independent blood-bank nodes (Pune, Mumbai, Nashik, Nagpur, Kolhapur), each with its own inventory, ID, and simulated IP/port.",
    where: "backend/state.js",
  },
  {
    topic: "Middleware",
    implementation: "Express API gateway sits between hospitals (frontend) and nodes — every request is routed and logged through it before reaching a node.",
    where: "backend/server.js",
  },
  {
    topic: "RPC (Remote Procedure Call)",
    implementation: "checkInventory(), reserveBlood(), updateInventory() are invoked as simulated remote calls (rpcCall) with latency and failure handling.",
    where: "backend/logic.js — rpcCall()",
  },
  {
    topic: "Message-Oriented Communication",
    implementation: "Asynchronous MESSAGE events (search broadcasts, heartbeat loss, emergency requests) are logged independently of any direct RPC response.",
    where: "backend/logic.js — log() calls tagged MESSAGE",
  },
  {
    topic: "P2P Communication",
    implementation: "After a primary node commits an update, it synchronizes the delta directly to every other healthy node (peer-to-peer, not via the coordinator).",
    where: "backend/logic.js — replicateUpdate()",
  },
  {
    topic: "Names, Identifiers & Addresses",
    implementation: "A service registry maps logical node names (e.g. 'pune') to Node ID, simulated IP and port — resolved before any RPC call.",
    where: "backend/state.js — registry",
  },
  {
    topic: "Distributed Computation",
    implementation: "Blood search fans out checkInventory() to every healthy node in parallel (Promise.all) and aggregates the results before responding.",
    where: "backend/logic.js — searchBlood()",
  },
  {
    topic: "Replication",
    implementation: "Every committed inventory change is replicated to all healthy peer nodes; the Replication Monitor shows the live sync log.",
    where: "backend/logic.js — replicateUpdate()",
  },
  {
    topic: "Concurrency & Synchronization",
    implementation: "A per-node, per-blood-group distributed lock ensures only one concurrent transaction can reserve the same stock at a time.",
    where: "backend/logic.js — tryAcquireLock() / releaseLock()",
  },
  {
    topic: "Fault Tolerance",
    implementation: "Nodes can be manually failed; the middleware stops routing to them and continues serving requests from the remaining healthy nodes.",
    where: "backend/logic.js — failNode() / recoverNode()",
  },
  {
    topic: "Leader Election (Bully Algorithm)",
    implementation: "When the coordinator fails, healthy nodes exchange ELECTION messages; the highest-numericId healthy node declares itself COORDINATOR.",
    where: "backend/logic.js — runElection()",
  },
  {
    topic: "Virtualization",
    implementation: "Each node is presented as an isolated virtual container with its own simulated CPU, memory, and workload metrics.",
    where: "frontend — Virtual Infrastructure page",
  },
  {
    topic: "Distributed Transactions",
    implementation: "Reservations move through Search → Lock → Reserve → UpdateInventory → Replicate → Commit, rolling back on any step failure.",
    where: "backend/logic.js — reserveBlood()",
  },
  {
    topic: "Distributed Multimedia",
    implementation: "When network-wide stock for a blood group falls below an emergency request's need, a shortage broadcast alert is pushed to all clients.",
    where: "backend/logic.js — createEmergencyRequest()",
  },
];


const unit3 = [
  { topic: "Clock Synchronization", implementation: "Cristian's algorithm (sync one node against a time server using RTT/2) and Berkeley's algorithm (coordinator averages all clocks and sends relative adjustments, ignoring outliers).", where: "sync.js: cristian(), berkeley() | Clock Synchronization page" },
  { topic: "Logical Clocks and Lamport's Algorithm", implementation: "Every node keeps a Lamport counter: +1 on local/send events, max(local, message)+1 on receive. A space-time diagram shows events and message arrows.", where: "sync.js: sendMsg(), localEvent() | Logical and Vector Clocks page" },
  { topic: "Vector Algorithm (Vector Clocks)", implementation: "Each node keeps a vector with one entry per node, merged element-wise on receive. Two events can be compared to decide happened-before or concurrent, which Lamport clocks cannot do.", where: "sync.js | Logical and Vector Clocks page" },
  { topic: "Global State", implementation: "Chandy-Lamport snapshot: the initiator records its state and sends markers; nodes record on the first marker and record in-flight messages on other channels. The result is checked for unit conservation.", where: "sync.js: snapshotRun() | Global State Snapshot page" },
  { topic: "Election Algorithms", implementation: "Bully algorithm (existing) and Ring algorithm, both selecting the highest-id healthy node as coordinator.", where: "logic.js: runElection(); sync.js: ringElection() | Leader Election page" },
  { topic: "Mutual Exclusion Algorithms", implementation: "Centralized, Ricart-Agrawala (REQUEST/REPLY with deferred replies and timestamp priority) and token ring, all protecting the shared central blood ledger, with message-count comparison.", where: "sync.js: mutexRun() | Mutual Exclusion page" },
  { topic: "Beacon Protocol", implementation: "Each node broadcasts beacons periodically; a monitor declares a node failed after a configurable timeout without beacons (silent crash), which can trigger a coordinator election.", where: "sync.js: beacon timer | Beacon Protocol page" },
  { topic: "Self study: Knapp's classification of deadlock detection", implementation: "Two classes implemented: edge chasing (Chandy-Misra-Haas probes) and a centralized global wait-for graph with cycle detection. Path-pushing and diffusion computation are described in theory only.", where: "sync.js: edgeChase(), sccCycles() | Deadlock Detection page" },
  { topic: "Self study: Lodha and Kshemkalyani fair mutual exclusion", implementation: "Not implemented as code. Ricart-Agrawala here is the base algorithm; the fair variant additionally orders requests by happened-before using vector clocks, which this project already provides.", where: "Theory only" },
];

const unit4 = [
  { topic: "Distributed Object-Based Systems", implementation: "RMI/CORBA-style remote objects: naming service, remote references, client stub marshalling, server skeleton and servant, with RemoteException on node failure.", where: "paradigms.js: objects | Distributed Objects page" },
  { topic: "Distributed Web-Based Systems", implementation: "Reverse proxy with load balancing (round-robin, least-loaded, random, hash) and an HTTP-style cache with TTL, hit ratio, latency and stale reads.", where: "paradigms.js: web | Web Systems page" },
  { topic: "Distributed File System", implementation: "HDFS-style design: NameNode metadata, fixed-size blocks, replication pipeline, read failover, under/over-replication repair.", where: "paradigms.js: dfs | Distributed File System page" },
  { topic: "Serverless Architectures", implementation: "Function-as-a-Service with cold starts, warm container reuse, keep-alive expiry, burst scale-out, concurrency limit and GB-ms billing.", where: "paradigms.js: serverless | Serverless page" },
];

const cases = [
  { topic: "Apache Hadoop", implementation: "HDFS behaviour in the Distributed File System page, and a MapReduce engine (data-local map tasks, combiner, hash-partitioned shuffle, reducers, task rescheduling).", where: "DFS + MapReduce pages" },
  { topic: "Kubernetes", implementation: "Desired-state controller: scheduler, ReplicaSets, self-healing after pod crash or node failure, horizontal autoscaling, rolling updates and service load balancing.", where: "Orchestrator page" },
  { topic: "AWS", implementation: "Lambda-style functions (Serverless page), S3/HDFS-style replicated storage (DFS page) and auto-scaling (Orchestrator page). Concepts are modelled, no AWS services are called.", where: "Serverless, DFS, Orchestrator" },
  { topic: "Cloudflare", implementation: "Edge cache with TTL and load-balanced origins in front of the nodes.", where: "Web Systems page" },
  { topic: "Megaport", implementation: "Software-defined interconnect: a port per node and on-demand virtual cross connects with provisionable and resizable bandwidth, latency by distance and transfer-time test.", where: "Network Fabric page" },
];

function Table({ title, data }: { title: string; data: { topic: string; implementation: string; where: string }[] }) {
  return (
    <Panel title={title} className="mt-6">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead><tr className="text-left text-slate-400 border-b border-white/10"><th className="py-2 pr-4 font-medium w-1/5">Topic</th><th className="py-2 pr-4 font-medium">Implementation</th><th className="py-2 pr-4 font-medium w-1/4">Where</th></tr></thead>
          <tbody>{data.map((r) => (<tr key={r.topic} className="border-b border-white/5 align-top"><td className="py-3 pr-4 text-white font-medium">{r.topic}</td><td className="py-3 pr-4 text-slate-300">{r.implementation}</td><td className="py-3 pr-4 text-slate-500 font-mono text-xs">{r.where}</td></tr>))}</tbody>
        </table>
      </div>
    </Panel>
  );
}

export default function DSConcepts() {
  return (
    <div>
      <PageHeader title="Distributed Systems Concepts" subtitle="Syllabus topic → where and how it's implemented in this project" />
      <Panel>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-slate-400 border-b border-white/10">
                <th className="py-2 pr-4 font-medium w-1/5">Syllabus Topic</th>
                <th className="py-2 pr-4 font-medium">Implementation</th>
                <th className="py-2 pr-4 font-medium w-1/5">Where</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.topic} className="border-b border-white/5 align-top">
                  <td className="py-3 pr-4 text-white font-medium">{r.topic}</td>
                  <td className="py-3 pr-4 text-slate-300">{r.implementation}</td>
                  <td className="py-3 pr-4 text-slate-500 font-mono text-xs">{r.where}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
      <Table title="Unit III: Synchronization" data={unit3} />
      <Table title="Unit IV: Emerging Distributed Paradigms" data={unit4} />
      <Table title="Unit IV case studies and where they appear" data={cases} />
    </div>
  );
}
