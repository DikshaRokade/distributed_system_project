import React, { useState } from "react";
import { http } from "../api";
import { usePoll, useAction } from "../components/hooks";
import { PageHeader, Panel, Button, Select, Input, StatusBadge } from "../components/ui";

export default function NetworkFabric() {
  const { data, reload } = usePoll(() => http.get("/net"), 1500);
  const ports: any[] = data?.ports || [];
  const names = ports.map((p) => p.name);
  const idOf = (n: string) => ports.find((p) => p.name === n)?.id;
  const [a, setA] = useState("Pune"); const [b, setB] = useState("Mumbai"); const [mbps, setMbps] = useState(200);
  const [sizes, setSizes] = useState<Record<number, number>>({});
  const [out, setOut] = useState<Record<number, any>>({});
  const [newSpeed, setNewSpeed] = useState<Record<number, number>>({});
  const { error, run } = useAction();
  const act = async (fn: () => Promise<any>) => { const r = await run(fn); reload(); return r; };
  const cap = data?.portMbps || 1000;

  return (
    <div>
      <PageHeader title="Network Fabric (software-defined interconnect)" subtitle="Megaport-style model: every blood bank has a physical port; Virtual Cross Connects (VXCs) are provisioned on demand between ports with a chosen bandwidth, with no new cabling." />
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 mb-4">
        {ports.map((p) => (
          <div key={p.id} className="bg-ink-800/60 border border-white/5 rounded-xl p-3">
            <div className="flex items-center justify-between"><span className="text-sm font-semibold text-white">{p.name}</span><StatusBadge status={p.status} /></div>
            <div className="w-full h-1.5 bg-white/5 rounded-full mt-2 overflow-hidden"><div className={`h-full ${p.used > cap * 0.8 ? "bg-rose-500" : "bg-sky-500"}`} style={{ width: `${(p.used / cap) * 100}%` }} /></div>
            <div className="text-[11px] text-slate-500 mt-1">{p.used} / {cap} Mbps provisioned</div>
          </div>
        ))}
      </div>
      <Panel title="Provision a Virtual Cross Connect" className="mb-4">
        <div className="flex flex-wrap items-end gap-2">
          <Select value={a} onChange={setA} options={names} /><span className="text-slate-500 pb-1.5">to</span><Select value={b} onChange={setB} options={names} />
          <Input type="number" min={10} step={50} value={mbps} onChange={(e) => setMbps(Number(e.target.value))} className="w-24" /><span className="text-slate-500 pb-1.5 text-sm">Mbps</span>
          <Button onClick={() => act(() => http.post("/net/vxc", { a: idOf(a), b: idOf(b), mbps }))}>Provision</Button>
        </div>
        {error && <div className="text-sm text-rose-400 mt-2">{error}</div>}
      </Panel>
      <Panel title="Active VXCs">
        <div className="space-y-3">
          {(data?.vxcs || []).map((v: any) => (
            <div key={v.id} className="rounded-xl border border-white/10 bg-white/5 p-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="text-sm text-white font-semibold">VXC-{v.id}: {v.aName} to {v.bName} <span className="text-xs text-slate-500 font-normal">{v.km} km, RTT {v.rttMs} ms</span></div>
                <div className="flex items-center gap-2"><span className={`text-xs ${v.state === "LIVE" ? "text-emerald-400" : "text-rose-400"}`}>{v.state}</span><span className="text-sm text-slate-300">{v.mbps} Mbps</span><span className="text-xs text-slate-500">demo rate ${v.costPerHour}/h</span></div>
              </div>
              <div className="flex flex-wrap items-end gap-2 mt-2">
                <Input type="number" placeholder="new Mbps" value={newSpeed[v.id] || ""} onChange={(e) => setNewSpeed({ ...newSpeed, [v.id]: Number(e.target.value) })} className="w-24" />
                <Button variant="secondary" onClick={() => act(() => http.post("/net/resize", { id: v.id, mbps: newSpeed[v.id] }))}>Resize</Button>
                <Input type="number" value={sizes[v.id] ?? 500} onChange={(e) => setSizes({ ...sizes, [v.id]: Number(e.target.value) })} className="w-20" /><span className="text-xs text-slate-500 pb-2">MB</span>
                <Button variant="secondary" onClick={async () => { const r = await act(() => http.post("/net/transfer", { id: v.id, sizeMB: sizes[v.id] ?? 500 })); if (r) setOut({ ...out, [v.id]: r }); }}>Test transfer</Button>
                <Button variant="ghost" onClick={() => act(() => http.post("/net/delete", { id: v.id }))}>Delete</Button>
                {out[v.id] && <span className="text-xs text-sky-300 font-mono pb-2">{out[v.id].sizeMB} MB in {out[v.id].seconds}s ({out[v.id].effectiveMbps} Mbps effective)</span>}
              </div>
            </div>
          ))}
          {!(data?.vxcs || []).length && <div className="text-sm text-slate-500">No VXCs yet. Provision one above, then resize it to see on-demand bandwidth.</div>}
        </div>
      </Panel>
    </div>
  );
}
