import React, { useEffect, useRef, useState } from "react";

export interface Step { text: string; kind?: string; from?: string; to?: string }

const color: Record<string, string> = {
  request: "text-sky-400 border-sky-500/30 bg-sky-500/10",
  probe: "text-sky-400 border-sky-500/30 bg-sky-500/10",
  reply: "text-emerald-400 border-emerald-500/30 bg-emerald-500/10",
  defer: "text-amber-400 border-amber-500/30 bg-amber-500/10",
  election: "text-amber-400 border-amber-500/30 bg-amber-500/10",
  enter: "text-violet-400 border-violet-500/30 bg-violet-500/10",
  exit: "text-slate-300 border-slate-500/30 bg-slate-500/10",
  token: "text-teal-400 border-teal-500/30 bg-teal-500/10",
  deadlock: "text-rose-400 border-rose-500/30 bg-rose-500/10",
  info: "text-slate-400 border-slate-600/40 bg-slate-500/5",
};

// Reveals the steps of an algorithm trace one by one so the protocol can be followed live.
export default function StepPlayer({ steps, speed = 450, title }: { steps: Step[]; speed?: number; title?: string }) {
  const [n, setN] = useState(0);
  const endRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    setN(0);
    if (!steps.length) return;
    const t = setInterval(() => setN((x) => { if (x >= steps.length) { clearInterval(t); return x; } return x + 1; }), speed);
    return () => clearInterval(t);
  }, [steps, speed]);
  useEffect(() => { endRef.current?.scrollIntoView({ block: "nearest" }); }, [n]);
  if (!steps.length) return <div className="text-sm text-slate-500 py-6 text-center">Run the algorithm to see its step-by-step trace here.</div>;
  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs text-slate-500">{title || "Protocol trace"} ({Math.min(n, steps.length)}/{steps.length})</span>
        <div className="flex gap-3 text-xs">
          <button className="text-slate-400 hover:text-white" onClick={() => setN(0)}>Replay</button>
          <button className="text-slate-400 hover:text-white" onClick={() => setN(steps.length)}>Show all</button>
        </div>
      </div>
      <div className="space-y-1.5 max-h-[420px] overflow-y-auto pr-1 text-xs">
        {steps.slice(0, n).map((s, i) => (
          <div key={i} className="log-enter flex items-start gap-2 px-2 py-1.5 rounded-lg bg-black/20 border border-white/5">
            <span className={`shrink-0 px-1.5 py-0.5 rounded border text-[10px] font-semibold uppercase ${color[s.kind || "info"] || color.info}`}>{s.kind || "info"}</span>
            <span className="text-slate-300 font-mono">{s.text}</span>
          </div>
        ))}
        <div ref={endRef} />
      </div>
    </div>
  );
}
