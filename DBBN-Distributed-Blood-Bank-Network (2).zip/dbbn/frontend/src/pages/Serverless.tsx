import React, { useState } from "react";
import { http } from "../api";
import { usePoll, useAction } from "../components/hooks";
import { PageHeader, Panel, Button, Select, Input, StatCard, timeAgo } from "../components/ui";
import { Zap, Snowflake, Flame, Coins } from "lucide-react";

export default function Serverless() {
  const { data, reload } = usePoll(() => http.get("/serverless"), 1000);
  const fns: any[] = data?.functions || [];
  const [fn, setFn] = useState("checkCompatibility");
  const cur = fns.find((f) => f.name === fn) || fns[0];
  const [event, setEvent] = useState('{"donor":"O-","recipient":"AB+"}');
  const [count, setCount] = useState(10);
  const [keep, setKeep] = useState(30000);
  const [last, setLast] = useState<any>(null);
  const { error, run } = useAction();
  const parse = () => { try { return JSON.parse(event); } catch { return null; } };
  const act = async (fn2: () => Promise<any>) => { const r = await run(fn2); reload(); return r; };
  const st = data?.stats || {};

  return (
    <div>
      <PageHeader title="Serverless (Function-as-a-Service)" subtitle="Functions run in short-lived containers placed on healthy nodes. The first call pays a cold start; later calls reuse a warm container; bursts scale out; you pay per execution time." />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <StatCard label="Invocations" value={st.invocations ?? 0} icon={Zap} />
        <StatCard label="Cold starts" value={st.cold ?? 0} icon={Snowflake} tone="warning" />
        <StatCard label="Warm hits" value={st.warm ?? 0} icon={Flame} tone="success" />
        <StatCard label="Billed GB-ms" value={(st.gbMs ?? 0).toFixed(1)} icon={Coins} hint={`demo cost estimate $${st.estCostUsd ?? 0}`} />
      </div>
      <Panel title="Invoke" className="mb-4">
        <div className="flex flex-wrap items-end gap-3">
          <div><label className="text-xs text-slate-400 block mb-1">Function ({cur?.memoryMB} MB)</label><Select value={fn} onChange={(v) => { setFn(v); setEvent(JSON.stringify(fns.find((f) => f.name === v)?.sample)); }} options={fns.map((f) => f.name)} /></div>
          <div className="flex-1 min-w-[260px]"><label className="text-xs text-slate-400 block mb-1">Event (JSON)</label><Input value={event} onChange={(e) => setEvent(e.target.value)} className="w-full font-mono" /></div>
          <Button onClick={async () => { const ev = parse(); if (!ev) return; const r = await act(() => http.post("/serverless/invoke", { fn, event: ev })); if (r) setLast(r.invocation); }}>Invoke once</Button>
          <div className="flex items-end gap-1"><Input type="number" min={1} max={40} value={count} onChange={(e) => setCount(Number(e.target.value))} className="w-20" /><Button variant="secondary" onClick={() => { const ev = parse(); if (ev) act(() => http.post("/serverless/burst", { fn, event: ev, count })); }}>Burst (parallel)</Button></div>
        </div>
        {error && <div className="text-sm text-rose-400 mt-2">{error}</div>}
        {last && <div className="mt-3 text-sm rounded-lg border border-white/10 bg-white/5 p-3 font-mono">{last.cold ? "COLD START" : "WARM"} on {last.node} ({last.container}): init {last.initMs} ms + run {last.execMs} ms. Result: {last.error ? <span className="text-rose-400">{last.error}</span> : JSON.stringify(last.result)}</div>}
      </Panel>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Panel title="Container pool" right={<div className="flex items-center gap-2 text-xs"><span className="text-slate-500">keep-alive ms</span><Input type="number" value={keep} onChange={(e) => setKeep(Number(e.target.value))} className="w-24" /><button className="text-sky-400" onClick={() => act(() => http.post("/serverless/config", { keepAliveMs: keep }))}>set</button><button className="text-slate-500" onClick={() => act(() => http.post("/serverless/reset"))}>reset</button></div>}>
          <table className="w-full text-xs"><thead><tr className="text-left text-slate-400 border-b border-white/10"><th className="py-1">Container</th><th>Function</th><th>Node</th><th>State</th><th>Calls</th></tr></thead>
            <tbody>{(data?.containers || []).map((c: any) => <tr key={c.id} className="border-b border-white/5"><td className="py-1 font-mono">{c.id}</td><td>{c.fn}</td><td>{c.node}</td><td className={c.state === "busy" ? "text-amber-400" : "text-emerald-400"}>{c.state}{c.state === "idle" ? ` ${(c.idleMs / 1000).toFixed(0)}s` : ""}</td><td>{c.invocations}</td></tr>)}</tbody></table>
          {!(data?.containers || []).length && <div className="text-sm text-slate-500 py-3">No containers running (scaled to zero).</div>}
        </Panel>
        <Panel title="Invocation log">
          <div className="max-h-[300px] overflow-y-auto"><table className="w-full text-xs"><tbody>{(data?.log || []).map((l: any, i: number) => <tr key={i} className="border-b border-white/5"><td className={`py-1 font-mono ${l.throttled ? "text-rose-400" : l.cold ? "text-sky-400" : "text-emerald-400"}`}>{l.throttled ? "THROTTLED" : l.cold ? "COLD" : "WARM"}</td><td>{l.fn}</td><td className="text-slate-500">{l.node}</td><td className="text-slate-500">{l.throttled ? "" : `${l.initMs + l.execMs} ms`}</td><td className="text-slate-600">{timeAgo(l.ts)}</td></tr>)}</tbody></table></div>
        </Panel>
      </div>
    </div>
  );
}
