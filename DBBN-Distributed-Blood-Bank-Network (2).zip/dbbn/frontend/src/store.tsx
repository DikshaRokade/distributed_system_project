import React, { createContext, useContext, useEffect, useRef, useState } from "react";
import { socket } from "./socket";
import { api } from "./api";
import type {
  Broadcast,
  Dashboard,
  DBNode,
  Election,
  EmergencyRequest,
  LogEntry,
  NetworkState,
  ReplicationEntry,
  Transaction,
} from "./types";

interface Ctx {
  nodes: DBNode[];
  coordinatorId: string;
  logs: LogEntry[];
  transactions: Transaction[];
  emergencyRequests: EmergencyRequest[];
  electionHistory: Election[];
  replicationLog: ReplicationEntry[];
  broadcasts: Broadcast[];
  dashboard: Dashboard | null;
  connected: boolean;
  refreshAll: () => Promise<void>;
}

const NetworkContext = createContext<Ctx | null>(null);

export function NetworkProvider({ children }: { children: React.ReactNode }) {
  const [nodes, setNodes] = useState<DBNode[]>([]);
  const [coordinatorId, setCoordinatorId] = useState("");
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [emergencyRequests, setEmergencyRequests] = useState<EmergencyRequest[]>([]);
  const [electionHistory, setElectionHistory] = useState<Election[]>([]);
  const [replicationLog, setReplicationLog] = useState<ReplicationEntry[]>([]);
  const [broadcasts, setBroadcasts] = useState<Broadcast[]>([]);
  const [dashboard, setDashboard] = useState<Dashboard | null>(null);
  const [connected, setConnected] = useState(false);
  const bootstrapped = useRef(false);

  const applyBootstrap = (s: NetworkState) => {
    setNodes(s.nodes);
    setCoordinatorId(s.coordinatorId);
    setLogs(s.logs || []);
    setTransactions(s.transactions || []);
    setEmergencyRequests(s.emergencyRequests || []);
    setElectionHistory(s.electionHistory || []);
    setReplicationLog(s.replicationLog || []);
    setBroadcasts(s.broadcasts || []);
    bootstrapped.current = true;
  };

  const refreshAll = async () => {
    try {
      const [n, c, l, t, e, el, r, b, d] = await Promise.all([
        api.nodes(),
        api.coordinator(),
        api.logs(),
        api.transactions(),
        api.emergencyRequests(),
        api.elections(),
        api.replicationLog(),
        api.broadcasts(),
        api.dashboard(),
      ]);
      setNodes(n);
      setCoordinatorId(c.coordinatorId);
      setLogs(l);
      setTransactions(t);
      setEmergencyRequests(e);
      setElectionHistory(el);
      setReplicationLog(r);
      setBroadcasts(b);
      setDashboard(d);
      bootstrapped.current = true;
    } catch (err) {
      console.error("Failed to reach DBBN backend API", err);
    }
  };

  useEffect(() => {
    refreshAll();

    function onConnect() {
      setConnected(true);
    }
    function onDisconnect() {
      setConnected(false);
    }
    function onBootstrap(s: NetworkState) {
      applyBootstrap(s);
    }
    function onDashboard(d: Dashboard) {
      setDashboard(d);
      setCoordinatorId(d.coordinatorId);
    }
    function onNodeUpdate(node: DBNode) {
      setNodes((prev) => prev.map((n) => (n.id === node.id ? node : n)));
    }
    function onLog(entry: LogEntry) {
      setLogs((prev) => [entry, ...prev].slice(0, 300));
    }
    function onTransactionUpdate(txn: Transaction) {
      setTransactions((prev) => {
        const idx = prev.findIndex((t) => t.id === txn.id);
        if (idx === -1) return [txn, ...prev];
        const copy = [...prev];
        copy[idx] = txn;
        return copy;
      });
    }
    function onEmergencyUpdate(reqObj: EmergencyRequest) {
      setEmergencyRequests((prev) => {
        const idx = prev.findIndex((r) => r.id === reqObj.id);
        if (idx === -1) return [reqObj, ...prev];
        const copy = [...prev];
        copy[idx] = reqObj;
        return copy;
      });
    }
    function onElectionUpdate(payload: { election: Election }) {
      setElectionHistory((prev) => {
        const idx = prev.findIndex((e) => e.id === payload.election.id);
        if (idx === -1) return [payload.election, ...prev];
        const copy = [...prev];
        copy[idx] = payload.election;
        return copy;
      });
    }
    function onReplicationUpdate(entry: ReplicationEntry) {
      setReplicationLog((prev) => [entry, ...prev].slice(0, 200));
    }
    function onBroadcast(b: Broadcast) {
      setBroadcasts((prev) => [b, ...prev]);
    }

    socket.on("connect", onConnect);
    socket.on("disconnect", onDisconnect);
    socket.on("bootstrap", onBootstrap);
    socket.on("dashboardUpdate", onDashboard);
    socket.on("nodeUpdate", onNodeUpdate);
    socket.on("log", onLog);
    socket.on("transactionUpdate", onTransactionUpdate);
    socket.on("emergencyUpdate", onEmergencyUpdate);
    socket.on("electionUpdate", onElectionUpdate);
    socket.on("replicationUpdate", onReplicationUpdate);
    socket.on("broadcast", onBroadcast);

    return () => {
      socket.off("connect", onConnect);
      socket.off("disconnect", onDisconnect);
      socket.off("bootstrap", onBootstrap);
      socket.off("dashboardUpdate", onDashboard);
      socket.off("nodeUpdate", onNodeUpdate);
      socket.off("log", onLog);
      socket.off("transactionUpdate", onTransactionUpdate);
      socket.off("emergencyUpdate", onEmergencyUpdate);
      socket.off("electionUpdate", onElectionUpdate);
      socket.off("replicationUpdate", onReplicationUpdate);
      socket.off("broadcast", onBroadcast);
    };
  }, []);

  return (
    <NetworkContext.Provider
      value={{
        nodes,
        coordinatorId,
        logs,
        transactions,
        emergencyRequests,
        electionHistory,
        replicationLog,
        broadcasts,
        dashboard,
        connected,
        refreshAll,
      }}
    >
      {children}
    </NetworkContext.Provider>
  );
}

export function useNetwork() {
  const ctx = useContext(NetworkContext);
  if (!ctx) throw new Error("useNetwork must be used within NetworkProvider");
  return ctx;
}
