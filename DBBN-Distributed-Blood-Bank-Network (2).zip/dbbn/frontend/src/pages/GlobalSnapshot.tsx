import React, { useState } from "react";
import { http } from "../api";
import { usePoll, useAction } from "../components/hooks";
import { PageHeader, Panel, Button, Select, Input } from "../components/ui";
import StepPlayer from "../components/StepPlayer";
import { BLOOD_GROUPS } from "../constants";

export default function GlobalSnapshot() {
  const { data, reload } = usePoll(() => http.get("/snapshot"), 2000);
  const nodes: any[] = data?.nodes || [];
  const names = nodes.map((n) => n.name);
  const idOf = (name: string) => nodes.find((n) => n.name === name)?.id;
  const [from, setFrom] = useState("Pune"); const [to, setTo] = useState("Nagpur");
  const [bg, setBg] = useState("O-"); const [units, setUnits] = useState(3);
  const [init, setInit] = useState("Mumbai");
  const [snap, setSnap] = useState<any>(null);
  const { error, run } = useAction();
  const act = (fn: () => Promise<any>) => run(fn).then(reload);
  const inflight = (data?.transfers || []).reduce((x: number, t: any) => x + t.units, 0);

  return (
    <div>
      <PageHeader title="Global State: Chandy-Lamport Snapshot" subtitle="Record a consistent global state (node states plus messages in transit) without stopping the system." />
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 mb-4">
        {nodes.map((n) => (<div key={n.id} className="bg-ink-800/60 border border-white/5 rounded-xl p-3"><div className="text-xs text-slate-400">{n.name}</div><div className="text-xl font-bold text-white">{n.units}</div><div className="text-[11px] text-slate-500">units in stock</div></div>))}
      </div>
      <Panel title="1. Create messages in flight (inter-node blood transfers)" className="mb-4">
        <div className="flex flex-wrap items-end gap-2">
          <Select value={from} onChange={setFrom} options={names} /><span className="text-slate-500 pb-1.5">to</span><Select value={to} onChange={setTo} options={names} />
          <Select value={bg} onChange={setBg} options={BLOOD_GROUPS} /><Input type="number" min={1} value={units} onChange={(e) => setUnits(Number(e.target.value))} className="w-20" />
          <Button onClick={() => act(() => http.post("/snapshot/transfer", { from: idOf(from), to: idOf(to), bloodGroup: bg, units }))}>Send transfer</Button>
          <Button variant="secondary" onClick={() => act(() => http.post("/snapshot/random", { count: 4 }))}>Add 4 random transfers</Button>
          <Button variant="ghost" onClick={() => act(() => http.post("/snapshot/deliver"))}>Deliver all</Button>
        </div>
        <div className="text-xs text-slate-400 mt-3">In flight now: {(data?.transfers || []).length} message(s), {inflight} units. These units have left the sender but not yet reached the receiver.</div>
        {(data?.transfers || []).length > 0 && <div className="flex flex-wrap gap-2 mt-2">{data.transfers.map((t: any) => <span key={t.id} className="text-[11px] px-2 py-0.5 rounded-full border border-amber-500/30 text-amber-300 bg-amber-500/5">{t.fromName} to {t.toName}: {t.units} x {t.bloodGroup}</span>)}</div>}
      </Panel>
      <Panel title="2. Run the snapshot" className="mb-4">
        <div className="flex items-end gap-2"><Select value={init} onChange={setInit} options={names} /><Button onClick={async () => { const r = await run(() => http.post("/snapshot/run", { initiator: idOf(init) })); if (r) setSnap(r); }}>Start snapshot from this node</Button></div>
        {error && <div className="text-sm text-rose-400 mt-2">{error}</div>}
      </Panel>
      {snap && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Panel title="Marker propagation"><StepPlayer steps={snap.steps} speed={350} /></Panel>
          <Panel title="Recorded global state">
            <table className="w-full text-sm mb-3"><thead><tr className="text-left text-slate-400 border-b border-white/10"><th className="py-1.5">Component</th><th>Recorded units</th></tr></thead>
              <tbody>{snap.nodeStates.map((n: any) => <tr key={n.id} className="border-b border-white/5"><td className="py-1.5 text-white">Node {n.name}</td><td>{n.units}</td></tr>)}
                {snap.channelStates.map((c: any) => <tr key={c.channel} className="border-b border-white/5"><td className="py-1.5 text-amber-300">Channel {c.channel} ({c.messages} msg)</td><td>{c.units}</td></tr>)}</tbody></table>
            <div className={`text-sm font-medium ${snap.consistent ? "text-emerald-400" : "text-rose-400"}`}>Snapshot total {snap.snapTotal} vs actual total {snap.expected}: {snap.consistent ? "consistent cut, no units lost or duplicated" : "inconsistent"}</div>
          </Panel>
        </div>
      )}
    </div>
  );
}
