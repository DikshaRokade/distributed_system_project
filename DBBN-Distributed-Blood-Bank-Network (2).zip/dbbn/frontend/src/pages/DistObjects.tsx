import React, { useState } from "react";
import { http } from "../api";
import { usePoll, useAction } from "../components/hooks";
import { PageHeader, Panel, Button, Select, Input, StatusBadge } from "../components/ui";
import StepPlayer from "../components/StepPlayer";

const DEFAULT_ARGS: Record<string, string> = { getStock: '["O-"]', getAllStock: "[]", reserve: '["O-", 2]', addStock: '["O-", 5]', register: '["Asha", "O-"]', count: '["O-"]', list: "[]" };

export default function DistObjects() {
  const { data, reload } = usePoll(() => http.get("/objects"), 3000);
  const objects: any[] = data?.objects || [];
  const classes: Record<string, string[]> = data?.classes || {};
  const names = objects.map((o) => o.name);
  const [target, setTarget] = useState("Pune/Inventory");
  const obj = objects.find((o) => o.name === target) || objects[0];
  const methods = obj ? classes[obj.class] || [] : [];
  const [method, setMethod] = useState("getStock");
  const [args, setArgs] = useState('["O-"]');
  const [res, setRes] = useState<any>(null);
  const [bn, setBn] = useState("Pune/Donors2"); const [bc, setBc] = useState("DonorRegistry"); const [bnode, setBnode] = useState("node-pune");
  const { busy, error, run } = useAction();

  return (
    <div>
      <PageHeader title="Distributed Objects" subtitle="RMI/CORBA-style remote objects: a naming service maps names to object references; client stubs marshal calls and server skeletons dispatch them to servants." />
      <Panel title="Naming service (object registry)" className="mb-4">
        <div className="overflow-x-auto"><table className="w-full text-xs"><thead><tr className="text-left text-slate-400 border-b border-white/10"><th className="py-1.5">Bound name</th><th>Class</th><th>Host</th><th>Remote reference</th><th>Calls</th><th></th></tr></thead>
          <tbody>{objects.map((o) => (<tr key={o.id} className="border-b border-white/5"><td className="py-1.5 text-white">{o.name}</td><td>{o.class}</td><td>{o.nodeName} <StatusBadge status={o.status} /></td><td className="font-mono text-slate-400">{o.ref}</td><td>{o.calls}</td><td><button className="text-rose-400 hover:underline" onClick={async () => { await run(() => http.post("/objects/unbind", { name: o.name })); reload(); }}>unbind</button></td></tr>))}</tbody></table></div>
      </Panel>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
        <Panel title="Invoke a remote method">
          <div className="space-y-2">
            <div className="flex gap-2 items-end flex-wrap"><div><label className="text-xs text-slate-400 block mb-1">Object</label><Select value={target} onChange={(v) => { setTarget(v); const o = objects.find((x) => x.name === v); const m = classes[o?.class]?.[0] || "getStock"; setMethod(m); setArgs(DEFAULT_ARGS[m]); }} options={names} /></div>
              <div><label className="text-xs text-slate-400 block mb-1">Method</label><Select value={method} onChange={(v) => { setMethod(v); setArgs(DEFAULT_ARGS[v] || "[]"); }} options={methods} /></div></div>
            <div><label className="text-xs text-slate-400 block mb-1">Arguments (JSON array)</label><Input value={args} onChange={(e) => setArgs(e.target.value)} className="w-full font-mono" /></div>
            <Button disabled={busy} onClick={async () => { let a: any[] = []; try { a = JSON.parse(args); } catch { return; } const r = await run(() => http.post("/objects/invoke", { target, method, args: a })); if (r) { setRes(r); reload(); } }}>Invoke</Button>
            {error && <div className="text-sm text-rose-400">{error}</div>}
          </div>
        </Panel>
        <Panel title="Bind a new remote object">
          <div className="space-y-2">
            <Input value={bn} onChange={(e) => setBn(e.target.value)} className="w-full" />
            <div className="flex gap-2"><Select value={bc} onChange={setBc} options={Object.keys(classes)} /><Select value={bnode.replace("node-", "")} onChange={(v) => setBnode("node-" + v)} options={["pune", "mumbai", "nashik", "nagpur", "kolhapur"]} /></div>
            <Button variant="secondary" onClick={async () => { await run(() => http.post("/objects/bind", { name: bn, class: bc, nodeId: bnode })); reload(); }}>Bind</Button>
            <div className="text-xs text-slate-500">Tip: fail a node on the Fault Tolerance page and invoke one of its objects to see a RemoteException.</div>
          </div>
        </Panel>
      </div>
      {res && <Panel title={res.ok ? `Result: ${JSON.stringify(res.result)}` : `Failed: ${res.error}`}><StepPlayer steps={res.steps} speed={400} title="Call path through stub and skeleton" /></Panel>}
    </div>
  );
}
