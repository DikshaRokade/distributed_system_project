import React, { useState } from "react";
import { Search, Droplet, CheckCircle2, XCircle, Loader2 } from "lucide-react";
import { api } from "../api";
import { PageHeader, Panel, Button, Select, Input, StatusBadge } from "../components/ui";
import { BLOOD_GROUPS } from "../constants";
import type { Transaction } from "../types";

interface SearchResult {
  nodeId: string;
  name: string;
  available: number;
  unreachable: boolean;
}

export default function BloodSearch() {
  const [bloodGroup, setBloodGroup] = useState("O-");
  const [units, setUnits] = useState(5);
  const [hospital, setHospital] = useState("Sassoon General Hospital");
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<SearchResult[] | null>(null);
  const [reserving, setReserving] = useState(false);
  const [txn, setTxn] = useState<Transaction | null>(null);

  async function runSearch() {
    setLoading(true);
    setResults(null);
    setTxn(null);
    try {
      const res = await api.bloodSearch(bloodGroup, units);
      setResults(res.results);
    } finally {
      setLoading(false);
    }
  }

  async function reserve() {
    setReserving(true);
    setTxn(null);
    try {
      const result = await api.reserve(hospital, bloodGroup, units);
      setTxn(result);
      // refresh search results to reflect new inventory
      const res = await api.bloodSearch(bloodGroup, units);
      setResults(res.results);
    } finally {
      setReserving(false);
    }
  }

  const bestNode = results?.find((r) => !r.unreachable && r.available >= units);

  return (
    <div>
      <PageHeader
        title="Blood Search"
        subtitle="Distributed computation: the middleware queries every healthy node in parallel and aggregates results"
      />

      <Panel className="mb-6">
        <div className="flex flex-wrap items-end gap-3">
          <div>
            <label className="text-xs text-slate-400 block mb-1">Hospital</label>
            <Input value={hospital} onChange={(e) => setHospital(e.target.value)} className="w-64" />
          </div>
          <div>
            <label className="text-xs text-slate-400 block mb-1">Blood Group</label>
            <Select value={bloodGroup} onChange={setBloodGroup} options={BLOOD_GROUPS} />
          </div>
          <div>
            <label className="text-xs text-slate-400 block mb-1">Units Required</label>
            <Input type="number" min={1} value={units} onChange={(e) => setUnits(Number(e.target.value))} className="w-24" />
          </div>
          <Button onClick={runSearch} disabled={loading}>
            {loading ? <Loader2 className="w-4 h-4 animate-spin inline mr-1" /> : <Search className="w-4 h-4 inline mr-1" />}
            Search Network
          </Button>
          {bestNode && (
            <Button variant="primary" onClick={reserve} disabled={reserving} className="bg-emerald-600 hover:bg-emerald-700 shadow-emerald-900/30">
              {reserving ? <Loader2 className="w-4 h-4 animate-spin inline mr-1" /> : null}
              Reserve {units} units from {bestNode.name}
            </Button>
          )}
        </div>
      </Panel>

      {results && (
        <Panel title={`Parallel RPC results — checkInventory("${bloodGroup}") sent to all healthy nodes`} className="mb-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {results.map((r) => (
              <div
                key={r.nodeId}
                className={`rounded-xl border p-3 ${
                  r.unreachable
                    ? "border-rose-500/30 bg-rose-500/5"
                    : r.available >= units
                    ? "border-emerald-500/30 bg-emerald-500/5"
                    : "border-white/10 bg-white/5"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-white text-sm">{r.name}</span>
                  {r.unreachable ? (
                    <XCircle className="w-4 h-4 text-rose-400" />
                  ) : r.available >= units ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  ) : null}
                </div>
                <div className="mt-2 flex items-center gap-1 text-slate-300">
                  <Droplet className="w-3.5 h-3.5 text-blood-500" />
                  <span className="text-lg font-bold">{r.unreachable ? "—" : r.available}</span>
                  <span className="text-xs text-slate-500">units</span>
                </div>
                <div className="text-[11px] text-slate-500 mt-1">{r.unreachable ? "RPC timeout — node down" : "reachable"}</div>
              </div>
            ))}
          </div>
          {!bestNode && (
            <div className="text-sm text-amber-400 mt-4">
              No single node currently holds {units} units of {bloodGroup}. Try fewer units, or check Fault Tolerance / Emergency Requests.
            </div>
          )}
        </Panel>
      )}

      {txn && (
        <Panel title="Distributed Transaction Timeline">
          <div className="flex items-center gap-2 mb-4">
            <span className="text-sm text-slate-400">Result:</span>
            <StatusBadge status={txn.status} />
          </div>
          <ol className="relative border-l border-white/10 ml-2 space-y-4">
            {txn.steps.map((s, i) => (
              <li key={i} className="ml-4">
                <div
                  className={`absolute w-2.5 h-2.5 rounded-full -left-[5px] mt-1.5 ${
                    s.status === "done" ? "bg-emerald-500" : s.status === "failed" ? "bg-rose-500" : "bg-sky-500"
                  }`}
                />
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-white">{s.name}</span>
                  <StatusBadge status={s.status} />
                </div>
                <div className="text-xs text-slate-400 mt-0.5">{s.detail}</div>
              </li>
            ))}
          </ol>
        </Panel>
      )}
    </div>
  );
}
