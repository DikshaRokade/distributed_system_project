import React, { useState } from "react";
import { ShieldAlert, PowerOff, Power, Loader2, Crown } from "lucide-react";
import { api } from "../api";
import { useNetwork } from "../store";
import { PageHeader, Panel, Button, StatusBadge } from "../components/ui";
import LogFeed from "../components/LogFeed";

export default function FaultTolerance() {
  const { nodes, coordinatorId, dashboard, logs, refreshAll } = useNetwork();
  const [busyId, setBusyId] = useState<string | null>(null);

  async function toggle(id: string, status: string) {
    setBusyId(id);
    try {
      if (status === "healthy") await api.failNode(id);
      else await api.recoverNode(id);
      await new Promise((r) => setTimeout(r, id === coordinatorId ? 2200 : 200));
      await refreshAll();
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div>
      <PageHeader
        title="Fault Tolerance"
        subtitle="Kill any node — including the coordinator — and watch the network keep serving requests through healthy nodes"
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        <Panel title="Network Health" className="lg:col-span-1">
          <div className="flex items-center gap-3">
            <ShieldAlert className={`w-8 h-8 ${(dashboard?.networkHealth ?? 100) > 60 ? "text-emerald-400" : "text-rose-400"}`} />
            <div>
              <div className="text-2xl font-bold text-white">{dashboard?.networkHealth ?? 100}%</div>
              <div className="text-xs text-slate-500">
                {dashboard?.activeNodes ?? 5} of {dashboard?.totalNodes ?? 5} nodes healthy
              </div>
            </div>
          </div>
        </Panel>
        <Panel title="What happens on failure" className="lg:col-span-2">
          <ul className="text-sm text-slate-400 list-disc list-inside space-y-1">
            <li>Middleware stops routing RPCs to the failed node; its locks are released</li>
            <li>Blood search & reservations continue transparently through the remaining nodes</li>
            <li>If the <span className="text-amber-400">coordinator</span> fails, a Bully election starts automatically</li>
            <li>On recovery, the node resynchronizes state via a P2P pull from its peers</li>
          </ul>
        </Panel>
      </div>

      <Panel title="Nodes" className="mb-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {nodes.map((n) => (
            <div key={n.id} className="rounded-xl border border-white/5 bg-white/5 p-3 flex flex-col items-center text-center gap-2">
              <div className="flex items-center gap-1">
                {n.id === coordinatorId && <Crown className="w-3.5 h-3.5 text-amber-400" />}
                <span className="font-semibold text-white text-sm">{n.name}</span>
              </div>
              <StatusBadge status={n.status} />
              <Button
                variant={n.status === "healthy" ? "danger" : "secondary"}
                onClick={() => toggle(n.id, n.status)}
                disabled={busyId === n.id}
                className="w-full"
              >
                {busyId === n.id ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin inline mr-1" />
                ) : n.status === "healthy" ? (
                  <PowerOff className="w-3.5 h-3.5 inline mr-1" />
                ) : (
                  <Power className="w-3.5 h-3.5 inline mr-1" />
                )}
                {n.status === "healthy" ? "Fail" : "Recover"}
              </Button>
            </div>
          ))}
        </div>
      </Panel>

      <Panel title="Live Effect Log">
        <LogFeed logs={logs} max={40} />
      </Panel>
    </div>
  );
}
