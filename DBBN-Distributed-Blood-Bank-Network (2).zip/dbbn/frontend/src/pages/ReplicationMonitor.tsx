import React from "react";
import { RefreshCw, Crown } from "lucide-react";
import { useNetwork } from "../store";
import { PageHeader, Panel, timeAgo } from "../components/ui";

export default function ReplicationMonitor() {
  const { replicationLog, nodes, coordinatorId } = useNetwork();

  return (
    <div>
      <PageHeader title="Replication Monitor" subtitle="Primary/replica synchronization — every inventory update on a primary node is propagated peer-to-peer" />

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-3 mb-6">
        {nodes.map((n) => (
          <div key={n.id} className="bg-ink-800/60 border border-white/5 rounded-xl p-3">
            <div className="flex items-center gap-1.5 mb-1">
              {n.id === coordinatorId ? (
                <Crown className="w-3.5 h-3.5 text-amber-400" />
              ) : (
                <RefreshCw className="w-3.5 h-3.5 text-teal-400" />
              )}
              <span className="text-sm font-semibold text-white">{n.name}</span>
            </div>
            <div className="text-[11px] text-slate-500">{n.id === coordinatorId ? "primary / coordinator" : "replica peer"}</div>
            <div className={`text-[11px] mt-1 ${n.status === "healthy" ? "text-emerald-400" : "text-rose-400"}`}>
              {n.status === "healthy" ? "in sync" : "unreachable — will resync on recovery"}
            </div>
          </div>
        ))}
      </div>

      <Panel title="Replication Log (P2P inventory sync)">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-slate-400 border-b border-white/10">
                <th className="py-2 pr-4 font-medium">From (primary)</th>
                <th className="py-2 pr-4 font-medium">To (replica)</th>
                <th className="py-2 pr-4 font-medium">Blood Group</th>
                <th className="py-2 pr-4 font-medium">Delta</th>
                <th className="py-2 pr-4 font-medium">Status</th>
                <th className="py-2 pr-4 font-medium">When</th>
              </tr>
            </thead>
            <tbody>
              {replicationLog.slice(0, 80).map((r, i) => (
                <tr key={i} className="border-b border-white/5">
                  <td className="py-2 pr-4 text-white">{nodes.find((n) => n.id === r.from)?.name || r.from}</td>
                  <td className="py-2 pr-4 text-slate-300">{nodes.find((n) => n.id === r.to)?.name || r.to}</td>
                  <td className="py-2 pr-4 text-blood-400 font-semibold">{r.bloodGroup}</td>
                  <td className={`py-2 pr-4 font-mono ${r.delta < 0 ? "text-rose-400" : "text-emerald-400"}`}>{r.delta > 0 ? `+${r.delta}` : r.delta}</td>
                  <td className="py-2 pr-4 text-emerald-400">{r.status}</td>
                  <td className="py-2 pr-4 text-slate-500">{timeAgo(r.ts)}</td>
                </tr>
              ))}
              {replicationLog.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500">
                    No replication events yet — reserve blood on the Blood Search page to trigger one.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Panel>
    </div>
  );
}
