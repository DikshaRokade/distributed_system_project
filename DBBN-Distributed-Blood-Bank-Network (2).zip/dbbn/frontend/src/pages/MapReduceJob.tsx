import React, { useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { http } from "../api";
import { usePoll, useAction } from "../components/hooks";
import { PageHeader, Panel, Button, Select, Input } from "../components/ui";

const JOBS: Record<string, string> = { inventory: "Units per blood group (node inventories)", demand: "Units requested per hospital (transactions)", wordcount: "Word count of a DFS file" };

export default function MapReduceJob() {
  const { data: dfs } = usePoll(() => http.get("/dfs"), 4000);
  const files: string[] = (dfs?.files || []).map((f: any) => f.name);
  const [job, setJob] = useState("inventory");
  const [file, setFile] = useState("");
  const [R, setR] = useState(3);
  const [comb, setComb] = useState(true);
  const [res, setRes] = useState<any>(null);
  const { busy, error, run } = useAction();
  const go = async (c: boolean) => { const r = await run(() => http.post("/mapreduce/run", { job, file: file || files[0], reducers: R, combiner: c })); if (r) setRes(r); };

  return (
    <div>
      <PageHeader title="MapReduce (Hadoop-style)" subtitle="Map tasks run on the nodes that hold the data, an optional combiner pre-aggregates locally, the shuffle partitions keys across reducers, and reducers produce the final result." />
      <Panel className="mb-4">
        <div className="flex flex-wrap items-end gap-3">
          <div><label className="text-xs text-slate-400 block mb-1">Job</label><Select value={JOBS[job]} onChange={(v) => setJob(Object.keys(JOBS).find((k) => JOBS[k] === v) || "inventory")} options={Object.values(JOBS)} /></div>
          {job === "wordcount" && <div><label className="text-xs text-slate-400 block mb-1">DFS file</label>{files.length ? <Select value={file || files[0]} onChange={setFile} options={files} /> : <span className="text-xs text-amber-400">Upload a file on the Distributed File System page first</span>}</div>}
          <div><label className="text-xs text-slate-400 block mb-1">Reducers</label><Input type="number" min={1} max={5} value={R} onChange={(e) => setR(Number(e.target.value))} className="w-20" /></div>
          <label className="text-sm text-slate-300 flex items-center gap-2 pb-1.5"><input type="checkbox" checked={comb} onChange={(e) => setComb(e.target.checked)} /> Use combiner</label>
          <Button disabled={busy} onClick={() => go(comb)}>Run job</Button>
        </div>
        {error && <div className="text-sm text-rose-400 mt-2">{error}</div>}
      </Panel>
      {res && (
        <>
          <div className="text-sm text-slate-300 mb-3">{res.title}</div>
          {res.warnings.map((w: string, i: number) => <div key={i} className="text-xs text-amber-400 mb-1">{w}</div>)}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 my-3">
            {[["Map input records", res.counters.mapInput], ["Map output records", res.counters.mapOutput], [`Shuffled records (${res.combiner ? "after combiner" : "no combiner"})`, res.counters.shuffled], ["Reduce output keys", res.counters.reduceOutput]].map(([l, v]) => <div key={String(l)} className="bg-ink-800/60 border border-white/5 rounded-xl p-3"><div className="text-xs text-slate-400">{l}</div><div className="text-xl font-bold text-white">{v}</div></div>)}
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <Panel title="1. Map tasks">
              <table className="w-full text-xs"><thead><tr className="text-left text-slate-400 border-b border-white/10"><th className="py-1">Task</th><th>Node</th><th>Out</th><th>Shuffled</th></tr></thead><tbody>{res.maps.map((m: any) => <tr key={m.id} className="border-b border-white/5" title={m.note}><td className="py-1 font-mono">{m.id}</td><td>{m.node}</td><td>{m.outRecords}</td><td>{m.shuffled}</td></tr>)}</tbody></table>
              <div className="text-[11px] text-slate-500 mt-2">Hover a row for data-locality or rescheduling notes.</div>
              <Button variant="secondary" className="mt-2" onClick={() => go(!res.combiner)}>Re-run {res.combiner ? "without" : "with"} combiner to compare</Button>
            </Panel>
            <Panel title="2. Shuffle and reduce tasks">
              <table className="w-full text-xs"><thead><tr className="text-left text-slate-400 border-b border-white/10"><th className="py-1">Reducer</th><th>Node</th><th>Keys</th><th>Values</th></tr></thead><tbody>{res.reducers.map((r: any) => <tr key={r.id} className="border-b border-white/5"><td className="py-1 font-mono">{r.id}</td><td>{r.node}</td><td>{r.keys}</td><td>{r.values}</td></tr>)}</tbody></table>
              <div className="text-[11px] text-slate-500 mt-2">Keys are assigned to reducers by hash(key) mod reducers.</div>
            </Panel>
            <Panel title="3. Output (top keys)">
              <ResponsiveContainer width="100%" height={240}><BarChart data={res.result.slice(0, 10)} layout="vertical"><CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" /><XAxis type="number" stroke="#94a3b8" fontSize={11} /><YAxis type="category" dataKey="key" width={90} stroke="#94a3b8" fontSize={11} /><Tooltip contentStyle={{ background: "#111827", border: "1px solid #ffffff20", borderRadius: 8 }} /><Bar dataKey="value" fill="#ef4444" radius={[0, 4, 4, 0]} /></BarChart></ResponsiveContainer>
            </Panel>
          </div>
        </>
      )}
    </div>
  );
}
