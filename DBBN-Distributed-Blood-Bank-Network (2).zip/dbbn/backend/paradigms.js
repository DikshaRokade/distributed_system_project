// paradigms.js — Unit IV (Emerging Distributed Paradigms):
// distributed objects (RMI-style), web systems (load balancer + edge cache),
// distributed file system (HDFS-style), serverless (FaaS), MapReduce (Hadoop),
// orchestrator (Kubernetes-style) and software-defined network fabric (Megaport-style).
const state = require("./state");

const rnd = (a, b) => a + Math.random() * (b - a);
const ri = (a, b) => Math.floor(rnd(a, b + 1));
const bad = (m, status = 400) => { const e = new Error(m); e.status = status; return e; };
const nm = (id) => (state.getNode(id) || { name: id }).name;
const hash = (s) => { let x = 0; for (const c of String(s)) x = (x * 31 + c.charCodeAt(0)) >>> 0; return x; };
const BG = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];

function init() {
  return {
    objects: [], oid: 0,
    web: { algorithm: "round-robin", ttlMs: 10000, cacheEnabled: true, cache: {}, counts: {}, rr: 0, hits: 0, misses: 0, latency: 0, log: [] },
    dfs: { files: {}, blocks: {}, blockSize: 32, next: 1 },
    fn: { keepAliveMs: 30000, containers: [], cid: 0, stats: { cold: 0, warm: 0, invocations: 0, gbMs: 0 }, log: [] },
    k8s: { deployments: {}, pods: [], events: [], rr: {}, boot: false },
    net: { vxcs: [], vid: 0 },
  };
}
const P = () => state.ext("para", init);

function register(app, logic, io) {
  const h = (fn) => async (req, res) => {
    try { const r = await fn(req, res); if (r !== undefined && !res.headersSent) res.json(r); }
    catch (err) { res.status(err.status || 500).json({ error: err.message }); }
  };

  // =====================================================================
  // 1. Distributed objects (remote object registry, stubs and skeletons)
  // =====================================================================
  const CLASSES = {
    BloodInventory: ["getStock", "getAllStock", "reserve", "addStock"],
    DonorRegistry: ["register", "count", "list"],
  };
  function bind(name, cls, nodeId) {
    const p = P();
    if (!CLASSES[cls]) throw bad("Unknown class");
    if (!state.getNode(nodeId)) throw bad("Unknown node");
    if (!name || p.objects.some((o) => o.name === name)) throw bad("Name is empty or already bound (AlreadyBoundException)");
    const id = ++p.oid;
    const o = { id, name, class: cls, nodeId, ref: `dbbn://${nodeId}/${cls}#${id}`, state: cls === "DonorRegistry" ? { donors: [] } : {}, calls: 0 };
    p.objects.push(o);
    state.persist();
    return o;
  }
  function ensureObjects() {
    const p = P();
    if (p.objects.length) return;
    state.getState().nodes.forEach((n) => { bind(`${n.name}/Inventory`, "BloodInventory", n.id); bind(`${n.name}/Donors`, "DonorRegistry", n.id); });
  }
  async function servant(o, node, method, args) {
    const key = `${o.class}.${method}`;
    const checkBg = (g) => { if (!BG.includes(g)) throw new Error(`IllegalArgumentException: unknown blood group ${g}`); return g; };
    switch (key) {
      case "BloodInventory.getStock": return node.inventory[checkBg(args[0])];
      case "BloodInventory.getAllStock": return { ...node.inventory };
      case "BloodInventory.reserve": {
        const g = checkBg(args[0]), u = Number(args[1]);
        if (!(u > 0)) throw new Error("IllegalArgumentException: units must be positive");
        if (node.inventory[g] < u) throw new Error("InsufficientStockException");
        node.inventory[g] -= u; state.persist();
        await logic.replicateUpdate(node.id, g, -u); logic.pushDashboard();
        return { reserved: u, remaining: node.inventory[g] };
      }
      case "BloodInventory.addStock": {
        const g = checkBg(args[0]), u = Number(args[1]);
        if (!(u > 0)) throw new Error("IllegalArgumentException: units must be positive");
        node.inventory[g] += u; state.persist();
        await logic.replicateUpdate(node.id, g, u); logic.pushDashboard();
        return { added: u, stock: node.inventory[g] };
      }
      case "DonorRegistry.register": o.state.donors.push({ name: String(args[0] || "anonymous"), bg: checkBg(args[1]) }); state.persist(); return { donorNumber: o.state.donors.length };
      case "DonorRegistry.count": return args[0] ? o.state.donors.filter((d) => d.bg === args[0]).length : o.state.donors.length;
      case "DonorRegistry.list": return o.state.donors;
      default: throw new Error("NoSuchMethodException");
    }
  }
  app.get("/api/objects", h(() => { ensureObjects(); return { classes: CLASSES, objects: P().objects.map((o) => ({ ...o, nodeName: nm(o.nodeId), status: state.getNode(o.nodeId).status })) }; }));
  app.post("/api/objects/bind", h((req) => { ensureObjects(); return bind(req.body.name, req.body.class, req.body.nodeId); }));
  app.post("/api/objects/unbind", h((req) => { const p = P(); p.objects = p.objects.filter((o) => o.name !== req.body.name); state.persist(); return { ok: true }; }));
  app.post("/api/objects/invoke", h(async (req) => {
    ensureObjects();
    const { target, method } = req.body, args = Array.isArray(req.body.args) ? req.body.args : [];
    const o = P().objects.find((x) => x.name === target || x.ref === target);
    if (!o) throw bad("NotBoundException: no object bound to that name");
    const node = state.getNode(o.nodeId);
    const payload = JSON.stringify({ ref: o.ref, method, args });
    const steps = [
      { kind: "info", text: `Naming service lookup "${o.name}" -> remote reference ${o.ref}` },
      { kind: "request", text: `Client stub marshals the call into ${payload.length} bytes: ${payload}` },
      { kind: "request", from: o.nodeId, text: `Request travels to ${node.ip}:${node.port} (${node.name})` },
    ];
    if (node.status !== "healthy") { steps.push({ kind: "deadlock", text: "RemoteException: connection refused, the host is down." }); return { ok: false, steps, error: "RemoteException" }; }
    if (!CLASSES[o.class].includes(method)) { steps.push({ kind: "deadlock", text: `NoSuchMethodException: ${o.class} has no method ${method}()` }); return { ok: false, steps, error: "NoSuchMethodException" }; }
    steps.push({ kind: "info", text: `Skeleton on ${node.name} unmarshals the request and invokes ${o.class}.${method}() on the servant.` });
    let result;
    try { result = await servant(o, node, method, args); }
    catch (e) { steps.push({ kind: "deadlock", text: `Servant raised ${e.message}; it is marshalled back and re-thrown at the client.` }); return { ok: false, steps, error: e.message }; }
    o.calls++; state.persist();
    const out = JSON.stringify(result);
    steps.push({ kind: "reply", from: o.nodeId, text: `Skeleton marshals the return value (${(out || "").length} bytes) and sends it back.` });
    steps.push({ kind: "enter", text: `Client stub unmarshals the reply: ${out}` });
    return { ok: true, steps, result };
  }));

  // =====================================================================
  // 2. Web-based systems: load balancer + edge cache
  // =====================================================================
  function webOnce(bg) {
    const w = P().web, now = Date.now();
    const healthy = state.healthyNodes();
    if (!healthy.length) throw bad("No healthy origin servers (503 Service Unavailable)", 503);
    const current = healthy.reduce((x, n) => x + (n.inventory[bg] || 0), 0);
    const c = w.cache[bg];
    let entry;
    if (w.cacheEnabled && c && now < c.expires) {
      const lat = ri(2, 8);
      w.hits++; w.latency += lat;
      entry = { bg, cache: "HIT", stale: c.value !== current, value: c.value, truth: current, servedBy: c.servedBy, latencyMs: lat, expiresInMs: c.expires - now };
    } else {
      let node;
      const a = w.algorithm;
      if (a === "round-robin") node = healthy[w.rr++ % healthy.length];
      else if (a === "least-loaded") node = [...healthy].sort((x, y) => (w.counts[x.id] || 0) - (w.counts[y.id] || 0))[0];
      else if (a === "random") node = healthy[ri(0, healthy.length - 1)];
      else node = healthy[hash(bg) % healthy.length];
      w.counts[node.id] = (w.counts[node.id] || 0) + 1;
      const lat = ri(40, 120);
      w.misses++; w.latency += lat;
      if (w.cacheEnabled) w.cache[bg] = { value: current, expires: now + w.ttlMs, servedBy: node.name };
      entry = { bg, cache: w.cacheEnabled ? "MISS" : "BYPASS", stale: false, value: current, truth: current, servedBy: node.name, latencyMs: lat, expiresInMs: w.cacheEnabled ? w.ttlMs : 0 };
    }
    w.log.unshift({ ts: now, ...entry });
    w.log = w.log.slice(0, 40);
    return entry;
  }
  const webStats = () => {
    const w = P().web, n = w.hits + w.misses;
    return {
      algorithm: w.algorithm, ttlMs: w.ttlMs, cacheEnabled: w.cacheEnabled,
      hits: w.hits, misses: w.misses, hitRatio: n ? Math.round((w.hits / n) * 100) : 0, avgLatency: n ? Math.round(w.latency / n) : 0,
      perNode: state.getState().nodes.map((x) => ({ name: x.name, requests: w.counts[x.id] || 0 })),
      cached: Object.entries(w.cache).map(([bg, c]) => ({ bg, value: c.value, servedBy: c.servedBy, expiresInMs: Math.max(0, c.expires - Date.now()) })),
      log: w.log,
    };
  };
  app.get("/api/web", h(() => webStats()));
  app.post("/api/web/config", h((req) => {
    const w = P().web;
    if (["round-robin", "least-loaded", "random", "hash"].includes(req.body.algorithm)) w.algorithm = req.body.algorithm;
    if (req.body.ttlMs !== undefined) w.ttlMs = Math.max(500, Math.min(120000, Number(req.body.ttlMs) || 10000));
    if (req.body.cacheEnabled !== undefined) w.cacheEnabled = !!req.body.cacheEnabled;
    state.persist();
    return webStats();
  }));
  app.post("/api/web/request", h((req) => { if (!BG.includes(req.body.bg)) throw bad("Unknown blood group"); return webOnce(req.body.bg); }));
  app.post("/api/web/burst", h((req) => {
    const n = Math.min(200, Number(req.body.count) || 30);
    for (let i = 0; i < n; i++) webOnce(["O-", "O-", "O-", "A+", "B+", "AB-", "O+"][ri(0, 6)]);
    return webStats();
  }));
  app.post("/api/web/reset", h(() => { const w = P().web; Object.assign(w, { cache: {}, counts: {}, rr: 0, hits: 0, misses: 0, latency: 0, log: [] }); return webStats(); }));
  app.post("/api/web/purge", h(() => { P().web.cache = {}; return webStats(); }));

  // =====================================================================
  // 3. Distributed file system (HDFS-style: NameNode metadata + DataNodes)
  // =====================================================================
  const dfsView = () => {
    const d = P().dfs, s = state.getState();
    const files = Object.values(d.files).map((f) => ({
      name: f.name, size: f.size, replication: f.replication,
      blocks: f.blocks.map((id) => {
        const b = d.blocks[id], healthy = b.replicas.filter((r) => state.getNode(r) && state.getNode(r).status === "healthy");
        return { id, size: b.data.length, replicas: b.replicas.map((r) => ({ node: nm(r), healthy: state.getNode(r).status === "healthy" })), healthyCount: healthy.length };
      }),
    }));
    const usage = s.nodes.map((n) => ({ name: n.name, status: n.status, blocks: Object.values(d.blocks).filter((b) => b.replicas.includes(n.id)).length }));
    const under = files.reduce((x, f) => x + f.blocks.filter((b) => b.healthyCount < f.replication).length, 0);
    const missing = files.reduce((x, f) => x + f.blocks.filter((b) => b.healthyCount === 0).length, 0);
    return { nameNode: nm(s.coordinatorId), blockSize: d.blockSize, files, usage, underReplicated: under, missingBlocks: missing };
  };
  app.get("/api/dfs", h(() => dfsView()));
  app.post("/api/dfs/upload", h((req) => {
    const d = P().dfs, { name, content } = req.body;
    const rep = Math.max(1, Math.min(5, Number(req.body.replication) || 3));
    if (!name || !content) throw bad("File name and content are required");
    if (String(content).length > 20000) throw bad("Content too large for the demo (max 20000 chars)");
    const bs = Math.max(8, Math.min(256, Number(req.body.blockSize) || d.blockSize));
    d.blockSize = bs;
    const healthy = state.healthyNodes();
    if (!healthy.length) throw bad("No DataNodes available");
    if (d.files[name]) d.files[name].blocks.forEach((id) => delete d.blocks[id]);
    const nameNode = state.getNode(state.getState().coordinatorId);
    const steps = [{ kind: "info", text: `Client contacts the NameNode (${nameNode.name}) to create "${name}" (${String(content).length} chars, block size ${bs}, replication ${rep}).` }];
    const f = { name, size: String(content).length, replication: rep, blocks: [] };
    const text = String(content);
    for (let i = 0; i < text.length; i += bs) {
      const id = `blk_${d.next++}`;
      const load = (n) => Object.values(d.blocks).filter((b) => b.replicas.includes(n.id)).length;
      const targets = [...healthy].sort((a, b) => load(a) - load(b) || a.numericId - b.numericId).slice(0, Math.min(rep, healthy.length));
      d.blocks[id] = { id, data: text.slice(i, i + bs), replicas: targets.map((t) => t.id) };
      f.blocks.push(id);
      steps.push({ kind: "request", from: nameNode.id, text: `NameNode allocates ${id} (${d.blocks[id].data.length} chars) -> DataNode pipeline ${targets.map((t) => t.name).join(" -> ")}` });
    }
    if (healthy.length < rep) steps.push({ kind: "defer", text: `Only ${healthy.length} healthy DataNode(s): blocks are under-replicated (target ${rep}).` });
    steps.push({ kind: "enter", text: `File stored as ${f.blocks.length} block(s). Data is written through a pipeline: each DataNode forwards to the next replica.` });
    d.files[name] = f;
    state.persist();
    return { steps, view: dfsView() };
  }));
  app.get("/api/dfs/read/:name", h((req) => {
    const d = P().dfs, f = d.files[req.params.name];
    if (!f) throw bad("File not found", 404);
    const steps = [{ kind: "info", text: `Client asks the NameNode for the block locations of "${f.name}".` }];
    let out = "", lost = false;
    f.blocks.forEach((id) => {
      const b = d.blocks[id];
      const r = b.replicas.find((x) => state.getNode(x).status === "healthy");
      if (!r) { lost = true; steps.push({ kind: "deadlock", text: `${id}: all replicas (${b.replicas.map(nm).join(", ")}) are down. BlockMissingException.` }); return; }
      const skipped = b.replicas.filter((x) => x !== r && b.replicas.indexOf(x) < b.replicas.indexOf(r));
      steps.push({ kind: "reply", from: r, text: `${id} read from DataNode ${nm(r)}${skipped.length ? ` (failed over: ${skipped.map(nm).join(", ")} unreachable)` : ""}` });
      out += b.data;
    });
    steps.push(lost ? { kind: "deadlock", text: "Read failed: some blocks have no live replica." } : { kind: "enter", text: "All blocks fetched and reassembled." });
    return { ok: !lost, content: lost ? null : out, steps };
  }));
  app.post("/api/dfs/delete", h((req) => {
    const d = P().dfs, f = d.files[req.body.name];
    if (f) { f.blocks.forEach((id) => delete d.blocks[id]); delete d.files[req.body.name]; state.persist(); }
    return dfsView();
  }));
  app.post("/api/dfs/rereplicate", h(() => {
    const d = P().dfs, healthy = state.healthyNodes();
    const steps = [{ kind: "info", text: "NameNode scans block reports from DataNodes (heartbeat-based) for under- or over-replicated blocks." }];
    let fixed = 0;
    Object.values(d.files).forEach((f) => f.blocks.forEach((id) => {
      const b = d.blocks[id];
      let live = b.replicas.filter((r) => healthy.some((n) => n.id === r));
      if (live.length > f.replication) {
        const extra = live.slice(f.replication);
        b.replicas = b.replicas.filter((r) => !extra.includes(r));
        steps.push({ kind: "exit", text: `${id} is over-replicated: deleting extra replica(s) on ${extra.map(nm).join(", ")}.` });
        return;
      }
      if (live.length === 0) { steps.push({ kind: "deadlock", text: `${id} has no live replica: cannot be recovered until a holder returns.` }); return; }
      while (live.length < f.replication) {
        const cand = healthy.filter((n) => !b.replicas.includes(n.id)).sort((x, y) => x.numericId - y.numericId)[0];
        if (!cand) break;
        const src = live[0];
        b.replicas = b.replicas.filter((r) => healthy.some((n) => n.id === r)).concat(cand.id);
        live = b.replicas.filter((r) => healthy.some((n) => n.id === r));
        fixed++;
        steps.push({ kind: "token", from: src, to: cand.id, text: `${id} under-replicated: copy ${nm(src)} -> ${cand.name}` });
      }
    }));
    steps.push({ kind: "enter", text: fixed ? `Re-replicated ${fixed} block copy(ies).` : "Nothing to fix (or not enough healthy nodes)." });
    state.persist();
    return { steps, view: dfsView() };
  }));

  // =====================================================================
  // 4. Serverless (FaaS): cold/warm containers, scale-out, billing
  // =====================================================================
  const aboOk = (d, r) => { const a = d.replace(/[+-]/, ""), b = r.replace(/[+-]/, ""); return a === "O" || a === b || b === "AB"; };
  const FUNCS = {
    checkCompatibility: { memoryMB: 128, sample: { donor: "O-", recipient: "AB+" }, run: (e) => { if (!BG.includes(e.donor) || !BG.includes(e.recipient)) throw new Error("donor and recipient must be valid blood groups"); return { compatible: aboOk(e.donor, e.recipient) && (e.donor.slice(-1) === "-" || e.recipient.slice(-1) === "+") }; } },
    donorEligibility: { memoryMB: 128, sample: { age: 25, weightKg: 60, hemoglobin: 13.5 }, run: (e) => { const why = []; if (e.age < 18 || e.age > 65) why.push("age must be 18-65"); if (e.weightKg < 45) why.push("weight must be at least 45 kg"); if (e.hemoglobin < 12.5) why.push("hemoglobin must be at least 12.5 g/dL"); return { eligible: !why.length, reasons: why }; } },
    stockLevelCheck: { memoryMB: 256, sample: { bloodGroup: "O-", threshold: 30 }, run: (e) => { if (!BG.includes(e.bloodGroup)) throw new Error("unknown blood group"); const t = state.healthyNodes().reduce((x, n) => x + n.inventory[e.bloodGroup], 0); return { bloodGroup: e.bloodGroup, networkUnits: t, status: t < (e.threshold || 30) ? "LOW - raise alert" : "OK" }; } },
  };
  function invokeFn(name, event, at) {
    const f = FUNCS[name], s = P().fn;
    if (!f) throw bad("No such function");
    s.containers = s.containers.filter((c) => at - c.lastUsed <= s.keepAliveMs || c.busyUntil > at);
    let c = s.containers.find((x) => x.fn === name && x.busyUntil <= at);
    const cold = !c;
    if (cold) {
      if (s.containers.filter((x) => x.fn === name).length >= 10) return { fn: name, throttled: true, error: "TooManyRequestsException (concurrency limit 10)" };
      const hn = state.healthyNodes();
      if (!hn.length) throw bad("No healthy node to host a container");
      const cnt = (n) => s.containers.filter((x) => x.node === n.id).length;
      const node = [...hn].sort((a, b) => cnt(a) - cnt(b))[0];
      c = { id: `c-${++s.cid}`, fn: name, node: node.id, createdAt: at, lastUsed: at, busyUntil: at, invocations: 0 };
      s.containers.push(c);
    }
    const initMs = cold ? ri(250, 700) : 0, execMs = ri(8, 60);
    c.busyUntil = at + initMs + execMs; c.lastUsed = c.busyUntil; c.invocations++;
    s.stats.invocations++; cold ? s.stats.cold++ : s.stats.warm++;
    s.stats.gbMs += (execMs * f.memoryMB) / 1024;
    let result, error = null;
    try { result = f.run(event || {}); } catch (e) { error = e.message; }
    const rec = { ts: at, fn: name, cold, container: c.id, node: nm(c.node), initMs, execMs, result, error };
    s.log.unshift(rec); s.log = s.log.slice(0, 40);
    return rec;
  }
  const fnView = () => {
    const s = P().fn, now = Date.now();
    s.containers = s.containers.filter((c) => now - c.lastUsed <= s.keepAliveMs || c.busyUntil > now);
    return {
      keepAliveMs: s.keepAliveMs, stats: { ...s.stats, estCostUsd: +(s.stats.gbMs / 1000 * 0.0000166667).toFixed(10) },
      functions: Object.entries(FUNCS).map(([name, f]) => ({ name, memoryMB: f.memoryMB, sample: f.sample })),
      containers: s.containers.map((c) => ({ id: c.id, fn: c.fn, node: nm(c.node), state: c.busyUntil > now ? "busy" : "idle", idleMs: Math.max(0, now - c.lastUsed), invocations: c.invocations })),
      log: s.log,
    };
  };
  app.get("/api/serverless", h(() => fnView()));
  app.post("/api/serverless/invoke", h((req) => ({ invocation: invokeFn(req.body.fn, req.body.event, Date.now()), view: fnView() })));
  app.post("/api/serverless/burst", h((req) => {
    const at = Date.now(), n = Math.min(40, Number(req.body.count) || 10), recs = [];
    for (let i = 0; i < n; i++) recs.push(invokeFn(req.body.fn, req.body.event, at));
    return { invocations: recs, view: fnView() };
  }));
  app.post("/api/serverless/config", h((req) => { P().fn.keepAliveMs = Math.max(1000, Math.min(600000, Number(req.body.keepAliveMs) || 30000)); return fnView(); }));
  app.post("/api/serverless/reset", h(() => { const s = P().fn; s.containers = []; s.log = []; s.stats = { cold: 0, warm: 0, invocations: 0, gbMs: 0 }; return fnView(); }));

  // =====================================================================
  // 5. MapReduce (Hadoop): data-local map tasks, combiner, shuffle, reduce
  // =====================================================================
  app.post("/api/mapreduce/run", h((req) => {
    const s = state.getState(), healthy = state.healthyNodes();
    if (!healthy.length) throw bad("No healthy nodes");
    const R = Math.max(1, Math.min(5, Number(req.body.reducers) || 3)), useComb = req.body.combiner !== false;
    const job = req.body.job, warnings = [], splits = [];
    let mapFn, title;
    if (job === "inventory") {
      title = "Total units per blood group (input: each node's local inventory)";
      s.nodes.forEach((n) => { if (n.status !== "healthy") { warnings.push(`Input split on ${n.name} is unavailable (node down); the result excludes it.`); return; } splits.push({ node: n.id, records: Object.entries(n.inventory), note: "data-local" }); });
      mapFn = ([g, u]) => [[g, u]];
    } else if (job === "demand") {
      title = "Units requested per hospital (input: committed transactions)";
      const tx = s.transactions.filter((t) => t.status === "committed");
      if (!tx.length) warnings.push("No committed transactions yet. Reserve some blood first (Blood Search page).");
      for (let i = 0; i < tx.length; i += 3) splits.push({ node: healthy[(i / 3) % healthy.length].id, records: tx.slice(i, i + 3).map((t) => [t.hospital, t.units]), note: "round-robin" });
      mapFn = ([hname, u]) => [[hname, u]];
    } else if (job === "wordcount") {
      const d = P().dfs, f = d.files[req.body.file];
      if (!f) throw bad("Pick a file stored in the distributed file system first");
      title = `Word count of "${f.name}" (input: DFS blocks, map tasks run where the block lives)`;
      f.blocks.forEach((id) => {
        const b = d.blocks[id], first = b.replicas[0], r = b.replicas.find((x) => state.getNode(x).status === "healthy");
        if (!r) { warnings.push(`Block ${id} has no live replica: its map task cannot run.`); return; }
        splits.push({ node: r, records: [b.data], note: r === first ? "data-local (primary replica)" : `rescheduled: ${nm(first)} down, using replica on ${nm(r)}` });
      });
      mapFn = (txt) => (txt.toLowerCase().match(/[a-z0-9+\-]+/g) || []).map((w) => [w, 1]);
    } else throw bad("Unknown job");
    const maps = splits.map((sp, i) => {
      const out = sp.records.flatMap(mapFn);
      let comb = out;
      if (useComb) { const m = {}; out.forEach(([k, v]) => (m[k] = (m[k] || 0) + v)); comb = Object.entries(m); }
      return { id: `map-${i}`, node: nm(sp.node), note: sp.note, inRecords: sp.records.length, outRecords: out.length, shuffled: comb.length, pairs: comb };
    });
    const parts = Array.from({ length: R }, () => ({}));
    maps.forEach((m) => m.pairs.forEach(([k, v]) => { const p = hash(k) % R; (parts[p][k] = parts[p][k] || []).push(v); }));
    const reducers = parts.map((p, i) => ({ id: `reduce-${i}`, node: healthy[i % healthy.length].name, keys: Object.keys(p).length, values: Object.values(p).reduce((x, a) => x + a.length, 0) }));
    const result = [];
    parts.forEach((p) => Object.entries(p).forEach(([k, vs]) => result.push({ key: k, value: vs.reduce((x, y) => x + y, 0) })));
    result.sort((a, b) => b.value - a.value || a.key.localeCompare(b.key));
    return {
      title, combiner: useComb, warnings,
      maps: maps.map(({ pairs, ...m }) => m), reducers, result: result.slice(0, 40),
      counters: { mapInput: maps.reduce((x, m) => x + m.inRecords, 0), mapOutput: maps.reduce((x, m) => x + m.outRecords, 0), shuffled: maps.reduce((x, m) => x + m.shuffled, 0), reduceOutput: result.length },
    };
  }));

  // =====================================================================
  // 6. Orchestrator (Kubernetes-style): desired state, scheduler, self-healing, HPA, rolling update
  // =====================================================================
  const kev = (t) => { const k = P().k8s; k.events.unshift({ ts: Date.now(), text: t }); k.events = k.events.slice(0, 40); };
  const podsOn = (n) => P().k8s.pods.filter((p) => p.node === n.id).length;
  function newPod(d, image) {
    const k = P().k8s;
    const cand = state.healthyNodes().filter((n) => podsOn(n) < 8).sort((a, b) => podsOn(a) - podsOn(b));
    const node = cand[0] ? cand[0].id : null;
    const pod = { id: `${d.name}-${Math.random().toString(36).slice(2, 7)}`, deployment: d.name, image, node, status: node ? "Running" : "Pending", createdAt: Date.now() };
    k.pods.push(pod);
    kev(`Scheduler placed ${pod.id} on ${node ? nm(node) : "no node (Pending: no capacity)"}`);
    return pod;
  }
  function reconcile() {
    const k = P().k8s; let changed = 0;
    if (!k.boot) {
      k.boot = true;
      [["blood-api", 3], ["sync-agent", 2], ["alert-service", 1]].forEach(([name, replicas]) => {
        k.deployments[name] = { name, image: `${name}:v1`, replicas, load: 0, autoscale: { enabled: false, min: 1, max: 8, target: 50 } };
      });
    }
    k.pods = k.pods.filter((p) => {
      if (p.node && state.getNode(p.node).status === "failed") { kev(`Node ${nm(p.node)} is NotReady: evicting pod ${p.id}`); changed++; return false; }
      return k.deployments[p.deployment];
    });
    k.pods.forEach((p) => { if (p.status === "Pending") { const n = state.healthyNodes().filter((x) => podsOn(x) < 8).sort((a, b) => podsOn(a) - podsOn(b))[0]; if (n) { p.node = n.id; p.status = "Running"; kev(`Pending pod ${p.id} scheduled on ${n.name}`); changed++; } } });
    Object.values(k.deployments).forEach((d) => {
      if (d.autoscale.enabled) {
        const want = Math.max(d.autoscale.min, Math.min(d.autoscale.max, Math.ceil(d.load / d.autoscale.target) || d.autoscale.min));
        if (want !== d.replicas) { kev(`HPA: ${d.name} load ${d.load} rps (target ${d.autoscale.target}/pod) -> replicas ${d.replicas} -> ${want}`); d.replicas = want; changed++; }
      }
      const mine = k.pods.filter((p) => p.deployment === d.name);
      for (let i = mine.length; i < d.replicas; i++) { newPod(d, d.image); changed++; }
      if (mine.length > d.replicas) {
        mine.slice(d.replicas).forEach((p) => { kev(`ReplicaSet scale-down: terminating ${p.id}`); k.pods = k.pods.filter((x) => x.id !== p.id); changed++; });
      }
    });
    return changed;
  }
  const k8sView = () => {
    reconcile();
    const k = P().k8s;
    return {
      deployments: Object.values(k.deployments).map((d) => ({ ...d, ready: k.pods.filter((p) => p.deployment === d.name && p.status === "Running").length })),
      pods: k.pods.map((p) => ({ ...p, nodeName: p.node ? nm(p.node) : null })),
      nodes: state.getState().nodes.map((n) => ({ id: n.id, name: n.name, status: n.status, pods: podsOn(n) })),
      events: k.events,
    };
  };
  setInterval(() => { try { if (reconcile()) io.emit("k8sUpdate"); } catch (e) { /* ignore */ } }, 2000);
  app.get("/api/k8s", h(() => k8sView()));
  app.post("/api/k8s/deployments", h((req) => {
    reconcile();
    const k = P().k8s, { name, image, replicas } = req.body;
    if (!/^[a-z0-9-]{2,30}$/.test(name || "")) throw bad("Name must be 2-30 chars: lowercase letters, digits, dashes");
    if (k.deployments[name]) throw bad("Deployment already exists");
    k.deployments[name] = { name, image: image || `${name}:v1`, replicas: Math.max(0, Math.min(10, Number(replicas) || 1)), load: 0, autoscale: { enabled: false, min: 1, max: 8, target: 50 } };
    kev(`Deployment ${name} created (${k.deployments[name].replicas} replica(s))`);
    return k8sView();
  }));
  app.post("/api/k8s/scale", h((req) => {
    reconcile();
    const d = P().k8s.deployments[req.body.name];
    if (!d) throw bad("No such deployment", 404);
    d.replicas = Math.max(0, Math.min(10, Number(req.body.replicas)));
    kev(`kubectl scale ${d.name} --replicas=${d.replicas}`);
    return k8sView();
  }));
  app.post("/api/k8s/delete", h((req) => { const k = P().k8s; delete k.deployments[req.body.name]; kev(`Deployment ${req.body.name} deleted`); return k8sView(); }));
  app.post("/api/k8s/kill-pod", h((req) => {
    const k = P().k8s, p = k.pods.find((x) => x.id === req.body.id);
    if (p) { k.pods = k.pods.filter((x) => x.id !== p.id); kev(`Pod ${p.id} crashed (killed by user): controller will recreate it`); }
    return k8sView();
  }));
  app.post("/api/k8s/autoscale", h((req) => {
    reconcile();
    const d = P().k8s.deployments[req.body.name];
    if (!d) throw bad("No such deployment", 404);
    if (req.body.enabled !== undefined) d.autoscale.enabled = !!req.body.enabled;
    if (req.body.load !== undefined) d.load = Math.max(0, Number(req.body.load) || 0);
    if (req.body.target) d.autoscale.target = Math.max(1, Number(req.body.target));
    return k8sView();
  }));
  app.post("/api/k8s/rollout", h((req) => {
    reconcile();
    const k = P().k8s, d = k.deployments[req.body.name];
    if (!d) throw bad("No such deployment", 404);
    const image = req.body.image;
    if (!image) throw bad("Image tag required");
    const old = k.pods.filter((p) => p.deployment === d.name && p.image !== image);
    const steps = [{ kind: "info", text: `Rolling update of ${d.name}: ${d.image} -> ${image} (maxSurge 1, maxUnavailable 0).` }];
    d.image = image;
    old.forEach((o) => {
      const p = newPod(d, image);
      steps.push({ kind: "request", text: `Surge: start new pod ${p.id} (${image}) on ${p.node ? nm(p.node) : "no node"}` });
      k.pods = k.pods.filter((x) => x.id !== o.id);
      steps.push({ kind: "exit", text: `New pod is Ready: terminate old pod ${o.id} (${o.image}). Service never dropped below ${d.replicas} ready pod(s).` });
    });
    if (!old.length) steps.push({ kind: "info", text: "All pods already run this image; nothing to do." });
    kev(`Rollout of ${d.name} to ${image} complete`);
    return { steps, view: k8sView() };
  }));
  app.post("/api/k8s/request", h((req) => {
    reconcile();
    const k = P().k8s, pods = k.pods.filter((p) => p.deployment === req.body.name && p.status === "Running");
    if (!pods.length) throw bad("503: Service has no ready endpoints", 503);
    k.rr[req.body.name] = (k.rr[req.body.name] || 0) + 1;
    const p = pods[k.rr[req.body.name] % pods.length];
    return { pod: p.id, node: nm(p.node), image: p.image };
  }));

  // =====================================================================
  // 7. Software-defined network fabric (Megaport-style ports + virtual cross connects)
  // =====================================================================
  const GEO = { "node-pune": [18.52, 73.86], "node-mumbai": [19.08, 72.88], "node-nashik": [20.0, 73.79], "node-nagpur": [21.15, 79.09], "node-kolhapur": [16.7, 74.24] };
  const km = (a, b) => {
    const A = GEO[a], B = GEO[b]; if (!A || !B) return 100;
    const r = (x) => (x * Math.PI) / 180, dl = r(B[0] - A[0]), dg = r(B[1] - A[1]);
    const q = Math.sin(dl / 2) ** 2 + Math.cos(r(A[0])) * Math.cos(r(B[0])) * Math.sin(dg / 2) ** 2;
    return Math.round(6371 * 2 * Math.atan2(Math.sqrt(q), Math.sqrt(1 - q)));
  };
  const PORT = 1000;
  const netView = () => {
    const nt = P().net, s = state.getState();
    const vxcs = nt.vxcs.map((v) => {
      const up = state.getNode(v.a).status === "healthy" && state.getNode(v.b).status === "healthy";
      const d = km(v.a, v.b);
      return { ...v, aName: nm(v.a), bName: nm(v.b), km: d, rttMs: +(d * 0.01 + 1).toFixed(2), state: up ? "LIVE" : "DOWN", costPerHour: +(v.mbps * 0.002).toFixed(2) };
    });
    return { portMbps: PORT, ports: s.nodes.map((n) => ({ id: n.id, name: n.name, status: n.status, used: nt.vxcs.filter((v) => v.a === n.id || v.b === n.id).reduce((x, v) => x + v.mbps, 0) })), vxcs };
  };
  const used = (id, skip) => P().net.vxcs.filter((v) => v.id !== skip && (v.a === id || v.b === id)).reduce((x, v) => x + v.mbps, 0);
  app.get("/api/net", h(() => netView()));
  app.post("/api/net/vxc", h((req) => {
    const nt = P().net, { a, b } = req.body, mbps = Number(req.body.mbps);
    if (!state.getNode(a) || !state.getNode(b) || a === b) throw bad("Choose two different ports");
    if (!(mbps >= 10)) throw bad("Minimum speed is 10 Mbps");
    if (state.getNode(a).status !== "healthy" || state.getNode(b).status !== "healthy") throw bad("Both ports must be up");
    if (used(a) + mbps > PORT) throw bad(`Port at ${nm(a)} would exceed ${PORT} Mbps (used ${used(a)})`);
    if (used(b) + mbps > PORT) throw bad(`Port at ${nm(b)} would exceed ${PORT} Mbps (used ${used(b)})`);
    nt.vxcs.push({ id: ++nt.vid, a, b, mbps });
    state.persist();
    return netView();
  }));
  app.post("/api/net/resize", h((req) => {
    const v = P().net.vxcs.find((x) => x.id === Number(req.body.id)), mbps = Number(req.body.mbps);
    if (!v) throw bad("No such VXC", 404);
    if (!(mbps >= 10)) throw bad("Minimum speed is 10 Mbps");
    if (used(v.a, v.id) + mbps > PORT || used(v.b, v.id) + mbps > PORT) throw bad("Not enough free capacity on an end port");
    v.mbps = mbps; state.persist();
    return netView();
  }));
  app.post("/api/net/delete", h((req) => { const nt = P().net; nt.vxcs = nt.vxcs.filter((x) => x.id !== Number(req.body.id)); state.persist(); return netView(); }));
  app.post("/api/net/transfer", h((req) => {
    const v = netView().vxcs.find((x) => x.id === Number(req.body.id)), mb = Math.max(1, Number(req.body.sizeMB) || 100);
    if (!v) throw bad("No such VXC", 404);
    if (v.state !== "LIVE") throw bad("VXC is DOWN (an endpoint node has failed)");
    const sec = (mb * 8) / v.mbps + v.rttMs / 1000;
    return { sizeMB: mb, seconds: +sec.toFixed(2), rttMs: v.rttMs, mbps: v.mbps, effectiveMbps: +((mb * 8) / sec).toFixed(1) };
  }));
}

module.exports = { register };
