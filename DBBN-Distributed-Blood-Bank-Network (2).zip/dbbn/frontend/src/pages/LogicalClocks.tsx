import React, { useState } from "react";
import { http } from "../api";
import { usePoll, useAction } from "../components/hooks";
import { PageHeader, Panel, Button, Select } from "../components/ui";

type Ev = { id: number; type: string; node: string; lamport: number; vector: Record<string, number>; label: string; to?: string; from?: string; sendId?: number };

function relation(a: Ev, b: Ev, ids: string[]) {
  const le = ids.every((k) => (a.vector[k] || 0) <= (b.vector[k] || 0));
  const ge = ids.every((k) => (a.vector[k] || 0) >= (b.vector[k] || 0));
  if (le && ge) return "identical";
  if (le) return "A happened-before B (A -> B)";
  if (ge) return "B happened-before A (B -> A)";
  return "A and B are CONCURRENT (neither caused the other)";
}

export default function LogicalClocks() {
  const { data, reload } = usePoll(() => http.get("/logical"), 2000);
  const nodes: any[] = data?.nodes || [];
  const events: Ev[] = data?.events || [];
  const names = nodes.map((n) => n.name);
  const ids = nodes.map((n) => n.id);
  const idOf = (name: string) => nodes.find((n) => n.name === name)?.id;
  const [local, setLocal] = useState("Pune");
  const [from, setFrom] = useState("Pune");
  const [to, setTo] = useState("Mumbai");
  const [sel, setSel] = useState<number[]>([]);
  const { error, run } = useAction();
  const lane = (id: string) => 40 + ids.indexOf(id) * 56;
  const X = (i: number) => 120 + i * 48;
  const pos = (id: number) => events.findIndex((e) => e.id === id);
  const A = events.find((e) => e.id === sel[0]), B = events.find((e) => e.id === sel[1]);
  const pick = (id: number) => setSel((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id].slice(-2)));
  const act = (fn: () => Promise<any>) => run(fn).then(reload);

  return (
    <div>
      <PageHeader title="Logical and Vector Clocks" subtitle="Lamport clocks give a consistent ordering; vector clocks additionally detect which events are concurrent." />
      <Panel className="mb-4">
        <div className="flex flex-wrap items-end gap-3">
          <div className="flex items-end gap-2"><Select value={local} onChange={setLocal} options={names} /><Button variant="secondary" onClick={() => act(() => http.post("/logical/local", { nodeId: idOf(local) }))}>Local event</Button></div>
          <div className="flex items-end gap-2"><Select value={from} onChange={setFrom} options={names} /><span className="text-slate-500 pb-1.5">to</span><Select value={to} onChange={setTo} options={names} /><Button onClick={() => act(() => http.post("/logical/send", { from: idOf(from), to: idOf(to) }))}>Send message</Button></div>
          <Button variant="secondary" onClick={() => act(() => http.post("/logical/scenario"))}>Run blood-request scenario</Button>
          <Button variant="ghost" onClick={() => { setSel([]); act(() => http.post("/logical/reset")); }}>Reset clocks</Button>
        </div>
        {error && <div className="text-sm text-rose-400 mt-2">{error}</div>}
      </Panel>
      <Panel title="Space-time diagram (click two events to compare them)" className="mb-4">
        <div className="overflow-x-auto">
          <svg width={Math.max(700, 160 + events.length * 48)} height={ids.length * 56 + 20}>
            <defs><marker id="arr" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="#38bdf8" /></marker></defs>
            {nodes.map((n) => (<g key={n.id}><line x1={90} x2={Math.max(700, 160 + events.length * 48)} y1={lane(n.id)} y2={lane(n.id)} stroke="#334155" /><text x={8} y={lane(n.id) + 4} fill="#94a3b8" fontSize="12">{n.name}</text></g>))}
            {events.filter((e) => e.type === "receive").map((e) => { const si = pos(e.sendId || -1); if (si < 0) return null; const s = events[si]; return <line key={e.id} x1={X(si)} y1={lane(s.node)} x2={X(pos(e.id))} y2={lane(e.node)} stroke="#38bdf8" strokeOpacity={0.6} markerEnd="url(#arr)" />; })}
            {events.map((e, i) => (
              <g key={e.id} onClick={() => pick(e.id)} className="cursor-pointer">
                <circle cx={X(i)} cy={lane(e.node)} r={11} fill={sel.includes(e.id) ? "#f59e0b" : e.type === "local" ? "#475569" : e.type === "send" ? "#0ea5e9" : "#10b981"} stroke="#0b1120" strokeWidth={2} />
                <text x={X(i)} y={lane(e.node) + 4} textAnchor="middle" fill="white" fontSize="10" fontWeight="700">{e.lamport}</text>
              </g>
            ))}
          </svg>
        </div>
        <div className="text-xs text-slate-500 mt-2">Circle number = Lamport timestamp. Grey = local event, blue = send, green = receive. Arrows show message delivery.</div>
        {A && B && (
          <div className="mt-3 text-sm rounded-lg border border-amber-500/30 bg-amber-500/5 p-3 space-y-1">
            <div className="text-slate-300">A = event #{A.id} ({A.label} at {nodes.find((n) => n.id === A.node)?.name}), Lamport {A.lamport}, vector [{ids.map((k) => A.vector[k]).join(", ")}]</div>
            <div className="text-slate-300">B = event #{B.id} ({B.label} at {nodes.find((n) => n.id === B.node)?.name}), Lamport {B.lamport}, vector [{ids.map((k) => B.vector[k]).join(", ")}]</div>
            <div className="text-amber-300 font-medium">Vector clocks: {relation(A, B, ids)}</div>
            <div className="text-slate-400">Lamport clocks only say L(A)={A.lamport} {A.lamport < B.lamport ? "<" : A.lamport > B.lamport ? ">" : "="} L(B)={B.lamport}; a smaller Lamport value does not prove causality.</div>
          </div>
        )}
      </Panel>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Panel title="Current clocks">
          <table className="w-full text-sm"><thead><tr className="text-left text-slate-400 border-b border-white/10"><th className="py-1.5">Node</th><th>Lamport</th><th>Vector {"[" + names.join(", ") + "]"}</th></tr></thead>
            <tbody>{nodes.map((n) => (<tr key={n.id} className="border-b border-white/5"><td className="py-1.5 text-white">{n.name}</td><td>{n.lamport}</td><td className="font-mono text-xs text-slate-300">[{ids.map((k) => n.vector[k]).join(", ")}]</td></tr>))}</tbody></table>
        </Panel>
        <Panel title="Rules">
          <ul className="text-sm text-slate-400 list-disc list-inside space-y-1">
            <li>Local or send event: clock = clock + 1</li>
            <li>Receive: Lamport = max(local, message) + 1</li>
            <li>Vector: take the element-wise maximum, then increment your own entry</li>
            <li>A happened-before B if every entry of V(A) is at most V(B) and one is smaller</li>
          </ul>
        </Panel>
      </div>
    </div>
  );
}
