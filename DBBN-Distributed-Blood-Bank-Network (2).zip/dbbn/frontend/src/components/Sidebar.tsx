import React from "react";
import { NavLink } from "react-router-dom";
import {
  LayoutDashboard,
  Search,
  Siren,
  Network,
  Server,
  Radio,
  RefreshCw,
  Crown,
  ShieldAlert,
  ListChecks,
  Boxes,
  BookOpen,
  Droplet,
  Clock,
  GitBranch,
  Camera,
  Lock,
  Share2,
  Box,
  Globe,
  HardDrive,
  Zap,
  Shuffle,
  Cable,
} from "lucide-react";
import { useNetwork } from "../store";

const sections = [
  {
    title: "Core system",
    items: [
      { to: "/", label: "Dashboard", icon: LayoutDashboard },
      { to: "/search", label: "Blood Search", icon: Search },
      { to: "/emergency", label: "Emergency Requests", icon: Siren },
      { to: "/topology", label: "Network Topology", icon: Network },
      { to: "/nodes", label: "Node Management", icon: Server },
      { to: "/monitor", label: "Communication Monitor", icon: Radio },
      { to: "/replication", label: "Replication Monitor", icon: RefreshCw },
      { to: "/election", label: "Leader Election", icon: Crown },
      { to: "/fault-tolerance", label: "Fault Tolerance", icon: ShieldAlert },
      { to: "/transactions", label: "Transactions", icon: ListChecks },
      { to: "/infrastructure", label: "Virtual Infrastructure", icon: Boxes },
    ],
  },
  {
    title: "Unit III: Synchronization",
    items: [
      { to: "/clocks", label: "Clock Synchronization", icon: Clock },
      { to: "/logical", label: "Logical and Vector Clocks", icon: GitBranch },
      { to: "/snapshot", label: "Global State Snapshot", icon: Camera },
      { to: "/mutex", label: "Mutual Exclusion", icon: Lock },
      { to: "/beacon", label: "Beacon Protocol", icon: Radio },
      { to: "/deadlock", label: "Deadlock Detection", icon: Share2 },
    ],
  },
  {
    title: "Unit IV: Emerging Paradigms",
    items: [
      { to: "/objects", label: "Distributed Objects", icon: Box },
      { to: "/web", label: "Web Systems", icon: Globe },
      { to: "/dfs", label: "Distributed File System", icon: HardDrive },
      { to: "/serverless", label: "Serverless", icon: Zap },
      { to: "/mapreduce", label: "MapReduce", icon: Shuffle },
      { to: "/orchestrator", label: "Orchestrator", icon: Boxes },
      { to: "/fabric", label: "Network Fabric", icon: Cable },
    ],
  },
  { title: "Reference", items: [{ to: "/concepts", label: "DS Concepts", icon: BookOpen }] },
];

export default function Sidebar() {
  const { connected } = useNetwork();
  return (
    <aside className="w-64 shrink-0 h-screen sticky top-0 bg-ink-900 border-r border-white/5 flex flex-col">
      <div className="px-5 py-5 flex items-center gap-2 border-b border-white/5">
        <div className="w-9 h-9 rounded-lg bg-blood-600 flex items-center justify-center shadow-lg shadow-blood-900/40">
          <Droplet className="w-5 h-5 text-white" fill="white" />
        </div>
        <div>
          <div className="font-bold text-white leading-tight">DBBN</div>
          <div className="text-[11px] text-slate-400 leading-tight">Distributed Blood Bank Network</div>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto py-2 px-2">
        {sections.map((sec) => (
          <div key={sec.title} className="mb-2">
            <div className="px-3 pt-2 pb-1 text-[10px] uppercase tracking-wider text-slate-500">{sec.title}</div>
            {sec.items.map(({ to, label, icon: Icon }) => (
              <NavLink
                key={to}
                to={to}
                end={to === "/"}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-1.5 rounded-lg text-sm transition-colors ${
                    isActive ? "bg-blood-600/15 text-blood-400 font-medium" : "text-slate-400 hover:bg-white/5 hover:text-slate-200"
                  }`
                }
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{label}</span>
              </NavLink>
            ))}
          </div>
        ))}
      </nav>

      <div className="px-4 py-3 border-t border-white/5 flex items-center gap-2 text-xs">
        <span className={`w-2 h-2 rounded-full ${connected ? "bg-emerald-400 pulse-dot" : "bg-rose-500"}`} />
        <span className="text-slate-400">{connected ? "Live socket connected" : "Disconnected"}</span>
      </div>
    </aside>
  );
}
