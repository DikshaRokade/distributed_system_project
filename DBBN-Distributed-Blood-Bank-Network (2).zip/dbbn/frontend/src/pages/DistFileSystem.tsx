import React, { useState } from "react";
import { http } from "../api";
import { usePoll, useAction } from "../components/hooks";
import { PageHeader, Panel, Button, Input } from "../components/ui";
import StepPlayer from "../components/StepPlayer";

const SAMPLE = "Asha O- Pune; Ravi A+ Mumbai; Meera B+ Nashik; Kiran O- Nagpur; Sana AB- Kolhapur; Asha O- Pune; Vikram O+ Mumbai; Neha A- Nashik; Arjun O- Pune";

export default function DistFileSystem() {
  const { data, reload } = usePoll(() => http.get("/dfs"), 1500);
  const [name, setName] = useState("donors.txt");
  const [rep, setRep] = useState(3); const [bs, setBs] = useState(32);
  const [content, setContent] = useState(SAMPLE);
  const [steps, setSteps] = useState<any[]>([]);
  const [read, setRead] = useState<string | null>(null);
  const { error, run } = useAction();
  const act = async (fn: () => Promise<any>) => { const r = await run(fn); reload(); return r; };

  return (
    <div>
      <PageHeader title="Distributed File System (HDFS-style)" subtitle={`Files are split into fixed-size blocks and each block is replicated on several DataNodes. The NameNode (${data?.nameNode || "coordinator"}) keeps only the metadata.`} />
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 mb-4">
        {(data?.usage || []).map((u: any) => (<div key={u.name} className={`rounded-xl border p-3 ${u.status === "healthy" ? "border-white/5 bg-ink-800/60" : "border-rose-500/30 bg-rose-500/10"}`}><div className="text-xs text-slate-400">DataNode {u.name}</div><div className="text-xl font-bold text-white">{u.blocks}</div><div className="text-[11px] text-slate-500">{u.status === "healthy" ? "block replicas" : "DOWN"}</div></div>))}
      </div>
      <Panel title="Upload a file" className="mb-4">
        <div className="flex flex-wrap items-end gap-3 mb-2">
          <div><label className="text-xs text-slate-400 block mb-1">File name</label><Input value={name} onChange={(e) => setName(e.target.value)} className="w-40" /></div>
          <div><label className="text-xs text-slate-400 block mb-1">Replication factor</label><Input type="number" min={1} max={5} value={rep} onChange={(e) => setRep(Number(e.target.value))} className="w-24" /></div>
          <div><label className="text-xs text-slate-400 block mb-1">Block size (chars)</label><Input type="number" min={8} value={bs} onChange={(e) => setBs(Number(e.target.value))} className="w-24" /></div>
          <Button onClick={async () => { const r = await act(() => http.post("/dfs/upload", { name, content, replication: rep, blockSize: bs })); if (r) setSteps(r.steps); }}>Upload</Button>
        </div>
        <textarea value={content} onChange={(e) => setContent(e.target.value)} rows={3} className="w-full bg-ink-700 border border-white/10 rounded-lg px-3 py-2 text-sm font-mono text-slate-200" />
        {error && <div className="text-sm text-rose-400 mt-2">{error}</div>}
      </Panel>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
        <Panel title="NameNode metadata (block map)" className="lg:col-span-2">
          <div className="flex items-center gap-4 text-xs mb-3"><span className={data?.underReplicated ? "text-amber-400" : "text-emerald-400"}>Under-replicated blocks: {data?.underReplicated ?? 0}</span><span className={data?.missingBlocks ? "text-rose-400" : "text-slate-400"}>Missing blocks: {data?.missingBlocks ?? 0}</span>
            <Button variant="secondary" onClick={async () => { const r = await act(() => http.post("/dfs/rereplicate")); if (r) setSteps(r.steps); }}>Run re-replication</Button></div>
          {(data?.files || []).map((f: any) => (
            <div key={f.name} className="mb-4">
              <div className="flex items-center gap-3 mb-1"><span className="text-white font-semibold text-sm">{f.name}</span><span className="text-xs text-slate-500">{f.size} chars, replication {f.replication}</span>
                <Button variant="ghost" onClick={async () => { const r = await act(() => http.get(`/dfs/read/${encodeURIComponent(f.name)}`)); if (r) { setSteps(r.steps); setRead(r.ok ? r.content : "(read failed: missing block)"); } }}>Read</Button>
                <Button variant="ghost" onClick={async () => { await act(() => http.post("/dfs/delete", { name: f.name })); setRead(null); }}>Delete</Button></div>
              <table className="w-full text-xs"><tbody>{f.blocks.map((b: any) => (<tr key={b.id} className="border-b border-white/5"><td className="py-1 font-mono text-slate-400 w-20">{b.id}</td><td className="w-16 text-slate-500">{b.size} ch</td><td><div className="flex gap-1.5">{b.replicas.map((r: any, i: number) => <span key={i} className={`px-2 py-0.5 rounded-full border text-[11px] ${r.healthy ? "border-emerald-500/30 text-emerald-300 bg-emerald-500/5" : "border-rose-500/30 text-rose-300 bg-rose-500/5 line-through"}`}>{r.node}</span>)}</div></td></tr>))}</tbody></table>
            </div>
          ))}
          {!(data?.files || []).length && <div className="text-sm text-slate-500">No files stored yet.</div>}
        </Panel>
        <Panel title="Last read result">{read !== null ? <div className="text-sm font-mono text-slate-300 break-words">{read}</div> : <div className="text-sm text-slate-500">Click Read on a file. Fail a node first to see failover to another replica.</div>}</Panel>
      </div>
      <Panel title="Operation trace"><StepPlayer steps={steps} speed={350} /></Panel>
    </div>
  );
}
