import React, { useState } from "react";
import { http } from "../api";
import { usePoll, useAction } from "../components/hooks";
import { PageHeader, Panel, Button, Select } from "../components/ui";
import StepPlayer from "../components/StepPlayer";

export default function DeadlockDetection() {
  const { data, reload } = usePoll(() => http.get("/deadlock"), 3000);
  const procs: any[] = data?.procs || [];
  const edges: string[][] = data?.edges || [];
  const ids = procs.map((p) => p.id);
  const [a, setA] = useState("T1"); const [b, setB] = useState("T2");
  const [init, setInit] = useState("T1");
  const [res, setRes] = useState<any>(null);
  const [victim, setVictim] = useState("T3");
  const [msg, setMsg] = useState("");
  const { error, run } = useAction();
  const act = (fn: () => Promise<any>) => run(fn).then(reload);
  const cx = 230, cy = 150, R = 105;
  const P = (id: string) => { const i = ids.indexOf(id); const t = (Math.PI * 2 * i) / Math.max(1, ids.length) - Math.PI / 2; return { x: cx + R * Math.cos(t), y: cy + R * Math.sin(t) }; };
  const inCycle = (x: string, y: string) => (res?.cycles || []).some((c: string[]) => c.includes(x) && c.includes(y) && c[(c.indexOf(x) + 1) % c.length] === y);

  return (
    <div>
      <PageHeader title="Distributed Deadlock Detection" subtitle="Transactions at different sites wait for each other's locks. Detect cycles in the wait-for graph with edge chasing (probes) or a centralized global graph." />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
        <Panel title="Wait-for graph (A -> B means A waits for a resource held by B)">
          <svg viewBox="0 0 460 300" className="w-full">
            <defs><marker id="wf" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="#94a3b8" /></marker><marker id="wr" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="#f43f5e" /></marker></defs>
            {edges.map(([x, y], i) => { const p = P(x), q = P(y); const dx = q.x - p.x, dy = q.y - p.y, d = Math.hypot(dx, dy) || 1; const hot = inCycle(x, y); return <line key={i} x1={p.x + (dx / d) * 22} y1={p.y + (dy / d) * 22} x2={q.x - (dx / d) * 26} y2={q.y - (dy / d) * 26} stroke={hot ? "#f43f5e" : "#94a3b8"} strokeWidth={hot ? 2.5 : 1.5} markerEnd={hot ? "url(#wr)" : "url(#wf)"} />; })}
            {procs.map((p) => { const q = P(p.id); return <g key={p.id}><circle cx={q.x} cy={q.y} r={22} fill="#111827" stroke="#38bdf8" strokeWidth={2} /><text x={q.x} y={q.y + 4} textAnchor="middle" fill="white" fontSize="12" fontWeight="700">{p.id}</text><text x={q.x} y={q.y + 38} textAnchor="middle" fill="#64748b" fontSize="9">@{p.siteName}</text></g>; })}
          </svg>
        </Panel>
        <Panel title="Build the graph">
          <div className="flex flex-wrap items-end gap-2 mb-3"><Select value={a} onChange={setA} options={ids} /><span className="text-slate-500 pb-1.5">waits for</span><Select value={b} onChange={setB} options={ids} /><Button onClick={() => act(() => http.post("/deadlock/edge", { from: a, to: b }))}>Add edge</Button></div>
          <div className="flex flex-wrap gap-1.5 mb-3">{edges.map(([x, y]) => <button key={x + y} onClick={() => act(() => http.post("/deadlock/remove-edge", { from: x, to: y }))} className="text-[11px] px-2 py-0.5 rounded-full border border-white/10 text-slate-300 hover:border-rose-500/50" title="click to remove">{x} to {y} x</button>)}{!edges.length && <span className="text-xs text-slate-500">No edges: no process is waiting.</span>}</div>
          <div className="text-xs text-slate-400 mb-1">Presets</div>
          <div className="flex flex-wrap gap-2">{[["cycle", "3-process cycle"], ["two-hospitals", "Two hospitals, opposite lock order"], ["double", "Two separate deadlocks"], ["none", "No deadlock"], ["empty", "Clear"]].map(([k, l]) => <Button key={k} variant="secondary" onClick={() => { setRes(null); act(() => http.post("/deadlock/preset", { name: k })); }}>{l}</Button>)}</div>
        </Panel>
      </div>
      <Panel title="Detect" className="mb-4">
        <div className="flex flex-wrap items-end gap-2">
          <Select value={init} onChange={setInit} options={[...ids, "all"]} />
          <Button onClick={async () => { const r = await run(() => http.post("/deadlock/detect", { algorithm: "edge-chasing", initiator: init })); if (r) { setRes(r); setMsg(""); } }}>Edge chasing (probes)</Button>
          <Button variant="secondary" onClick={async () => { const r = await run(() => http.post("/deadlock/detect", { algorithm: "wfg" })); if (r) { setRes(r); setMsg(""); } }}>Centralized global WFG</Button>
          {res?.deadlocked && <><Select value={victim} onChange={setVictim} options={ids} /><Button variant="danger" onClick={async () => { const r = await run(() => http.post("/deadlock/resolve", { victim })); if (r) { setMsg(r.text); setRes(null); reload(); } }}>Abort victim</Button></>}
        </div>
        {error && <div className="text-sm text-rose-400 mt-2">{error}</div>}
        {msg && <div className="text-sm text-emerald-400 mt-2">{msg}</div>}
        {res && <div className={`text-sm mt-3 font-medium ${res.deadlocked ? "text-rose-400" : "text-emerald-400"}`}>{res.deadlocked ? `Deadlock: ${res.cycles.map((c: string[]) => c.join(" -> ") + " -> " + c[0]).join(" ; ")}` : "No deadlock found."} <span className="text-slate-500 font-normal">({res.messages} messages, {res.interSite} inter-site)</span></div>}
      </Panel>
      <Panel title="Trace"><StepPlayer steps={res?.steps || []} speed={350} /></Panel>
    </div>
  );
}
