// state.js — in-memory representation of the distributed blood bank network.
// This plays the role of each node's local database + the middleware's service registry.
const fs = require("fs");
const path = require("path");

const DATA_FILE = path.join(__dirname, "data.json");
const BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];

function randomInventory(seed) {
  const inv = {};
  BLOOD_GROUPS.forEach((bg, i) => {
    // deterministic-ish spread so demo data looks reasonable but varies per node
    inv[bg] = Math.max(0, Math.round(8 + Math.sin(seed * 3 + i) * 10 + (seed % 5) * 4));
  });
  return inv;
}

const NODE_DEFS = [
  { id: "node-pune", name: "Pune", ip: "10.10.1.1", port: 7001 },
  { id: "node-mumbai", name: "Mumbai", ip: "10.10.1.2", port: 7002 },
  { id: "node-nashik", name: "Nashik", ip: "10.10.1.3", port: 7003 },
  { id: "node-nagpur", name: "Nagpur", ip: "10.10.1.4", port: 7004 },
  { id: "node-kolhapur", name: "Kolhapur", ip: "10.10.1.5", port: 7005 },
];

function defaultState() {
  const nodes = NODE_DEFS.map((def, idx) => ({
    ...def,
    numericId: idx + 1, // used by the Bully algorithm (higher numericId = higher priority)
    status: "healthy", // healthy | failed
    workload: Math.round(10 + Math.random() * 30),
    inventory: randomInventory(idx + 1),
    locks: {}, // bloodGroup -> boolean (distributed lock held on this node)
    lastHeartbeat: Date.now(),
  }));

  return {
    nodes,
    coordinatorId: nodes[nodes.length - 1].id, // highest numericId starts as coordinator
    registry: Object.fromEntries(
      nodes.map((n) => [n.name.toLowerCase(), { id: n.id, ip: n.ip, port: n.port }])
    ),
    logs: [], // communication monitor: {ts, type: RPC|MESSAGE|P2P|ELECTION, from, to, summary}
    transactions: [], // {id, status, hospital, bloodGroup, units, steps:[], createdAt}
    emergencyRequests: [], // {id, hospital, bloodGroup, units, status, createdAt}
    electionHistory: [], // list of past elections
    replicationLog: [], // {ts, from, to, bloodGroup, delta, status}
    broadcasts: [], // emergency shortage broadcasts
  };
}

let state = load();

function load() {
  if (fs.existsSync(DATA_FILE)) {
    try {
      const raw = JSON.parse(fs.readFileSync(DATA_FILE, "utf-8"));
      return raw;
    } catch (e) {
      console.warn("Could not parse data.json, starting fresh:", e.message);
    }
  }
  return defaultState();
}

let saveTimer = null;
function persist() {
  // debounce disk writes so bursts of activity don't thrash the filesystem
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    fs.writeFileSync(DATA_FILE, JSON.stringify(state, null, 2));
  }, 150);
}

function getState() {
  return state;
}

function resetState() {
  state = defaultState();
  persist();
  return state;
}

function getNode(id) {
  return state.nodes.find((n) => n.id === id);
}

function healthyNodes() {
  return state.nodes.filter((n) => n.status === "healthy");
}

// Lazily-created extension state (used by sync.js / paradigms.js). Survives
// resetState() because it is re-initialised on first access.
function ext(key, init) {
  if (!state[key]) state[key] = init(state);
  return state[key];
}

module.exports = {
  ext,
  BLOOD_GROUPS,
  getState,
  resetState,
  getNode,
  healthyNodes,
  persist,
};
