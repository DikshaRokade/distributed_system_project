// sync.js — Unit III (Synchronization): clock synchronization (Cristian, Berkeley),
// Lamport & vector clocks, Chandy-Lamport global snapshot, mutual exclusion
// (centralized, Ricart-Agrawala, token ring), ring election, beacon protocol,
// and distributed deadlock detection (edge chasing + global WFG).
const state = require("./state");

const rnd = (a, b) => a + Math.random() * (b - a);
const ri = (a, b) => Math.floor(rnd(a, b + 1));
const bad = (m, status = 400) => { const e = new Error(m); e.status = status; return e; };
const shuffle = (arr) => { const a = [...arr]; for (let i = a.length - 1; i > 0; i--) { const j = ri(0, i); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const total = (n) => Object.values(n.inventory).reduce((x, y) => x + y, 0);
const nm = (id) => (state.getNode(id) || { name: id }).name;
const num = (id) => (state.getNode(id) || { numericId: 0 }).numericId;

function init(s) {
  const offsets = [3200, -1800, 900, -4100, 2500];
  const clockOffsets = {}, lamport = {}, vector = {};
  s.nodes.forEach((n, i) => {
    clockOffsets[n.id] = offsets[i % 5];
    lamport[n.id] = 0;
    vector[n.id] = Object.fromEntries(s.nodes.map((m) => [m.id, 0]));
  });
  const procs = ["T1", "T2", "T3", "T4", "T5"].map((id, i) => ({ id, site: s.nodes[i % s.nodes.length].id }));
  return {
    clockOffsets, lamport, vector, events: [], eid: 0,
    transfers: [], tid: 0,
    beacon: { intervalMs: 2000, timeoutMs: 6000, muted: {}, lastSeen: {}, prev: {}, seq: 0, events: [] },
    deadlock: { procs, edges: [["T1", "T2"], ["T2", "T3"], ["T3", "T1"]] },
    ledger: [],
  };
}
const E = () => state.ext("sync", init);

// ---------------- Clock synchronization ----------------
function cristian(nodeId) {
  const e = E();
  const n = state.getNode(nodeId);
  if (!n || n.status !== "healthy") throw bad("Node unavailable");
  const d1 = ri(20, 120), d2 = ri(20, 120);
  const before = e.clockOffsets[nodeId];
  const rtt = d1 + d2;
  const serverTime = d1; // server clock reading, relative to the true time at request send
  const estimate = serverTime + rtt / 2; // Cristian: T_server + RTT/2
  const trueAtReceive = d1 + d2;
  e.clockOffsets[nodeId] = Math.round(estimate - trueAtReceive);
  state.persist();
  const steps = [
    { kind: "info", text: `${n.name} clock is off by ${before >= 0 ? "+" : ""}${before} ms relative to the UTC time server.` },
    { kind: "request", from: nodeId, text: `${n.name} sends time request at its local time T0 (request delay ${d1} ms).` },
    { kind: "reply", to: nodeId, text: `Time server replies with its time Ts (reply delay ${d2} ms).` },
    { kind: "info", text: `${n.name} measures round trip RTT = ${rtt} ms and estimates the server delay as RTT/2 = ${rtt / 2} ms.` },
    { kind: "enter", text: `New time = Ts + RTT/2. Residual error = |d2 - d1| / 2 = ${Math.abs(d2 - d1) / 2} ms (because the two delays are asymmetric).` },
  ];
  return { steps, before: { [nodeId]: before }, after: { [nodeId]: e.clockOffsets[nodeId] } };
}

function berkeley(threshold) {
  const e = E(), s = state.getState();
  const coord = state.getNode(s.coordinatorId);
  if (!coord || coord.status !== "healthy") throw bad("Coordinator (time daemon) is not healthy");
  const nodes = state.healthyNodes();
  const before = {};
  nodes.forEach((n) => (before[n.id] = e.clockOffsets[n.id]));
  const steps = [{ kind: "info", text: `Time daemon = coordinator ${coord.name}. It polls every healthy node for its clock.` }];
  const diffs = {};
  nodes.forEach((n) => {
    const d = e.clockOffsets[n.id] - e.clockOffsets[coord.id];
    diffs[n.id] = d;
    if (n.id !== coord.id) steps.push({ kind: "request", from: coord.id, to: n.id, text: `${coord.name} polls ${n.name} -> clock differs by ${d >= 0 ? "+" : ""}${d} ms` });
  });
  const included = nodes.filter((n) => Math.abs(diffs[n.id]) <= threshold);
  nodes.filter((n) => Math.abs(diffs[n.id]) > threshold).forEach((n) =>
    steps.push({ kind: "defer", text: `${n.name} differs by ${diffs[n.id]} ms (more than ${threshold} ms): excluded from the average (faulty clock).` }));
  const avg = Math.round(included.reduce((a, n) => a + diffs[n.id], 0) / included.length);
  steps.push({ kind: "info", text: `Average difference over ${included.length} clocks = ${avg >= 0 ? "+" : ""}${avg} ms.` });
  nodes.forEach((n) => {
    const adj = avg - diffs[n.id];
    e.clockOffsets[n.id] += adj;
    steps.push({ kind: "reply", from: coord.id, to: n.id, text: `Coordinator tells ${n.name} to adjust its clock by ${adj >= 0 ? "+" : ""}${adj} ms (a relative adjustment, not an absolute time).` });
  });
  const after = {};
  nodes.forEach((n) => (after[n.id] = e.clockOffsets[n.id]));
  const spread = (o) => { const v = Object.values(o); return Math.max(...v) - Math.min(...v); };
  steps.push({ kind: "enter", text: `Maximum difference between clocks: ${spread(before)} ms before, ${spread(after)} ms after.` });
  state.persist();
  return { steps, before, after };
}

// ---------------- Logical & vector clocks ----------------
function record(e, type, node, label, extra = {}) {
  e.eid++;
  const ev = { id: e.eid, type, node, lamport: e.lamport[node], vector: { ...e.vector[node] }, label, ...extra };
  e.events.push(ev);
  if (e.events.length > 60) e.events.shift();
  return ev;
}
function localEvent(nodeId) {
  const e = E(), n = state.getNode(nodeId);
  if (!n || n.status !== "healthy") throw bad("Node unavailable");
  e.lamport[nodeId]++; e.vector[nodeId][nodeId]++;
  return record(e, "local", nodeId, "local event");
}
function sendMsg(from, to) {
  const e = E(), a = state.getNode(from), b = state.getNode(to);
  if (!a || !b || a.status !== "healthy" || b.status !== "healthy" || from === to) throw bad("Choose two different healthy nodes");
  e.lamport[from]++; e.vector[from][from]++;
  const snd = record(e, "send", from, `send to ${b.name}`, { to });
  e.lamport[to] = Math.max(e.lamport[to], snd.lamport) + 1;
  for (const k in e.vector[to]) e.vector[to][k] = Math.max(e.vector[to][k], snd.vector[k] || 0);
  e.vector[to][to]++;
  const rcv = record(e, "receive", to, `receive from ${a.name}`, { from, sendId: snd.id });
  return { send: snd, receive: rcv };
}

// ---------------- Chandy-Lamport snapshot ----------------
function snapshotRun(initiator) {
  const e = E();
  const nodes = state.healthyNodes();
  const ids = nodes.map((n) => n.id);
  if (!ids.includes(initiator)) throw bad("Initiator must be a healthy node");
  const tot = {};
  nodes.forEach((n) => (tot[n.id] = total(n)));
  const chan = {};
  ids.forEach((a) => ids.forEach((b) => { if (a !== b) chan[`${a}>${b}`] = []; }));
  e.transfers.forEach((t) => { if (chan[`${t.from}>${t.to}`]) chan[`${t.from}>${t.to}`].push({ kind: "msg", units: t.units, bg: t.bloodGroup }); });
  const expected = Object.values(tot).reduce((x, y) => x + y, 0) + e.transfers.filter((t) => chan[`${t.from}>${t.to}`]).reduce((x, t) => x + t.units, 0);
  const recorded = {}, chanState = {}, markerSeen = {}, recording = {};
  const steps = [];
  const record = (n, via) => {
    recorded[n] = tot[n];
    steps.push({ kind: "enter", text: `${nm(n)} records its local state: ${tot[n]} units${via ? ` (first marker came from ${nm(via)}; channel ${nm(via)}->${nm(n)} recorded as empty)` : " (initiator)"}.` });
    ids.forEach((m) => { if (m !== n && m !== via) recording[`${m}>${n}`] = true; });
    ids.forEach((m) => { if (m !== n) chan[`${n}>${m}`].push({ kind: "marker" }); });
    steps.push({ kind: "request", from: n, text: `${nm(n)} sends MARKER on all ${ids.length - 1} outgoing channels.` });
  };
  steps.push({ kind: "info", text: `Initiator ${nm(initiator)} starts the Chandy-Lamport snapshot. ${e.transfers.length} transfer message(s) are currently in flight.` });
  record(initiator, null);
  let guard = 0;
  while (guard++ < 2000) {
    const keys = Object.keys(chan).filter((k) => chan[k].length);
    if (!keys.length) break;
    const k = keys[ri(0, keys.length - 1)];
    const msg = chan[k].shift();
    const [from, to] = k.split(">");
    if (msg.kind === "msg") {
      tot[to] += msg.units;
      if (recorded[to] !== undefined && recording[k] && !markerSeen[k]) {
        (chanState[k] = chanState[k] || []).push(msg);
        steps.push({ kind: "defer", from, to, text: `${nm(to)} receives ${msg.units} units of ${msg.bg} from ${nm(from)} AFTER recording its state but BEFORE the marker on this channel: message becomes part of the channel state.` });
      } else {
        steps.push({ kind: "reply", from, to, text: `${nm(to)} receives ${msg.units} units of ${msg.bg} from ${nm(from)} (already reflected in recorded state or sent before the sender recorded).` });
      }
    } else {
      markerSeen[k] = true; recording[k] = false;
      if (recorded[to] === undefined) { chanState[k] = []; record(to, from); }
      else steps.push({ kind: "exit", from, to, text: `${nm(to)} receives MARKER from ${nm(from)}: stops recording that channel.` });
    }
  }
  const nodeStates = ids.map((id) => ({ id, name: nm(id), units: recorded[id] }));
  const channelStates = Object.entries(chanState).filter(([, v]) => v.length).map(([k, v]) => {
    const [a, b] = k.split(">");
    return { channel: `${nm(a)} -> ${nm(b)}`, messages: v.length, units: v.reduce((x, m) => x + m.units, 0) };
  });
  const snapTotal = nodeStates.reduce((x, n) => x + n.units, 0) + channelStates.reduce((x, c) => x + c.units, 0);
  steps.push({ kind: "enter", text: `Snapshot complete. Sum of recorded node states + channel states = ${snapTotal}. Actual system total = ${expected}. ${snapTotal === expected ? "The snapshot is a consistent global state (units conserved)." : "MISMATCH"}` });
  return { steps, nodeStates, channelStates, snapTotal, expected, consistent: snapTotal === expected };
}

// ---------------- Mutual exclusion ----------------
function mutexRun(algorithm, reqIds) {
  const e = E();
  const nodes = state.healthyNodes();
  const reqs = reqIds.filter((id) => nodes.some((n) => n.id === id));
  if (!reqs.length) throw bad("Select at least one healthy requesting node");
  const N = nodes.length;
  const steps = [];
  let order = [], messages = 0;
  if (algorithm === "centralized") {
    const c = state.getNode(state.getState().coordinatorId);
    const arrival = shuffle(reqs);
    steps.push({ kind: "info", text: `Centralized algorithm: coordinator ${c.name} owns the permission token for the critical section.` });
    arrival.forEach((r) => { steps.push({ kind: "request", from: r, to: c.id, text: `${nm(r)} -> ${c.name}: REQUEST` }); messages++; });
    arrival.forEach((r, i) => {
      steps.push({ kind: "reply", from: c.id, to: r, text: `${c.name} -> ${nm(r)}: GRANT${i ? " (was queued FIFO)" : ""}` });
      steps.push({ kind: "enter", text: `${nm(r)} ENTERS the critical section (central blood ledger).` });
      steps.push({ kind: "exit", from: r, to: c.id, text: `${nm(r)} leaves the critical section and sends RELEASE.` });
      messages += 2; order.push(r);
    });
  } else if (algorithm === "ricart-agrawala") {
    const ts = {};
    reqs.forEach((r) => (ts[r] = ri(1, 3)));
    const pri = (a, b) => ts[a] < ts[b] || (ts[a] === ts[b] && num(a) < num(b));
    steps.push({ kind: "info", text: `Ricart-Agrawala: no coordinator. A node may enter only after ALL ${N - 1} other nodes reply. Priority = (Lamport timestamp, node id), lowest wins.` });
    reqs.forEach((r) => { steps.push({ kind: "request", from: r, text: `${nm(r)} multicasts REQUEST(ts=${ts[r]}, id=${num(r)}) to ${N - 1} nodes.` }); messages += N - 1; });
    const deferred = {};
    reqs.forEach((r) => (deferred[r] = []));
    reqs.forEach((i) => nodes.forEach((j) => {
      if (j.id === i) return;
      if (reqs.includes(j.id) && pri(j.id, i)) {
        deferred[j.id].push(i);
        steps.push({ kind: "defer", from: j.id, to: i, text: `${j.name} DEFERS its reply to ${nm(i)}: its own request (${ts[j.id]},${j.numericId}) has higher priority.` });
      } else {
        steps.push({ kind: "reply", from: j.id, to: i, text: `${j.name} replies OK to ${nm(i)}${reqs.includes(j.id) ? " (the other request has priority)" : " (not interested in the critical section)"}.` });
        messages++;
      }
    }));
    order = [...reqs].sort((a, b) => (pri(a, b) ? -1 : 1));
    order.forEach((r) => {
      steps.push({ kind: "enter", text: `${nm(r)} has received all ${N - 1} replies and ENTERS the critical section.` });
      const d = deferred[r];
      steps.push({ kind: "exit", from: r, text: `${nm(r)} exits${d.length ? ` and sends deferred replies to ${d.map(nm).join(", ")}` : ""}.` });
      messages += d.length;
    });
  } else if (algorithm === "token-ring") {
    const ring = [...nodes].sort((a, b) => a.numericId - b.numericId);
    steps.push({ kind: "info", text: `Token ring: logical ring ${ring.map((n) => n.name).join(" -> ")} -> (back). Only the token holder may enter the critical section.` });
    const waiting = new Set(reqs);
    let i = 0, guard = 0;
    while (waiting.size && guard++ < 100) {
      const cur = ring[i % ring.length];
      if (waiting.has(cur.id)) {
        steps.push({ kind: "enter", text: `${cur.name} holds the TOKEN and has a pending request: ENTERS the critical section.` });
        steps.push({ kind: "exit", from: cur.id, text: `${cur.name} exits the critical section.` });
        waiting.delete(cur.id); order.push(cur.id);
        if (!waiting.size) break;
      }
      const nxt = ring[(i + 1) % ring.length];
      steps.push({ kind: "token", from: cur.id, to: nxt.id, text: `Token passes ${cur.name} -> ${nxt.name}${waiting.has(nxt.id) ? "" : " (no request, passes on)"}` });
      messages++; i++;
    }
  } else throw bad("Unknown algorithm");
  order.forEach((id, k) => e.ledger.push({ seq: e.ledger.length + 1, node: nm(id), algorithm, ts: Date.now() }));
  e.ledger = e.ledger.slice(-30);
  state.persist();
  return { algorithm, steps, order: order.map(nm), messages, perEntry: +(messages / order.length).toFixed(2), ledger: e.ledger.slice(-12) };
}

// ---------------- Ring election ----------------
function ringElection(initiatorId, logic) {
  const s = state.getState();
  const ring = state.healthyNodes().sort((a, b) => a.numericId - b.numericId);
  const start = ring.findIndex((n) => n.id === initiatorId);
  if (start < 0) throw bad("Initiator must be a healthy node");
  const steps = [{ kind: "info", text: `Ring election started by ${ring[start].name}. Ring order (by id): ${ring.map((n) => n.name).join(" -> ")}.` }];
  const ids = [ring[start].numericId];
  let msgs = 0;
  for (let k = 0; k < ring.length; k++) {
    const a = ring[(start + k) % ring.length], b = ring[(start + k + 1) % ring.length];
    steps.push({ kind: "election", from: a.id, to: b.id, text: `${a.name} -> ${b.name}: ELECTION [${ids.join(", ")}]` });
    msgs++;
    if (b.id !== ring[start].id) ids.push(b.numericId);
  }
  const winner = ring.reduce((m, n) => (n.numericId > m.numericId ? n : m), ring[0]);
  steps.push({ kind: "enter", text: `Message returned to initiator with all live ids [${ids.join(", ")}]. Highest id = ${winner.numericId} (${winner.name}).` });
  for (let k = 0; k < ring.length; k++) {
    const a = ring[(start + k) % ring.length], b = ring[(start + k + 1) % ring.length];
    steps.push({ kind: "token", from: a.id, to: b.id, text: `${a.name} -> ${b.name}: COORDINATOR(${winner.name})` });
    msgs++;
  }
  s.coordinatorId = winner.id;
  state.persist();
  logic.log({ type: "ELECTION", from: initiatorId, to: "ALL", summary: `Ring election finished: ${winner.name} is coordinator (${msgs} messages)`, ok: true });
  logic.pushDashboard();
  steps.push({ kind: "enter", text: `${winner.name} is the new coordinator. Total messages: ${msgs} (2N for N=${ring.length}).` });
  return { steps, coordinatorId: winner.id, messages: msgs };
}

// ---------------- Deadlock detection ----------------
const site = (d, id) => (d.procs.find((p) => p.id === id) || {}).site;
function edgeChase(d, init) {
  const out = (id) => d.edges.filter((e) => e[0] === id).map((e) => e[1]);
  const steps = [{ kind: "info", text: `Chandy-Misra-Haas edge chasing: ${init} (blocked at ${nm(site(d, init))}) sends probes along its wait-for edges.` }];
  const queue = [], visited = new Set(), parent = {};
  let msgs = 0, inter = 0, found = null;
  out(init).forEach((k) => queue.push([init, init, k]));
  if (!queue.length) steps.push({ kind: "info", text: `${init} is not waiting for anything, so it cannot be deadlocked.` });
  while (queue.length && !found) {
    const [i, j, k] = queue.shift();
    msgs++;
    const cross = site(d, j) !== site(d, k);
    if (cross) inter++;
    steps.push({ kind: "probe", from: site(d, j), to: site(d, k), text: `probe(${i}, ${j}, ${k}): ${j}@${nm(site(d, j))} -> ${k}@${nm(site(d, k))} ${cross ? "(inter-site message)" : "(same site)"}` });
    if (k === i) { found = j; steps.push({ kind: "deadlock", text: `${i} received its own probe back: DEADLOCK detected.` }); break; }
    if (visited.has(k)) { steps.push({ kind: "info", text: `${k} already forwarded a probe for ${i}: discarded.` }); continue; }
    visited.add(k); parent[k] = j;
    const o = out(k);
    if (!o.length) steps.push({ kind: "info", text: `${k} is not blocked: probe discarded.` });
    else o.forEach((l) => queue.push([i, k, l]));
  }
  let cycle = null;
  if (found) { cycle = [found]; let cur = found; while (cur !== init) { cur = parent[cur]; cycle.unshift(cur); } }
  else if (queue.length === 0 && out(init).length) steps.push({ kind: "info", text: `No probe returned to ${init}: it is not part of a deadlock.` });
  return { deadlocked: !!found, cycle, steps, messages: msgs, interSite: inter };
}
function sccCycles(d) {
  const ids = d.procs.map((p) => p.id);
  const adj = (v) => d.edges.filter((e) => e[0] === v).map((e) => e[1]);
  let idx = 0; const st = [], on = new Set(), index = {}, low = {}, res = [];
  const dfs = (v) => {
    index[v] = low[v] = idx++; st.push(v); on.add(v);
    adj(v).forEach((w) => { if (index[w] === undefined) { dfs(w); low[v] = Math.min(low[v], low[w]); } else if (on.has(w)) low[v] = Math.min(low[v], index[w]); });
    if (low[v] === index[v]) { const c = []; let w; do { w = st.pop(); on.delete(w); c.push(w); } while (w !== v); if (c.length > 1) res.push(c.reverse()); }
  };
  ids.forEach((v) => { if (index[v] === undefined) dfs(v); });
  return res;
}

// ---------------- Routes ----------------
function register(app, logic, io) {
  const h = (fn) => async (req, res) => {
    try { const r = await fn(req, res); if (r !== undefined && !res.headersSent) res.json(r); }
    catch (err) { res.status(err.status || 500).json({ error: err.message }); }
  };

  app.get("/api/sync/clocks", h(() => {
    const e = E(), s = state.getState();
    return { coordinatorId: s.coordinatorId, nodes: s.nodes.map((n) => ({ id: n.id, name: n.name, status: n.status, offset: e.clockOffsets[n.id] || 0 })) };
  }));
  app.post("/api/sync/cristian", h((req) => cristian(req.body.nodeId)));
  app.post("/api/sync/berkeley", h((req) => berkeley(Number(req.body.threshold) || 5000)));
  app.post("/api/sync/skew", h((req) => {
    const e = E();
    if (!state.getNode(req.body.nodeId)) throw bad("Unknown node");
    e.clockOffsets[req.body.nodeId] += Number(req.body.deltaMs) || 0;
    state.persist();
    return { ok: true };
  }));

  app.get("/api/logical", h(() => {
    const e = E();
    return { nodes: state.getState().nodes.map((n) => ({ id: n.id, name: n.name, status: n.status, lamport: e.lamport[n.id], vector: e.vector[n.id] })), events: e.events };
  }));
  app.post("/api/logical/local", h((req) => localEvent(req.body.nodeId)));
  app.post("/api/logical/send", h((req) => sendMsg(req.body.from, req.body.to)));
  app.post("/api/logical/scenario", h(() => {
    const c = state.getState().coordinatorId;
    const others = state.healthyNodes().filter((n) => n.id !== c);
    if (!others.length) throw bad("Need at least two healthy nodes");
    others.forEach((n) => sendMsg(c, n.id));
    others.forEach((n) => localEvent(n.id));
    others.forEach((n) => sendMsg(n.id, c));
    return { ok: true };
  }));
  app.post("/api/logical/reset", h(() => {
    const e = E();
    state.getState().nodes.forEach((n) => { e.lamport[n.id] = 0; Object.keys(e.vector[n.id]).forEach((k) => (e.vector[n.id][k] = 0)); });
    e.events = []; e.eid = 0;
    return { ok: true };
  }));

  app.get("/api/snapshot", h(() => {
    const e = E();
    return {
      nodes: state.getState().nodes.map((n) => ({ id: n.id, name: n.name, status: n.status, units: total(n) })),
      transfers: e.transfers.map((t) => ({ ...t, fromName: nm(t.from), toName: nm(t.to) })),
    };
  }));
  app.post("/api/snapshot/transfer", h((req) => {
    const e = E();
    const { from, to, bloodGroup, units } = req.body;
    const a = state.getNode(from), b = state.getNode(to), u = Number(units);
    if (!a || !b || a.status !== "healthy" || b.status !== "healthy" || from === to) throw bad("Choose two different healthy nodes");
    if (!(u > 0) || (a.inventory[bloodGroup] || 0) < u) throw bad(`${a.name} does not have ${u} units of ${bloodGroup}`);
    a.inventory[bloodGroup] -= u;
    e.transfers.push({ id: ++e.tid, from, to, bloodGroup, units: u });
    state.persist();
    logic.pushDashboard();
    return { ok: true };
  }));
  app.post("/api/snapshot/random", h((req) => {
    const e = E();
    const hn = state.healthyNodes();
    if (hn.length < 2) throw bad("Need two healthy nodes");
    for (let i = 0; i < (Number(req.body.count) || 4); i++) {
      const [a, b] = shuffle(hn);
      const groups = Object.keys(a.inventory).filter((g) => a.inventory[g] > 2);
      if (!groups.length) continue;
      const g = groups[ri(0, groups.length - 1)], u = ri(1, Math.min(4, a.inventory[g]));
      a.inventory[g] -= u;
      e.transfers.push({ id: ++e.tid, from: a.id, to: b.id, bloodGroup: g, units: u });
    }
    state.persist(); logic.pushDashboard();
    return { ok: true };
  }));
  app.post("/api/snapshot/deliver", h(() => {
    const e = E();
    e.transfers.forEach((t) => { const b = state.getNode(t.to); if (b) b.inventory[t.bloodGroup] += t.units; });
    const n = e.transfers.length;
    e.transfers = [];
    state.persist(); logic.pushDashboard();
    return { delivered: n };
  }));
  app.post("/api/snapshot/run", h((req) => snapshotRun(req.body.initiator)));

  app.post("/api/mutex/run", h((req) => mutexRun(req.body.algorithm, req.body.requesters || [])));
  app.get("/api/mutex/ledger", h(() => E().ledger.slice(-12)));
  app.post("/api/election/ring", h((req) => ringElection(req.body.initiator, logic)));

  // ----- Beacon protocol -----
  const b0 = E().beacon;
  b0.lastSeen = {}; b0.muted = {}; b0.prev = {};
  let timer = null;
  const bev = (text, kind) => { const b = E().beacon; b.events.unshift({ ts: Date.now(), text, kind }); b.events = b.events.slice(0, 30); };
  const tick = () => {
    const b = E().beacon, now = Date.now();
    b.seq++;
    state.getState().nodes.forEach((n) => {
      if (n.status === "healthy" && b.prev[n.id] === "failed") { b.muted[n.id] = false; b.lastSeen[n.id] = now; bev(`${n.name} is back: beacons resumed`, "ok"); }
      b.prev[n.id] = n.status;
      if (n.status === "healthy" && !b.muted[n.id]) { b.lastSeen[n.id] = now; io.emit("beacon", { from: n.id, seq: b.seq, ts: now }); }
      if (b.lastSeen[n.id] === undefined) b.lastSeen[n.id] = now;
    });
    state.getState().nodes.forEach((n) => {
      if (n.status === "healthy" && now - b.lastSeen[n.id] > b.timeoutMs) {
        bev(`No beacon from ${n.name} for ${now - b.lastSeen[n.id]} ms (timeout ${b.timeoutMs} ms): declared FAILED`, "fail");
        logic.log({ type: "MESSAGE", from: "beacon-monitor", to: n.id, summary: `Beacon timeout: ${n.name} declared failed`, ok: false });
        logic.failNode(n.id);
        b.prev[n.id] = "failed";
      }
    });
  };
  const schedule = () => { if (timer) clearInterval(timer); timer = setInterval(tick, E().beacon.intervalMs); };
  schedule();
  app.get("/api/beacon", h(() => {
    const b = E().beacon, now = Date.now();
    return {
      intervalMs: b.intervalMs, timeoutMs: b.timeoutMs, events: b.events,
      nodes: state.getState().nodes.map((n) => {
        const ago = b.lastSeen[n.id] ? now - b.lastSeen[n.id] : 0;
        const st = n.status === "failed" ? "failed" : ago > b.intervalMs * 2 ? "suspect" : "alive";
        return { id: n.id, name: n.name, status: st, muted: !!b.muted[n.id], agoMs: ago };
      }),
    };
  }));
  app.post("/api/beacon/config", h((req) => {
    const b = E().beacon;
    const iv = Math.max(500, Math.min(5000, Number(req.body.intervalMs) || b.intervalMs));
    const to = Math.max(iv * 2, Math.min(30000, Number(req.body.timeoutMs) || b.timeoutMs));
    b.intervalMs = iv; b.timeoutMs = to;
    schedule(); state.persist();
    return { ok: true };
  }));
  app.post("/api/beacon/mute", h((req) => {
    const b = E().beacon, n = state.getNode(req.body.nodeId);
    if (!n || n.status !== "healthy") throw bad("Node must be healthy");
    b.muted[n.id] = !!req.body.muted;
    bev(`${n.name} ${b.muted[n.id] ? "stopped sending beacons (silent crash)" : "resumed beacons"}`, b.muted[n.id] ? "warn" : "ok");
    return { ok: true };
  }));

  // ----- Deadlock detection -----
  app.get("/api/deadlock", h(() => { const d = E().deadlock; return { procs: d.procs.map((p) => ({ ...p, siteName: nm(p.site) })), edges: d.edges }; }));
  app.post("/api/deadlock/edge", h((req) => {
    const d = E().deadlock, { from, to } = req.body;
    if (from === to || !d.procs.some((p) => p.id === from) || !d.procs.some((p) => p.id === to)) throw bad("Invalid edge");
    if (!d.edges.some((e) => e[0] === from && e[1] === to)) d.edges.push([from, to]);
    state.persist();
    return { ok: true };
  }));
  app.post("/api/deadlock/remove-edge", h((req) => {
    const d = E().deadlock;
    d.edges = d.edges.filter((e) => !(e[0] === req.body.from && e[1] === req.body.to));
    state.persist();
    return { ok: true };
  }));
  app.post("/api/deadlock/preset", h((req) => {
    const d = E().deadlock;
    const presets = {
      cycle: [["T1", "T2"], ["T2", "T3"], ["T3", "T1"]],
      none: [["T1", "T2"], ["T2", "T3"], ["T4", "T3"]],
      "two-hospitals": [["T1", "T2"], ["T2", "T1"]],
      double: [["T1", "T2"], ["T2", "T1"], ["T3", "T4"], ["T4", "T5"], ["T5", "T3"]],
      empty: [],
    };
    if (!presets[req.body.name]) throw bad("Unknown preset");
    d.edges = presets[req.body.name].map((x) => [...x]);
    state.persist();
    return { ok: true };
  }));
  app.post("/api/deadlock/detect", h((req) => {
    const d = E().deadlock, { algorithm, initiator } = req.body;
    if (algorithm === "wfg") {
      const sites = [...new Set(d.procs.map((p) => p.site))];
      const steps = [{ kind: "info", text: `Centralized global WFG: coordinator collects local wait-for graphs from ${sites.length} sites.` }];
      sites.forEach((sid) => steps.push({ kind: "request", from: sid, to: state.getState().coordinatorId, text: `${nm(sid)} sends its local WFG (${d.edges.filter((e) => site(d, e[0]) === sid).length} edge(s)).` }));
      const cycles = sccCycles(d);
      steps.push(cycles.length ? { kind: "deadlock", text: `Cycle(s) found in the global graph: ${cycles.map((c) => c.join(" -> ") + " -> " + c[0]).join(" ; ")}` } : { kind: "enter", text: "Global graph is acyclic: no deadlock." });
      return { deadlocked: cycles.length > 0, cycles, steps, messages: sites.length, interSite: sites.length };
    }
    const inits = initiator === "all" ? d.procs.map((p) => p.id) : [initiator || d.procs[0].id];
    let steps = [], messages = 0, interSite = 0; const cycles = [];
    inits.forEach((i) => {
      if (inits.length > 1) steps.push({ kind: "info", text: `--- initiator ${i} ---` });
      const r = edgeChase(d, i);
      steps = steps.concat(r.steps); messages += r.messages; interSite += r.interSite;
      if (r.cycle && !cycles.some((c) => [...c].sort().join() === [...r.cycle].sort().join())) cycles.push(r.cycle);
    });
    return { deadlocked: cycles.length > 0, cycles, steps, messages, interSite };
  }));
  app.post("/api/deadlock/resolve", h((req) => {
    const d = E().deadlock, v = req.body.victim;
    d.edges = d.edges.filter((e) => e[0] !== v && e[1] !== v);
    state.persist();
    return { ok: true, text: `${v} aborted: it releases its resources and all wait-for edges touching it are removed.` };
  }));
}

module.exports = { register };
