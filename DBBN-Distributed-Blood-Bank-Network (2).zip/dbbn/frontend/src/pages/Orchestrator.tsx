import React, { useState } from "react";
import { http } from "../api";
import { usePoll, useAction } from "../components/hooks";
import { PageHeader, Panel, Button, Input, timeAgo } from "../components/ui";
import StepPlayer from "../components/StepPlayer";

const podTone: Record<string, string> = { Running: "border-emerald-500/30 bg-emerald-500/10 text-emerald-300", Pending: "border-amber-500/30 bg-amber-500/10 text-amber-300" };

export default function Orchestrator() {
  const { data, reload } = usePoll(() => http.get("/k8s"), 1200);
  const { error, run } = useAction();
  const act = async (fn: () => Promise<any>) => { const r = await run(fn); reload(); return r; };
  const [nd, setNd] = useState("billing-api"); const [nr, setNr] = useState(2);
  const [tags, setTags] = useState<Record<string, string>>({});
  const [steps, setSteps] = useState<any[]>([]);
  const [svc, setSvc] = useState<Record<string, string>>({});
  const deployments: any[] = data?.deployments || [];
  const pods: any[] = data?.pods || [];

  return (
    <div>
      <PageHeader title="Orchestrator (Kubernetes-style)" subtitle="Declare desired replicas; a controller keeps reconciling reality to match: it schedules pods onto healthy nodes, self-heals after crashes and node failures, autoscales on load and performs rolling updates." />
      {error && <div className="text-sm text-rose-400 mb-3">{error}</div>}
      <Panel title="Cluster: pods per node (click a pod to kill it)" className="mb-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {(data?.nodes || []).map((n: any) => (
            <div key={n.id} className={`rounded-xl border p-2 min-h-[110px] ${n.status === "healthy" ? "border-white/10 bg-white/5" : "border-rose-500/30 bg-rose-500/10"}`}>
              <div className="text-xs font-semibold text-white mb-2">{n.name} <span className="text-slate-500 font-normal">{n.status === "healthy" ? `${n.pods}/8 pods` : "NotReady"}</span></div>
              <div className="flex flex-col gap-1">{pods.filter((p) => p.node === n.id).map((p) => <button key={p.id} onClick={() => act(() => http.post("/k8s/kill-pod", { id: p.id }))} className={`text-left text-[10px] px-1.5 py-0.5 rounded border font-mono truncate ${podTone[p.status] || ""}`} title={`${p.image} - click to kill`}>{p.id}</button>)}</div>
            </div>
          ))}
        </div>
        {pods.some((p) => p.status === "Pending") && <div className="text-xs text-amber-400 mt-2">{pods.filter((p) => p.status === "Pending").length} pod(s) Pending: no node with capacity.</div>}
      </Panel>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
        {deployments.map((d) => (
          <Panel key={d.name}>
            <div className="flex items-center justify-between mb-2">
              <div><span className="font-semibold text-white">{d.name}</span> <span className="text-xs text-slate-500 font-mono">{d.image}</span></div>
              <div className={`text-sm font-bold ${d.ready === d.replicas ? "text-emerald-400" : "text-amber-400"}`}>{d.ready}/{d.replicas} ready</div>
            </div>
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <Button variant="secondary" onClick={() => act(() => http.post("/k8s/scale", { name: d.name, replicas: d.replicas - 1 }))}>-</Button>
              <span className="text-sm text-slate-300 w-16 text-center">replicas {d.replicas}</span>
              <Button variant="secondary" onClick={() => act(() => http.post("/k8s/scale", { name: d.name, replicas: d.replicas + 1 }))}>+</Button>
              <Input placeholder={`${d.name}:v2`} value={tags[d.name] || ""} onChange={(e) => setTags({ ...tags, [d.name]: e.target.value })} className="w-32" />
              <Button onClick={async () => { const r = await act(() => http.post("/k8s/rollout", { name: d.name, image: tags[d.name] || `${d.name}:v2` })); if (r) setSteps(r.steps); }}>Rolling update</Button>
              <Button variant="ghost" onClick={() => act(() => http.post("/k8s/delete", { name: d.name }))}>Delete</Button>
            </div>
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 border-t border-white/5 pt-2">
              <label className="flex items-center gap-1"><input type="checkbox" checked={d.autoscale.enabled} onChange={(e) => act(() => http.post("/k8s/autoscale", { name: d.name, enabled: e.target.checked }))} /> Autoscale (target {d.autoscale.target} rps/pod, max {d.autoscale.max})</label>
              <input type="range" min={0} max={400} value={d.load} onChange={(e) => act(() => http.post("/k8s/autoscale", { name: d.name, load: Number(e.target.value) }))} />
              <span>load {d.load} rps</span>
              <Button variant="ghost" onClick={async () => { const r = await act(() => http.post("/k8s/request", { name: d.name })); if (r) setSvc({ ...svc, [d.name]: `${r.pod} on ${r.node}` }); }}>Send request via service</Button>
              {svc[d.name] && <span className="text-sky-300 font-mono">served by {svc[d.name]}</span>}
            </div>
          </Panel>
        ))}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Panel title="Create deployment">
          <div className="flex items-end gap-2"><Input value={nd} onChange={(e) => setNd(e.target.value)} className="w-44" /><Input type="number" min={0} max={10} value={nr} onChange={(e) => setNr(Number(e.target.value))} className="w-20" /><Button onClick={() => act(() => http.post("/k8s/deployments", { name: nd, replicas: nr }))}>Create</Button></div>
          <div className="text-xs text-slate-500 mt-2">Tip: fail a node on the Fault Tolerance page. Its pods are evicted and recreated on healthy nodes within about 2 seconds.</div>
          {steps.length > 0 && <div className="mt-3"><StepPlayer steps={steps} speed={450} title="Rolling update" /></div>}
        </Panel>
        <Panel title="Controller events"><div className="space-y-1 max-h-[260px] overflow-y-auto text-xs font-mono">{(data?.events || []).map((e: any, i: number) => <div key={i} className="px-2 py-1 rounded bg-black/20 border border-white/5 text-slate-300">{e.text} <span className="text-slate-600">({timeAgo(e.ts)})</span></div>)}</div></Panel>
      </div>
    </div>
  );
}
