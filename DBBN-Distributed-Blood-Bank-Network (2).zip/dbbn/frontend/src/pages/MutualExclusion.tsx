import React, { useState } from "react";
import { http } from "../api";
import { usePoll, useAction } from "../components/hooks";
import { PageHeader, Panel, Button, Select } from "../components/ui";
import StepPlayer from "../components/StepPlayer";

const ALGOS: Record<string, string> = { centralized: "Centralized (coordinator grants permission)", "ricart-agrawala": "Ricart-Agrawala (distributed, timestamps)", "token-ring": "Token ring" };

export default function MutualExclusion() {
  const { data } = usePoll(() => http.get("/sync/clocks"), 3000);
  const nodes: any[] = (data?.nodes || []).filter((n: any) => n.status === "healthy");
  const [algo, setAlgo] = useState("ricart-agrawala");
  const [chosen, setChosen] = useState<string[]>(["node-pune", "node-nashik", "node-nagpur"]);
  const [res, setRes] = useState<any>(null);
  const { busy, error, run } = useAction();
  const toggle = (id: string) => setChosen((c) => (c.includes(id) ? c.filter((x) => x !== id) : [...c, id]));
  const key = Object.keys(ALGOS).find((k) => ALGOS[k] === ALGOS[algo]) || algo;

  return (
    <div>
      <PageHeader title="Mutual Exclusion" subtitle="Several nodes want to write to the shared central blood ledger at the same time. Only one may be in the critical section." />
      <Panel className="mb-4">
        <div className="flex flex-wrap items-end gap-4">
          <div><label className="text-xs text-slate-400 block mb-1">Algorithm</label>
            <Select value={ALGOS[algo]} onChange={(v) => setAlgo(Object.keys(ALGOS).find((k) => ALGOS[k] === v) || "centralized")} options={Object.values(ALGOS)} /></div>
          <div><label className="text-xs text-slate-400 block mb-1">Nodes requesting the critical section</label>
            <div className="flex flex-wrap gap-2">{nodes.map((n) => (<label key={n.id} className={`text-sm px-2.5 py-1 rounded-lg border cursor-pointer ${chosen.includes(n.id) ? "border-blood-500 bg-blood-500/10 text-white" : "border-white/10 text-slate-400"}`}><input type="checkbox" className="hidden" checked={chosen.includes(n.id)} onChange={() => toggle(n.id)} />{n.name}</label>))}</div></div>
          <Button disabled={busy} onClick={async () => { const r = await run(() => http.post("/mutex/run", { algorithm: algo, requesters: chosen })); if (r) setRes(r); }}>Run simultaneous requests</Button>
        </div>
        {error && <div className="text-sm text-rose-400 mt-2">{error}</div>}
      </Panel>
      {res && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
          <Panel title="Trace" className="lg:col-span-2"><StepPlayer steps={res.steps} speed={380} /></Panel>
          <Panel title="Result">
            <div className="text-xs text-slate-400">Order of entry into the critical section</div>
            <ol className="list-decimal list-inside text-sm text-white mt-1 mb-3">{res.order.map((n: string, i: number) => <li key={i}>{n}</li>)}</ol>
            <div className="text-sm text-slate-300">Total messages: <b className="text-white">{res.messages}</b></div>
            <div className="text-sm text-slate-300">Messages per entry: <b className="text-white">{res.perEntry}</b></div>
            <div className="text-xs text-emerald-400 mt-2">Safety: only one node was inside the critical section at any step.</div>
          </Panel>
        </div>
      )}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Panel title="Comparison">
          <table className="w-full text-xs"><thead><tr className="text-left text-slate-400 border-b border-white/10"><th className="py-1.5">Algorithm</th><th>Messages per entry</th><th>Weakness</th></tr></thead>
            <tbody>
              <tr className="border-b border-white/5"><td className="py-1.5 text-white">Centralized</td><td>3</td><td className="text-slate-400">Coordinator is a single point of failure</td></tr>
              <tr className="border-b border-white/5"><td className="py-1.5 text-white">Ricart-Agrawala</td><td>2(N-1)</td><td className="text-slate-400">Any node failure blocks progress</td></tr>
              <tr className="border-b border-white/5"><td className="py-1.5 text-white">Token ring</td><td>1 to N-1</td><td className="text-slate-400">Lost token must be regenerated</td></tr>
            </tbody></table>
        </Panel>
        <Panel title="Shared central ledger (critical section writes)">
          <div className="text-xs text-slate-400 mb-1">{key}</div>
          {(res?.ledger || []).length ? <ol className="text-xs font-mono text-slate-300 space-y-0.5">{res.ledger.map((l: any) => <li key={l.seq}>#{l.seq} written by {l.node} ({l.algorithm})</li>)}</ol> : <div className="text-sm text-slate-500">No ledger writes yet.</div>}
        </Panel>
      </div>
    </div>
  );
}
