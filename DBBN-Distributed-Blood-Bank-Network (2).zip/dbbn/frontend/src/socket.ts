import { io } from "socket.io-client";

// In dev, Vite proxies /socket.io to the backend (see vite.config.ts).
export const socket = io({
  path: "/socket.io",
  transports: ["websocket", "polling"],
});
