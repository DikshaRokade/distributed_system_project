import React, { useState } from "react";
import { Crown, Zap, Loader2 } from "lucide-react";
import { api, http } from "../api";
import StepPlayer from "../components/StepPlayer";
import { useAction } from "../components/hooks";
import { useNetwork } from "../store";
import { PageHeader, Panel, Button, Select, timeAgo } from "../components/ui";

export default function LeaderElection() {
  const { nodes, coordinatorId, electionHistory, refreshAll } = useNetwork();
  const [triggering, setTriggering] = useState(false);
  const coordinator = nodes.find((n) => n.id === coordinatorId);
  const latest = electionHistory[0];
  const [ringInit, setRingInit] = useState("");
  const [ringSteps, setRingSteps] = useState<any[]>([]);
  const ring = useAction();
  const healthyNames = nodes.filter((n) => n.status === "healthy").map((n) => n.name);
  async function runRing() {
    const n = nodes.find((x) => x.name === (ringInit || healthyNames[0]));
    const r = await ring.run(() => http.post("/election/ring", { initiator: n?.id }));
    if (r) { setRingSteps(r.steps); await refreshAll(); }
  }

  async function trigger() {
    setTriggering(true);
    try {
      await api.triggerElection();
      await new Promise((r) => setTimeout(r, 2200)); // let the animated messages play out server-side
      await refreshAll();
    } finally {
      setTriggering(false);
    }
  }

  return (
    <div>
      <PageHeader
        title="Leader Election"
        subtitle="Bully Algorithm — when the coordinator fails, the healthy node with the highest numeric ID becomes the new coordinator"
        right={
          <Button onClick={trigger} disabled={triggering} variant="danger">
            {triggering ? <Loader2 className="w-4 h-4 animate-spin inline mr-1" /> : <Zap className="w-4 h-4 inline mr-1" />}
            Simulate Coordinator Failure
          </Button>
        }
      />

      <Panel title="Current Coordinator" className="mb-6">
        {coordinator ? (
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
              <Crown className="w-6 h-6 text-amber-400" />
            </div>
            <div>
              <div className="text-white font-semibold">{coordinator.name}</div>
              <div className="text-xs text-slate-400">numericId {coordinator.numericId} (highest among healthy nodes)</div>
            </div>
          </div>
        ) : (
          <div className="text-slate-500 text-sm">No coordinator elected yet.</div>
        )}
      </Panel>

      <Panel title="Node Priority Order (Bully Algorithm ranks by numericId)" className="mb-6">
        <div className="flex flex-wrap gap-3">
          {[...nodes]
            .sort((a, b) => b.numericId - a.numericId)
            .map((n) => (
              <div
                key={n.id}
                className={`px-3 py-2 rounded-lg border text-sm flex items-center gap-2 ${
                  n.status !== "healthy"
                    ? "border-rose-500/30 bg-rose-500/5 text-rose-400 line-through"
                    : n.id === coordinatorId
                    ? "border-amber-500/40 bg-amber-500/10 text-amber-300"
                    : "border-white/10 bg-white/5 text-slate-300"
                }`}
              >
                {n.id === coordinatorId && <Crown className="w-3.5 h-3.5" />}
                {n.name} <span className="text-[10px] opacity-60">#{n.numericId}</span>
              </div>
            ))}
        </div>
      </Panel>

      <Panel title="Latest Election Trace">
        {latest ? (
          <div>
            <div className="text-xs text-slate-400 mb-3">
              Started {timeAgo(latest.startedAt)} · triggered by failure of{" "}
              <span className="text-rose-400">{nodes.find((n) => n.id === latest.failedCoordinatorId)?.name || latest.failedCoordinatorId}</span>
              {latest.newCoordinatorId && (
                <>
                  {" "}
                  · new coordinator: <span className="text-amber-400">{nodes.find((n) => n.id === latest.newCoordinatorId)?.name}</span>
                </>
              )}
            </div>
            <div className="space-y-1.5 font-mono text-xs max-h-96 overflow-y-auto">
              {latest.messages.map((m, i) => (
                <div key={i} className="flex items-center gap-2 px-2 py-1.5 rounded-lg bg-black/20 border border-white/5">
                  <span
                    className={`shrink-0 px-1.5 py-0.5 rounded border text-[10px] font-semibold ${
                      m.type === "COORDINATOR" ? "text-amber-400 border-amber-500/30 bg-amber-500/10" : "text-sky-400 border-sky-500/30 bg-sky-500/10"
                    }`}
                  >
                    {m.type}
                  </span>
                  <span className="text-slate-300">
                    {nodes.find((n) => n.id === m.from)?.name || m.from} → {m.to === "ALL" ? "ALL" : nodes.find((n) => n.id === m.to)?.name || m.to}
                  </span>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="text-sm text-slate-500 py-6 text-center">No election has run yet. Click "Simulate Coordinator Failure" to trigger a Bully election.</div>
        )}
      </Panel>
      <Panel title="Ring election algorithm (alternative to Bully)" className="mt-6">
        <p className="text-sm text-slate-400 mb-3">Nodes form a logical ring. The initiator circulates an ELECTION message collecting live node ids; when it returns, the highest id wins and a COORDINATOR message circulates the ring. Cost: 2N messages, versus the Bully algorithm's O(N^2) worst case.</p>
        <div className="flex items-end gap-2 mb-3">
          <Select value={ringInit || healthyNames[0] || ""} onChange={setRingInit} options={healthyNames} />
          <Button onClick={runRing}>Start ring election</Button>
        </div>
        {ring.error && <div className="text-sm text-rose-400 mb-2">{ring.error}</div>}
        <StepPlayer steps={ringSteps} speed={380} title="Ring election trace" />
      </Panel>
    </div>
  );
}
