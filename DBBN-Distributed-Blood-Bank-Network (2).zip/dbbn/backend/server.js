// server.js — the "middleware / API gateway" that sits between hospitals (the
// frontend) and the 5 distributed blood-bank nodes. All REST endpoints below
// route through logic.js, which performs RPC-style calls to individual nodes.
const express = require("express");
const cors = require("cors");
const http = require("http");
const { Server } = require("socket.io");

const state = require("./state");
const { makeLogic } = require("./logic");

const PORT = process.env.PORT || 4000;

const app = express();
app.use(cors());
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });
const logic = makeLogic(io);

io.on("connection", (socket) => {
  socket.emit("dashboardUpdate", logic.buildDashboard());
  socket.emit("bootstrap", state.getState());
});

// ---------- Read endpoints ----------
app.get("/api/health", (req, res) => res.json({ ok: true }));

app.get("/api/dashboard", (req, res) => res.json(logic.buildDashboard()));

app.get("/api/nodes", (req, res) => res.json(state.getState().nodes));

app.get("/api/nodes/:id", (req, res) => {
  const node = state.getNode(req.params.id);
  if (!node) return res.status(404).json({ error: "NOT_FOUND" });
  res.json(node);
});

app.get("/api/registry", (req, res) => res.json(state.getState().registry));

app.get("/api/logs", (req, res) => res.json(state.getState().logs));

app.get("/api/transactions", (req, res) => res.json(state.getState().transactions));

app.get("/api/replication-log", (req, res) => res.json(state.getState().replicationLog));

app.get("/api/elections", (req, res) => res.json(state.getState().electionHistory));

app.get("/api/emergency-requests", (req, res) => res.json(state.getState().emergencyRequests));

app.get("/api/broadcasts", (req, res) => res.json(state.getState().broadcasts));

app.get("/api/coordinator", (req, res) => {
  const s = state.getState();
  res.json({ coordinatorId: s.coordinatorId, node: state.getNode(s.coordinatorId) });
});

// ---------- Blood search (distributed computation) ----------
app.post("/api/blood-search", async (req, res) => {
  const { bloodGroup, units } = req.body;
  if (!bloodGroup || !units) return res.status(400).json({ error: "bloodGroup and units required" });
  const results = await logic.searchBlood(bloodGroup, Number(units));
  res.json({ bloodGroup, units: Number(units), results });
});

// ---------- Reservation (full distributed transaction) ----------
app.post("/api/reserve", async (req, res) => {
  const { hospital, bloodGroup, units } = req.body;
  if (!hospital || !bloodGroup || !units) return res.status(400).json({ error: "hospital, bloodGroup, units required" });
  const txn = await logic.reserveBlood({ hospital, bloodGroup, units: Number(units) });
  res.json(txn);
});

// ---------- Concurrency demo: two hospitals race for last units ----------
app.post("/api/reserve/race", async (req, res) => {
  const { bloodGroup, units, hospitalA, hospitalB } = req.body;
  if (!bloodGroup || !units) return res.status(400).json({ error: "bloodGroup and units required" });
  const result = await logic.raceReserve({
    bloodGroup,
    units: Number(units),
    hospitalA: hospitalA || "City Hospital A",
    hospitalB: hospitalB || "City Hospital B",
  });
  res.json(result);
});

// ---------- Emergency requests ----------
app.post("/api/emergency-requests", (req, res) => {
  const { hospital, bloodGroup, units, notes } = req.body;
  if (!hospital || !bloodGroup || !units) return res.status(400).json({ error: "hospital, bloodGroup, units required" });
  const reqObj = logic.createEmergencyRequest({ hospital, bloodGroup, units: Number(units), notes });
  res.json(reqObj);
});

app.post("/api/emergency-requests/:id/resolve", async (req, res) => {
  const result = await logic.resolveEmergencyRequest(req.params.id);
  if (!result) return res.status(404).json({ error: "NOT_FOUND" });
  res.json(result);
});

// ---------- Node management / fault tolerance ----------
app.post("/api/nodes/:id/fail", (req, res) => {
  const node = logic.failNode(req.params.id);
  if (!node) return res.status(404).json({ error: "NOT_FOUND" });
  res.json(node);
});

app.post("/api/nodes/:id/recover", (req, res) => {
  const node = logic.recoverNode(req.params.id);
  if (!node) return res.status(404).json({ error: "NOT_FOUND" });
  res.json(node);
});

// ---------- Leader election (manual trigger, e.g. "simulate coordinator failure") ----------
app.post("/api/election/trigger", async (req, res) => {
  const s = state.getState();
  const coordinatorId = s.coordinatorId;
  logic.failNode(coordinatorId); // failing the coordinator itself triggers runElection()
  res.json({ triggered: true, previousCoordinatorId: coordinatorId });
});

// ---------- Reset demo state ----------
app.post("/api/reset", (req, res) => {
  const fresh = state.resetState();
  io.emit("bootstrap", fresh);
  io.emit("dashboardUpdate", logic.buildDashboard());
  res.json({ ok: true });
});

// Unit III (synchronization) and Unit IV (emerging paradigms) modules
require("./sync").register(app, logic, io);
require("./paradigms").register(app, logic, io);

server.listen(PORT, () => {
  console.log(`DBBN middleware/API gateway listening on http://localhost:${PORT}`);
});
