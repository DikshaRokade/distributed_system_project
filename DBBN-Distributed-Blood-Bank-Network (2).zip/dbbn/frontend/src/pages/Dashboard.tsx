import React from "react";
import { Droplets, Server, ServerCrash, Siren, Crown, Activity } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from "recharts";
import { useNetwork } from "../store";
import { PageHeader, Panel, StatCard } from "../components/ui";
import LogFeed from "../components/LogFeed";
import { BLOOD_GROUPS } from "../constants";

export default function Dashboard() {
  const { dashboard, nodes, logs, coordinatorId } = useNetwork();
  const coordinator = nodes.find((n) => n.id === coordinatorId);

  const chartData = BLOOD_GROUPS.map((bg) => {
    const row: Record<string, any> = { bloodGroup: bg };
    nodes.forEach((n) => {
      row[n.name] = n.inventory[bg] || 0;
    });
    return row;
  });

  const colors = ["#ef4444", "#f59e0b", "#10b981", "#38bdf8", "#a78bfa"];

  return (
    <div>
      <PageHeader
        title="Network Dashboard"
        subtitle="Live overview of the 5-node distributed blood bank network"
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Total Blood Units" value={dashboard?.totalUnits ?? "—"} icon={Droplets} />
        <StatCard label="Active Nodes" value={`${dashboard?.activeNodes ?? "—"} / ${dashboard?.totalNodes ?? 5}`} icon={Server} tone="success" />
        <StatCard label="Failed Nodes" value={dashboard?.failedNodes ?? 0} icon={ServerCrash} tone={dashboard?.failedNodes ? "danger" : "default"} />
        <StatCard label="Pending Emergency Requests" value={dashboard?.pendingRequests ?? 0} icon={Siren} tone="warning" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        <Panel title="Current Coordinator" className="lg:col-span-1">
          {coordinator ? (
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
                <Crown className="w-6 h-6 text-amber-400" />
              </div>
              <div>
                <div className="text-white font-semibold">{coordinator.name}</div>
                <div className="text-xs text-slate-400 font-mono">{coordinator.ip}:{coordinator.port}</div>
                <div className="text-xs text-slate-500 mt-0.5">Elected via Bully Algorithm</div>
              </div>
            </div>
          ) : (
            <div className="text-slate-500 text-sm">No coordinator</div>
          )}
        </Panel>
        <Panel title="Network Health" className="lg:col-span-1">
          <div className="flex items-center gap-3">
            <Activity className="w-6 h-6 text-emerald-400" />
            <div className="flex-1">
              <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full ${
                    (dashboard?.networkHealth ?? 100) > 70 ? "bg-emerald-500" : (dashboard?.networkHealth ?? 100) > 40 ? "bg-amber-500" : "bg-rose-500"
                  }`}
                  style={{ width: `${dashboard?.networkHealth ?? 100}%` }}
                />
              </div>
              <div className="text-xs text-slate-400 mt-1">{dashboard?.networkHealth ?? 100}% of nodes healthy</div>
            </div>
          </div>
        </Panel>
        <Panel title="Transactions Recorded" className="lg:col-span-1">
          <div className="text-2xl font-bold text-white">{dashboard?.transactionsToday ?? 0}</div>
          <div className="text-xs text-slate-500 mt-1">Reserve → Update → Replicate → Commit cycles</div>
        </Panel>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Panel title="Inventory by Node & Blood Group" className="lg:col-span-2">
          <ResponsiveContainer width="100%" height={320}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" />
              <XAxis dataKey="bloodGroup" stroke="#94a3b8" fontSize={12} />
              <YAxis stroke="#94a3b8" fontSize={12} />
              <Tooltip contentStyle={{ background: "#111827", border: "1px solid #ffffff20", borderRadius: 8 }} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              {nodes.map((n, i) => (
                <Bar key={n.id} dataKey={n.name} stackId="a" fill={colors[i % colors.length]} radius={i === nodes.length - 1 ? [4, 4, 0, 0] : undefined} />
              ))}
            </BarChart>
          </ResponsiveContainer>
        </Panel>
        <Panel title="Live Activity" className="lg:col-span-1">
          <LogFeed logs={logs} max={12} />
        </Panel>
      </div>
    </div>
  );
}
