import React, { useEffect, useState } from "react";
import { Clock } from "lucide-react";
import { http } from "../api";
import { usePoll, useAction } from "../components/hooks";
import { PageHeader, Panel, Button, Select, Input, StatusBadge } from "../components/ui";
import StepPlayer, { Step } from "../components/StepPlayer";

const fmt = (ms: number) => new Date(ms).toISOString().slice(11, 23);

export default function ClockSync() {
  const { data, reload } = usePoll(() => http.get("/sync/clocks"), 2000);
  const [, tick] = useState(0);
  useEffect(() => { const t = setInterval(() => tick((x) => x + 1), 80); return () => clearInterval(t); }, []);
  const nodes: any[] = data?.nodes || [];
  const names = nodes.map((n) => n.name);
  const [target, setTarget] = useState("Pune");
  const [skewNode, setSkewNode] = useState("Pune");
  const [skew, setSkew] = useState(2500);
  const [threshold, setThreshold] = useState(5000);
  const [steps, setSteps] = useState<Step[]>([]);
  const { busy, error, run } = useAction();
  const idOf = (name: string) => nodes.find((n) => n.name === name)?.id;
  const healthy = nodes.filter((n) => n.status === "healthy");
  const offs = healthy.map((n) => n.offset);
  const spread = offs.length ? Math.max(...offs) - Math.min(...offs) : 0;
  const now = Date.now();

  return (
    <div>
      <PageHeader title="Clock Synchronization" subtitle="Every node has its own drifting clock. Cristian's algorithm syncs one node to a time server; Berkeley's algorithm averages all clocks through the coordinator." />
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 mb-4">
        {nodes.map((n) => (
          <div key={n.id} className="bg-ink-800/60 border border-white/5 rounded-xl p-3">
            <div className="flex items-center justify-between"><span className="text-sm font-semibold text-white">{n.name}</span><StatusBadge status={n.status} /></div>
            <div className="font-mono text-sm text-sky-300 mt-2">{n.status === "healthy" ? fmt(now + n.offset) : "--:--:--.---"}</div>
            <div className={`text-[11px] mt-1 ${n.offset === 0 ? "text-emerald-400" : "text-amber-400"}`}>offset {n.offset >= 0 ? "+" : ""}{n.offset} ms</div>
          </div>
        ))}
      </div>
      <Panel className="mb-4">
        <div className="text-sm text-slate-300">Maximum difference between healthy clocks: <span className={`font-bold ${spread < 200 ? "text-emerald-400" : "text-amber-400"}`}>{spread} ms</span></div>
      </Panel>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
        <Panel title="Cristian's algorithm (time server)">
          <div className="flex items-end gap-2">
            <Select value={target} onChange={setTarget} options={names} />
            <Button disabled={busy} onClick={async () => { const r = await run(() => http.post("/sync/cristian", { nodeId: idOf(target) })); if (r) { setSteps(r.steps); reload(); } }}>Sync this node</Button>
          </div>
        </Panel>
        <Panel title="Berkeley algorithm (coordinator is time daemon)">
          <div className="flex items-end gap-2">
            <div><label className="text-xs text-slate-400 block mb-1">Outlier threshold (ms)</label><Input type="number" value={threshold} onChange={(e) => setThreshold(Number(e.target.value))} className="w-28" /></div>
            <Button disabled={busy} onClick={async () => { const r = await run(() => http.post("/sync/berkeley", { threshold })); if (r) { setSteps(r.steps); reload(); } }}>Run Berkeley sync</Button>
          </div>
        </Panel>
        <Panel title="Inject clock skew (simulate drift)">
          <div className="flex items-end gap-2">
            <Select value={skewNode} onChange={setSkewNode} options={names} />
            <Input type="number" value={skew} onChange={(e) => setSkew(Number(e.target.value))} className="w-24" />
            <Button variant="secondary" onClick={async () => { await run(() => http.post("/sync/skew", { nodeId: idOf(skewNode), deltaMs: skew })); reload(); }}>Apply</Button>
          </div>
        </Panel>
      </div>
      {error && <div className="text-sm text-rose-400 mb-3">{error}</div>}
      <Panel title="Algorithm trace"><StepPlayer steps={steps} /></Panel>
    </div>
  );
}
