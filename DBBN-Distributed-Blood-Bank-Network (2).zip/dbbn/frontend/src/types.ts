export type BloodGroup = "A+" | "A-" | "B+" | "B-" | "AB+" | "AB-" | "O+" | "O-";

export interface DBNode {
  id: string;
  name: string;
  ip: string;
  port: number;
  numericId: number;
  status: "healthy" | "failed";
  workload: number;
  inventory: Record<string, number>;
  locks: Record<string, boolean>;
  lastHeartbeat: number;
}

export interface LogEntry {
  id: string;
  ts: number;
  type: "RPC" | "MESSAGE" | "P2P" | "ELECTION";
  from: string;
  to: string;
  summary: string;
  ok?: boolean;
}

export interface TxnStep {
  name: string;
  status: "running" | "done" | "failed";
  detail: string;
  ts: number;
}

export interface Transaction {
  id: string;
  hospital: string;
  bloodGroup: string;
  units: number;
  status: "pending" | "preparing" | "committed" | "rolled_back";
  steps: TxnStep[];
  createdAt: number;
}

export interface EmergencyRequest {
  id: string;
  hospital: string;
  bloodGroup: string;
  units: number;
  notes: string;
  status: "pending" | "fulfilled" | "unresolved";
  createdAt: number;
  transactionId?: string;
}

export interface ReplicationEntry {
  ts: number;
  from: string;
  to: string;
  bloodGroup: string;
  delta: number;
  status: string;
}

export interface ElectionMessage {
  ts: number;
  from: string;
  to: string;
  type: "ELECTION" | "COORDINATOR";
}

export interface Election {
  id: string;
  startedAt: number;
  messages: ElectionMessage[];
  failedCoordinatorId: string;
  newCoordinatorId: string | null;
}

export interface Broadcast {
  id: string;
  ts: number;
  bloodGroup: string;
  shortfall: number;
  message: string;
}

export interface Dashboard {
  totalUnits: number;
  activeNodes: number;
  failedNodes: number;
  totalNodes: number;
  pendingRequests: number;
  coordinatorId: string;
  networkHealth: number;
  transactionsToday: number;
}

export interface NetworkState {
  nodes: DBNode[];
  coordinatorId: string;
  registry: Record<string, { id: string; ip: string; port: number }>;
  logs: LogEntry[];
  transactions: Transaction[];
  emergencyRequests: EmergencyRequest[];
  electionHistory: Election[];
  replicationLog: ReplicationEntry[];
  broadcasts: Broadcast[];
}
