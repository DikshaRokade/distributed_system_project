import React from "react";
import { Cpu, MemoryStick, Container, Crown } from "lucide-react";
import { useNetwork } from "../store";
import { PageHeader, Panel, StatusBadge } from "../components/ui";

// Each node is represented as a lightweight "virtual container" — CPU/memory
// figures are derived from the node's live workload so they move with real
// activity while staying stable between renders for the same workload value.
function deriveMetrics(workload: number, numericId: number) {
  const cpu = Math.min(98, Math.round(workload * 0.9 + numericId * 2));
  const memory = Math.min(95, Math.round(30 + workload * 0.6 + ((numericId * 7) % 11)));
  return { cpu, memory };
}

export default function VirtualInfrastructure() {
  const { nodes, coordinatorId } = useNetwork();

  return (
    <div>
      <PageHeader title="Virtual Infrastructure" subtitle="Each blood bank runs as an isolated virtual node (container) with its own resources" />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {nodes.map((n) => {
          const { cpu, memory } = deriveMetrics(n.workload, n.numericId);
          return (
            <Panel key={n.id}>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-9 h-9 rounded-lg bg-white/5 flex items-center justify-center">
                    <Container className="w-4 h-4 text-slate-300" />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-semibold text-white text-sm">vm-{n.id}</span>
                      {n.id === coordinatorId && <Crown className="w-3.5 h-3.5 text-amber-400" />}
                    </div>
                    <div className="text-[11px] text-slate-500 font-mono">{n.ip}:{n.port}</div>
                  </div>
                </div>
                <StatusBadge status={n.status} />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <div className="flex items-center gap-1.5 text-xs text-slate-400 mb-1">
                    <Cpu className="w-3.5 h-3.5" /> CPU
                  </div>
                  <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
                    <div className={`h-full rounded-full ${cpu > 75 ? "bg-rose-500" : cpu > 50 ? "bg-amber-500" : "bg-sky-500"}`} style={{ width: `${n.status === "healthy" ? cpu : 0}%` }} />
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1">{n.status === "healthy" ? `${cpu}%` : "offline"}</div>
                </div>
                <div>
                  <div className="flex items-center gap-1.5 text-xs text-slate-400 mb-1">
                    <MemoryStick className="w-3.5 h-3.5" /> Memory
                  </div>
                  <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
                    <div className={`h-full rounded-full ${memory > 75 ? "bg-rose-500" : memory > 50 ? "bg-amber-500" : "bg-emerald-500"}`} style={{ width: `${n.status === "healthy" ? memory : 0}%` }} />
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1">{n.status === "healthy" ? `${memory}%` : "offline"}</div>
                </div>
              </div>

              <div className="text-[11px] text-slate-500 mt-3">
                Workload score: {n.workload} · Active locks: {Object.keys(n.locks).length}
              </div>
            </Panel>
          );
        })}
      </div>
    </div>
  );
}
