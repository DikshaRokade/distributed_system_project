const BASE = "/api";

async function req<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Request failed: ${res.status}`);
  }
  return res.json();
}

export const api = {
  dashboard: () => req<import("./types").Dashboard>("/dashboard"),
  nodes: () => req<import("./types").DBNode[]>("/nodes"),
  registry: () => req<Record<string, any>>("/registry"),
  logs: () => req<import("./types").LogEntry[]>("/logs"),
  transactions: () => req<import("./types").Transaction[]>("/transactions"),
  replicationLog: () => req<import("./types").ReplicationEntry[]>("/replication-log"),
  elections: () => req<import("./types").Election[]>("/elections"),
  emergencyRequests: () => req<import("./types").EmergencyRequest[]>("/emergency-requests"),
  broadcasts: () => req<import("./types").Broadcast[]>("/broadcasts"),
  coordinator: () => req<{ coordinatorId: string; node: import("./types").DBNode }>("/coordinator"),

  bloodSearch: (bloodGroup: string, units: number) =>
    req<{ bloodGroup: string; units: number; results: any[] }>("/blood-search", {
      method: "POST",
      body: JSON.stringify({ bloodGroup, units }),
    }),

  reserve: (hospital: string, bloodGroup: string, units: number) =>
    req<import("./types").Transaction>("/reserve", {
      method: "POST",
      body: JSON.stringify({ hospital, bloodGroup, units }),
    }),

  reserveRace: (bloodGroup: string, units: number, hospitalA: string, hospitalB: string) =>
    req<{ a: import("./types").Transaction; b: import("./types").Transaction }>("/reserve/race", {
      method: "POST",
      body: JSON.stringify({ bloodGroup, units, hospitalA, hospitalB }),
    }),

  createEmergency: (hospital: string, bloodGroup: string, units: number, notes: string) =>
    req<import("./types").EmergencyRequest>("/emergency-requests", {
      method: "POST",
      body: JSON.stringify({ hospital, bloodGroup, units, notes }),
    }),

  resolveEmergency: (id: string) =>
    req<{ req: import("./types").EmergencyRequest; txn: import("./types").Transaction }>(
      `/emergency-requests/${id}/resolve`,
      { method: "POST" }
    ),

  failNode: (id: string) => req<import("./types").DBNode>(`/nodes/${id}/fail`, { method: "POST" }),
  recoverNode: (id: string) => req<import("./types").DBNode>(`/nodes/${id}/recover`, { method: "POST" }),

  triggerElection: () =>
    req<{ triggered: boolean; previousCoordinatorId: string }>("/election/trigger", { method: "POST" }),

  reset: () => req<{ ok: boolean }>("/reset", { method: "POST" }),
};

// Generic helpers used by the Unit III / Unit IV pages.
export const http = {
  get: <T = any>(p: string) => req<T>(p),
  post: <T = any>(p: string, body?: any) => req<T>(p, { method: "POST", body: JSON.stringify(body || {}) }),
};
