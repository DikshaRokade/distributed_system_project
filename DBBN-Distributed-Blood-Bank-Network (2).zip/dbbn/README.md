# DBBN — Distributed Blood Bank Network

An academic Distributed Systems project: a network of 5 independent blood-bank
nodes (Pune, Mumbai, Nashik, Nagpur, Kolhapur) coordinated through a
middleware/API gateway, with RPC, P2P replication, distributed locking,
transactions, fault tolerance, and Bully-algorithm leader election — all
visualized live in a React dashboard.

## 1. Architecture

```
 Hospital (browser)
        │  HTTPS / REST + WebSocket
        ▼
 ┌─────────────────────────┐
 │  Middleware / API Gateway │  backend/server.js  (Express + Socket.IO)
 └─────────────────────────┘
        │  simulated RPC (rpcCall)          │  live events (Socket.IO)
        ▼                                    ▼
 ┌───────────────────────────────────┐   React dashboard (frontend/)
 │  5 virtual blood-bank nodes         │   — Dashboard, Blood Search,
 │  Pune · Mumbai · Nashik ·           │     Emergency Requests, Topology,
 │  Nagpur · Kolhapur                  │     Node Mgmt, Monitors, Election,
 │  (backend/state.js, logic.js)       │     Fault Tolerance, Transactions...
 └───────────────────────────────────┘
        │  P2P replication mesh (node ↔ node, bypasses the coordinator)
        ▼
 Persistent state (backend/data.json, written on every change)
```

- **Frontend**: React + TypeScript + Vite + Tailwind CSS + Recharts + lucide-react,
  talking to the backend over REST and a live Socket.IO connection for logs,
  transactions, elections, and replication events.
- **Backend**: Node.js + Express (the middleware/API gateway) + Socket.IO,
  with all distributed-systems behaviour implemented in `logic.js` on top of
  the shared in-memory state in `state.js`. State is persisted to
  `backend/data.json` (simple JSON persistence, as allowed by the brief).

## 2. Setup

Requires Node.js 18+.

```bash
# 1. Backend
cd backend
npm install
npm run dev          # starts the API gateway on http://localhost:4000

# 2. Frontend (in a second terminal)
cd frontend
npm install
npm run dev           # starts Vite on http://localhost:5173
```

Open **http://localhost:5173** — the Vite dev server proxies `/api` and
`/socket.io` to the backend automatically (see `frontend/vite.config.ts`), so
no CORS configuration is needed in development.

To reset the demo data at any point, either delete `backend/data.json` and
restart the backend, or call `POST /api/reset`.

## 3. REST API

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/dashboard` | Aggregate network stats |
| GET | `/api/nodes` | All node states |
| GET | `/api/nodes/:id` | Single node |
| GET | `/api/registry` | Name → ID/IP/port service registry |
| GET | `/api/logs` | Communication log (RPC/MESSAGE/P2P/ELECTION) |
| GET | `/api/transactions` | All reservation transactions |
| GET | `/api/replication-log` | P2P replication history |
| GET | `/api/elections` | Election history |
| GET | `/api/emergency-requests` | Emergency requests |
| GET | `/api/broadcasts` | Shortage broadcast alerts |
| GET | `/api/coordinator` | Current coordinator |
| POST | `/api/blood-search` `{bloodGroup, units}` | Parallel distributed search |
| POST | `/api/reserve` `{hospital, bloodGroup, units}` | Full distributed transaction |
| POST | `/api/reserve/race` `{bloodGroup, units, hospitalA, hospitalB}` | Concurrency demo |
| POST | `/api/emergency-requests` `{hospital, bloodGroup, units, notes}` | Create emergency request |
| POST | `/api/emergency-requests/:id/resolve` | Attempt to fulfil a request |
| POST | `/api/nodes/:id/fail` | Simulate node failure |
| POST | `/api/nodes/:id/recover` | Recover a failed node |
| POST | `/api/election/trigger` | Simulate coordinator failure → Bully election |
| POST | `/api/reset` | Reset all demo state |

## 4. Distributed Systems concepts implemented

See the in-app **DS Concepts** page for the full syllabus-topic-to-code
mapping. Summary:

| Concept | Where |
|---|---|
| Distributed Architecture | `backend/state.js` — 5 independent node states |
| Middleware | `backend/server.js` — Express API gateway |
| RPC | `backend/logic.js` → `rpcCall()` |
| Message-Oriented Communication | `backend/logic.js` → `log()` (type `MESSAGE`) |
| P2P Communication | `backend/logic.js` → `replicateUpdate()` |
| Names/Identifiers/Addresses | `backend/state.js` → `registry` |
| Distributed Computation | `backend/logic.js` → `searchBlood()` (parallel RPC) |
| Replication | `backend/logic.js` → `replicateUpdate()` |
| Concurrency & Synchronization | `backend/logic.js` → `tryAcquireLock()` / `releaseLock()` |
| Fault Tolerance | `backend/logic.js` → `failNode()` / `recoverNode()` |
| Leader Election (Bully) | `backend/logic.js` → `runElection()` |
| Virtualization | Frontend "Virtual Infrastructure" page |
| Distributed Transactions | `backend/logic.js` → `reserveBlood()` |
| Distributed Multimedia | `backend/logic.js` → shortage broadcast in `createEmergencyRequest()` |

## 5. Demo script

**A. Distributed search + transaction**
1. Go to **Blood Search**, pick a blood group and unit count, click *Search Network*.
2. Watch the parallel per-node RPC results appear.
3. Click *Reserve from <node>* — watch the animated transaction timeline:
   Search → Lock → Reserve → UpdateInventory → Replicate → Commit.
4. Check **Communication Monitor** and **Replication Monitor** to see the
   RPC/P2P events this generated, and **Transactions** for the full record.

**B. Fault tolerance + leader election**
1. Go to **Fault Tolerance** (or **Node Management**).
2. Fail the current coordinator (crown icon) — a Bully election starts
   automatically. Watch **Leader Election** for the message trace and the
   newly elected coordinator.
3. Run another blood search — the network keeps serving requests through the
   remaining healthy nodes.
4. Recover the node — it resynchronizes.

**C. Concurrency / distributed locking**
1. Go to **Transactions** → *Concurrency Demo*.
2. Fire two simultaneous reservation requests for the same blood group/units.
3. Only one commits; the other is rolled back because it couldn't acquire the
   distributed lock — proving mutual exclusion across concurrent transactions.

**D. Emergency broadcast**
1. Go to **Emergency Requests**, submit a request for more units than the
   network currently holds of that blood group.
2. A shortage broadcast alert appears (distributed multimedia notification).

## 6. Notes for the report

- All 5 nodes and the middleware run inside a single Node.js process for
  simplicity of local demoing — logically they are still treated (and coded)
  as independent nodes communicating only via RPC/message/P2P calls, never by
  directly touching each other's state. This mirrors how many academic
  DS projects simulate a cluster on one machine.
- Simulated network latency (60–260ms) is added to every RPC/P2P call so the
  distributed nature of the system is visible in the UI rather than being
  instantaneous.
- State persists to `backend/data.json` between restarts; delete the file (or
  call `POST /api/reset`) to start a fresh demo.

## 7. Part 2: Unit III (Synchronization) and Unit IV (Emerging Paradigms)

Two new backend modules were added: `backend/sync.js` (Unit III) and
`backend/paradigms.js` (Unit IV). Both are registered from `server.js`.
The sidebar is grouped into Core system, Unit III, Unit IV and Reference.

### Unit III pages

| Syllabus topic | Page | How to demo it |
|---|---|---|
| Clock synchronization | Clock Synchronization | Nodes start with skewed clocks. Run Cristian on one node, or Berkeley for all. Watch the "maximum difference" drop. Use "Inject clock skew" to break a clock again. |
| Logical clocks, Lamport | Logical and Vector Clocks | Run "blood-request scenario", then read the space-time diagram. |
| Vector clocks | Logical and Vector Clocks | Click two events on the diagram: the app reports happened-before or concurrent. |
| Global state | Global State Snapshot | Add random transfers (messages in flight), start a snapshot. Check "consistent cut" (total units conserved). |
| Election algorithms | Leader Election | Bully (existing) and the new Ring election panel. |
| Mutual exclusion | Mutual Exclusion | Select 3 requesters and run centralized, Ricart-Agrawala and token ring. Compare message counts. |
| Beacon protocol | Beacon Protocol | Press "Silent crash" on a node. After the timeout it is declared failed automatically (and an election runs if it was the coordinator). |
| Deadlock detection (self study: Knapp) | Deadlock Detection | Load "Two hospitals, opposite lock order". Run edge chasing, then the centralized WFG, then abort a victim. |

Lodha and Kshemkalyani's fair mutual exclusion algorithm is listed as theory
only (not implemented). Path-pushing and diffusion deadlock detection are
likewise theory only; edge chasing and the global-graph method are implemented.

### Unit IV pages

| Syllabus topic | Page | How to demo it |
|---|---|---|
| Distributed object-based systems | Distributed Objects | Invoke `Pune/Inventory.reserve` and read the stub/skeleton path. Fail Pune and invoke again to get a RemoteException. |
| Distributed web-based systems | Web Systems | Send repeated requests (HIT vs MISS), change the load-balancing algorithm, press "Reserve 2 units" to see a stale cached value. |
| Distributed file system | Distributed File System | Upload a file (blocks + replicas), fail a node, read the file (failover), run re-replication. |
| Serverless | Serverless | Invoke once (cold), again (warm), then burst 10 (scale-out). Watch the container pool and billing. |
| Hadoop (case study) | MapReduce | Run word count on a DFS file with and without the combiner and compare shuffled records. Fail a node and re-run. |
| Kubernetes (case study) | Orchestrator | Kill a pod, fail a node, enable autoscale and drag the load slider, run a rolling update. |
| AWS, Cloudflare (case studies) | Serverless, DFS, Orchestrator, Web Systems | Modelled concepts only; no real AWS or Cloudflare services are called. |
| Megaport (case study) | Network Fabric | Provision a virtual cross connect, resize it, test a transfer. |

### New REST endpoints

Unit III: `GET /api/sync/clocks`, `POST /api/sync/{cristian,berkeley,skew}`,
`GET /api/logical`, `POST /api/logical/{local,send,scenario,reset}`,
`GET /api/snapshot`, `POST /api/snapshot/{transfer,random,deliver,run}`,
`POST /api/mutex/run`, `POST /api/election/ring`,
`GET /api/beacon`, `POST /api/beacon/{config,mute}`,
`GET /api/deadlock`, `POST /api/deadlock/{edge,remove-edge,preset,detect,resolve}`.

Unit IV: `GET /api/objects`, `POST /api/objects/{bind,unbind,invoke}`,
`GET /api/web`, `POST /api/web/{config,request,burst,purge,reset}`,
`GET /api/dfs`, `POST /api/dfs/{upload,delete,rereplicate}`, `GET /api/dfs/read/:name`,
`GET /api/serverless`, `POST /api/serverless/{invoke,burst,config,reset}`,
`POST /api/mapreduce/run`,
`GET /api/k8s`, `POST /api/k8s/{deployments,scale,delete,kill-pod,autoscale,rollout,request}`,
`GET /api/net`, `POST /api/net/{vxc,resize,delete,transfer}`.

### Honest limitations (useful for the viva)

- Everything runs in one Node process; nodes are logical, as in Part 1.
- Algorithm traces for the synchronization pages are computed on the server in
  one pass and replayed step by step in the browser. The protocols themselves
  are real; the "network" is simulated.
- Serverless functions are three built-in functions (no user-uploaded code).
- Costs on the Serverless and Network Fabric pages are demo estimates, not real prices.
