import React from "react";
import type { LucideIcon } from "lucide-react";

export function PageHeader({ title, subtitle, right }: { title: string; subtitle?: string; right?: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between mb-6 gap-4 flex-wrap">
      <div>
        <h1 className="text-xl font-bold text-white">{title}</h1>
        {subtitle && <p className="text-sm text-slate-400 mt-1">{subtitle}</p>}
      </div>
      {right}
    </div>
  );
}

export function Panel({ title, children, className = "", right }: { title?: string; children: React.ReactNode; className?: string; right?: React.ReactNode }) {
  return (
    <div className={`bg-ink-800/60 border border-white/5 rounded-xl p-4 ${className}`}>
      {title && (
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-semibold text-slate-200">{title}</h2>
          {right}
        </div>
      )}
      {children}
    </div>
  );
}

export function StatCard({
  label,
  value,
  icon: Icon,
  tone = "default",
  hint,
}: {
  label: string;
  value: React.ReactNode;
  icon: LucideIcon;
  tone?: "default" | "danger" | "success" | "warning";
  hint?: string;
}) {
  const toneMap: Record<string, string> = {
    default: "text-blood-400 bg-blood-600/10",
    danger: "text-rose-400 bg-rose-500/10",
    success: "text-emerald-400 bg-emerald-500/10",
    warning: "text-amber-400 bg-amber-500/10",
  };
  return (
    <div className="bg-ink-800/60 border border-white/5 rounded-xl p-4 flex items-start justify-between">
      <div>
        <div className="text-xs text-slate-400">{label}</div>
        <div className="text-2xl font-bold text-white mt-1">{value}</div>
        {hint && <div className="text-[11px] text-slate-500 mt-1">{hint}</div>}
      </div>
      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${toneMap[tone]}`}>
        <Icon className="w-5 h-5" />
      </div>
    </div>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    healthy: "bg-emerald-500/10 text-emerald-400 border-emerald-500/30",
    failed: "bg-rose-500/10 text-rose-400 border-rose-500/30",
    pending: "bg-amber-500/10 text-amber-400 border-amber-500/30",
    preparing: "bg-amber-500/10 text-amber-400 border-amber-500/30",
    committed: "bg-emerald-500/10 text-emerald-400 border-emerald-500/30",
    fulfilled: "bg-emerald-500/10 text-emerald-400 border-emerald-500/30",
    rolled_back: "bg-rose-500/10 text-rose-400 border-rose-500/30",
    unresolved: "bg-rose-500/10 text-rose-400 border-rose-500/30",
    running: "bg-sky-500/10 text-sky-400 border-sky-500/30",
    done: "bg-emerald-500/10 text-emerald-400 border-emerald-500/30",
    failed_step: "bg-rose-500/10 text-rose-400 border-rose-500/30",
  };
  const cls = map[status] || "bg-slate-500/10 text-slate-300 border-slate-500/30";
  return (
    <span className={`text-[11px] px-2 py-0.5 rounded-full border font-medium capitalize ${cls}`}>
      {status.replace(/_/g, " ")}
    </span>
  );
}

export function Button({
  children,
  onClick,
  variant = "primary",
  disabled,
  className = "",
  type = "button",
}: {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "danger" | "ghost";
  disabled?: boolean;
  className?: string;
  type?: "button" | "submit";
}) {
  const variants: Record<string, string> = {
    primary: "bg-blood-600 hover:bg-blood-700 text-white shadow shadow-blood-900/30",
    secondary: "bg-white/5 hover:bg-white/10 text-slate-200 border border-white/10",
    danger: "bg-rose-600 hover:bg-rose-700 text-white",
    ghost: "hover:bg-white/5 text-slate-300",
  };
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors disabled:opacity-40 disabled:cursor-not-allowed ${variants[variant]} ${className}`}
    >
      {children}
    </button>
  );
}

export function Select({ value, onChange, options, className = "" }: { value: string; onChange: (v: string) => void; options: string[]; className?: string }) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className={`bg-ink-700 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-slate-200 focus:outline-none focus:ring-1 focus:ring-blood-500 ${className}`}
    >
      {options.map((o) => (
        <option key={o} value={o}>
          {o}
        </option>
      ))}
    </select>
  );
}

export function Input(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={`bg-ink-700 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-slate-200 focus:outline-none focus:ring-1 focus:ring-blood-500 ${props.className || ""}`}
    />
  );
}

export function timeAgo(ts: number) {
  const diff = Math.max(0, Date.now() - ts);
  const s = Math.floor(diff / 1000);
  if (s < 5) return "just now";
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  return `${h}h ago`;
}
