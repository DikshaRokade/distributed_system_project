import React, { useState } from "react";
import { Siren, Send, Loader2, RadioTower } from "lucide-react";
import { api } from "../api";
import { useNetwork } from "../store";
import { PageHeader, Panel, Button, Select, Input, StatusBadge, timeAgo } from "../components/ui";
import { BLOOD_GROUPS } from "../constants";

export default function EmergencyRequests() {
  const { emergencyRequests, broadcasts, refreshAll } = useNetwork();
  const [hospital, setHospital] = useState("Ruby Hall Clinic");
  const [bloodGroup, setBloodGroup] = useState("AB-");
  const [units, setUnits] = useState(10);
  const [notes, setNotes] = useState("Trauma ward — urgent");
  const [submitting, setSubmitting] = useState(false);
  const [resolvingId, setResolvingId] = useState<string | null>(null);

  async function submit() {
    setSubmitting(true);
    try {
      await api.createEmergency(hospital, bloodGroup, units, notes);
      await refreshAll();
    } finally {
      setSubmitting(false);
    }
  }

  async function resolve(id: string) {
    setResolvingId(id);
    try {
      await api.resolveEmergency(id);
      await refreshAll();
    } finally {
      setResolvingId(null);
    }
  }

  return (
    <div>
      <PageHeader title="Emergency Requests" subtitle="Urgent hospital requests, with automatic network-wide shortage broadcasts" />

      <Panel title="New Emergency Request" className="mb-6">
        <div className="flex flex-wrap items-end gap-3">
          <div>
            <label className="text-xs text-slate-400 block mb-1">Hospital</label>
            <Input value={hospital} onChange={(e) => setHospital(e.target.value)} className="w-56" />
          </div>
          <div>
            <label className="text-xs text-slate-400 block mb-1">Blood Group</label>
            <Select value={bloodGroup} onChange={setBloodGroup} options={BLOOD_GROUPS} />
          </div>
          <div>
            <label className="text-xs text-slate-400 block mb-1">Units</label>
            <Input type="number" min={1} value={units} onChange={(e) => setUnits(Number(e.target.value))} className="w-24" />
          </div>
          <div className="flex-1 min-w-[200px]">
            <label className="text-xs text-slate-400 block mb-1">Notes</label>
            <Input value={notes} onChange={(e) => setNotes(e.target.value)} className="w-full" />
          </div>
          <Button onClick={submit} disabled={submitting}>
            {submitting ? <Loader2 className="w-4 h-4 animate-spin inline mr-1" /> : <Send className="w-4 h-4 inline mr-1" />}
            Submit Request
          </Button>
        </div>
      </Panel>

      {broadcasts.length > 0 && (
        <Panel title="Shortage Broadcasts (Distributed Multimedia Alert)" className="mb-6">
          <div className="space-y-2">
            {broadcasts.slice(0, 5).map((b) => (
              <div key={b.id} className="flex items-start gap-2 p-3 rounded-lg bg-rose-500/10 border border-rose-500/30">
                <RadioTower className="w-4 h-4 text-rose-400 mt-0.5 shrink-0" />
                <div className="flex-1">
                  <div className="text-sm text-rose-300">{b.message}</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">{timeAgo(b.ts)} · shortfall {b.shortfall} units</div>
                </div>
              </div>
            ))}
          </div>
        </Panel>
      )}

      <Panel title="Requests">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-slate-400 border-b border-white/10">
                <th className="py-2 pr-4 font-medium">Hospital</th>
                <th className="py-2 pr-4 font-medium">Blood Group</th>
                <th className="py-2 pr-4 font-medium">Units</th>
                <th className="py-2 pr-4 font-medium">Notes</th>
                <th className="py-2 pr-4 font-medium">Status</th>
                <th className="py-2 pr-4 font-medium">Requested</th>
                <th className="py-2 pr-4 font-medium"></th>
              </tr>
            </thead>
            <tbody>
              {emergencyRequests.map((r) => (
                <tr key={r.id} className="border-b border-white/5">
                  <td className="py-2 pr-4 text-white">{r.hospital}</td>
                  <td className="py-2 pr-4 text-blood-400 font-semibold">{r.bloodGroup}</td>
                  <td className="py-2 pr-4">{r.units}</td>
                  <td className="py-2 pr-4 text-slate-400">{r.notes}</td>
                  <td className="py-2 pr-4">
                    <StatusBadge status={r.status} />
                  </td>
                  <td className="py-2 pr-4 text-slate-500">{timeAgo(r.createdAt)}</td>
                  <td className="py-2 pr-4">
                    {r.status === "pending" && (
                      <Button variant="secondary" onClick={() => resolve(r.id)} disabled={resolvingId === r.id}>
                        {resolvingId === r.id ? <Loader2 className="w-3.5 h-3.5 animate-spin inline mr-1" /> : <Siren className="w-3.5 h-3.5 inline mr-1" />}
                        Resolve
                      </Button>
                    )}
                  </td>
                </tr>
              ))}
              {emergencyRequests.length === 0 && (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-500">
                    No emergency requests yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Panel>
    </div>
  );
}
