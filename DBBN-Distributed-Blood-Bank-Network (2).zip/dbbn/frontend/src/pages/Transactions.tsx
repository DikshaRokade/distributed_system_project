import React, { useState } from "react";
import { Swords, Loader2 } from "lucide-react";
import { api } from "../api";
import { useNetwork } from "../store";
import { PageHeader, Panel, Button, Select, Input, StatusBadge, timeAgo } from "../components/ui";
import { BLOOD_GROUPS } from "../constants";
import type { Transaction } from "../types";

export default function Transactions() {
  const { transactions, refreshAll } = useNetwork();
  const [bloodGroup, setBloodGroup] = useState("B+");
  const [units, setUnits] = useState(6);
  const [racing, setRacing] = useState(false);
  const [raceResult, setRaceResult] = useState<{ a: Transaction; b: Transaction } | null>(null);

  async function runRace() {
    setRacing(true);
    setRaceResult(null);
    try {
      const result = await api.reserveRace(bloodGroup, units, "City Hospital A", "City Hospital B");
      setRaceResult(result);
      await refreshAll();
    } finally {
      setRacing(false);
    }
  }

  return (
    <div>
      <PageHeader title="Transactions" subtitle="Reserve → Update Inventory → Replicate → Commit / Rollback" />

      <Panel title="Concurrency Demo — two hospitals race for the same stock" className="mb-6">
        <p className="text-sm text-slate-400 mb-3">
          Two hospitals simultaneously request the same blood group and quantity. A distributed lock on the target node
          ensures only one reservation can commit at a time.
        </p>
        <div className="flex flex-wrap items-end gap-3">
          <div>
            <label className="text-xs text-slate-400 block mb-1">Blood Group</label>
            <Select value={bloodGroup} onChange={setBloodGroup} options={BLOOD_GROUPS} />
          </div>
          <div>
            <label className="text-xs text-slate-400 block mb-1">Units (each hospital requests this many)</label>
            <Input type="number" min={1} value={units} onChange={(e) => setUnits(Number(e.target.value))} className="w-28" />
          </div>
          <Button onClick={runRace} disabled={racing}>
            {racing ? <Loader2 className="w-4 h-4 animate-spin inline mr-1" /> : <Swords className="w-4 h-4 inline mr-1" />}
            Fire concurrent requests
          </Button>
        </div>

        {raceResult && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4">
            {(["a", "b"] as const).map((k) => {
              const t = raceResult[k];
              return (
                <div key={k} className="rounded-xl border border-white/10 p-3">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-semibold text-white text-sm">{t.hospital}</span>
                    <StatusBadge status={t.status} />
                  </div>
                  <div className="text-xs text-slate-500">{t.steps[t.steps.length - 1]?.detail}</div>
                </div>
              );
            })}
          </div>
        )}
      </Panel>

      <Panel title="All Transactions">
        <div className="space-y-3 max-h-[560px] overflow-y-auto pr-1">
          {transactions.map((t) => (
            <div key={t.id} className="rounded-xl border border-white/5 bg-white/5 p-3">
              <div className="flex items-center justify-between mb-2 flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-white text-sm">{t.hospital}</span>
                  <span className="text-xs text-slate-500">{t.units} units of</span>
                  <span className="text-blood-400 font-semibold text-sm">{t.bloodGroup}</span>
                </div>
                <div className="flex items-center gap-2">
                  <StatusBadge status={t.status} />
                  <span className="text-[11px] text-slate-500">{timeAgo(t.createdAt)}</span>
                </div>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {t.steps.map((s, i) => (
                  <span
                    key={i}
                    title={s.detail}
                    className={`text-[10px] px-2 py-0.5 rounded-full border ${
                      s.status === "done"
                        ? "border-emerald-500/30 text-emerald-400 bg-emerald-500/5"
                        : s.status === "failed"
                        ? "border-rose-500/30 text-rose-400 bg-rose-500/5"
                        : "border-sky-500/30 text-sky-400 bg-sky-500/5"
                    }`}
                  >
                    {s.name}
                  </span>
                ))}
              </div>
            </div>
          ))}
          {transactions.length === 0 && <div className="text-sm text-slate-500 text-center py-8">No transactions yet.</div>}
        </div>
      </Panel>
    </div>
  );
}
