import { useCallback, useEffect, useRef, useState } from "react";

// Poll an async loader every `ms` milliseconds.
export function usePoll<T>(fn: () => Promise<T>, ms: number) {
  const [data, setData] = useState<T | null>(null);
  const ref = useRef(fn);
  ref.current = fn;
  const reload = useCallback(async () => {
    try { setData(await ref.current()); } catch { /* backend not reachable yet */ }
  }, []);
  useEffect(() => {
    reload();
    const t = setInterval(reload, ms);
    return () => clearInterval(t);
  }, [reload, ms]);
  return { data, reload };
}

// Run an async action, capturing errors for display.
export function useAction() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const run = async <T,>(fn: () => Promise<T>): Promise<T | undefined> => {
    setBusy(true); setError("");
    try { return await fn(); }
    catch (e: any) { setError(e.message || "Request failed"); }
    finally { setBusy(false); }
  };
  return { busy, error, run, setError };
}
